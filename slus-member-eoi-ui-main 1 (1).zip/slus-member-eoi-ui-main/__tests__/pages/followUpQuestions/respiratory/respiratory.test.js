import { AppProvider } from '@/components/context/app.context'
import { ApplicantsProvider, useApplicantsDispatcher } from '@/components/context/Applicants.context'
import { StepHandlerContext } from '@/components/context/StepHandler.context'
import { RespiratorySteps } from '@/components/followUpQuestions/respiratory/stepConfig'
import RespiratoryLandingStep from '@/components/followUpQuestions/respiratory/steps/respiratory'
import { act, fireEvent, render, screen, waitFor } from '@testing-library/react'
import { useEffect, useState } from 'react'
import { FormProvider, useForm } from 'react-hook-form'

describe('RespiratoryLandingStep component', () => {
  const stepConfig = RespiratorySteps.steps.find((s) => s.stepId === 'landing')

  const applicant = {
    firstName: 'testFirst',
    lastName: 'nameLast',
    genderCode: 'M',
    heightFeet: 5,
    heightInches: 11,
    weight: 150,
    dateOfBirth: '01/01/1991',
    street: '123 fake street',
    city: 'Boston',
    state: 'MA',
    zip: '02199',
    email: 'test@example.com',
    emailConfirm: 'test@example.com',
    phone: '255-345-9999',
    occupation: 'Software Engineer',
    locationCode: 'Boston',
    questions: [
      {
        benCd: 'COMMON',
        requirementId: 13,
        requirementOptionCd: 'Asthma',
        requirementOptionUsageCd: stepConfig.usageCode,
        displayType: 'CHECKBOX',
        dataType: 'TEXT',
        optionName: 'Asthma',
        optionDescription: 'Asthma',
        amountValue: null,
        textValue: 'NO',
        dateValue: null,
        valueId: null,
        applicantType: 'EMPLOYEE',
        seqNum: 1,
        followUpRequirementId: 13,
        followUpRequirementOptionUsageCd: 'AsthmaFlUp',
        provisionSeqNum: 1,
        reqtOptSubGroupCd: 'DIAG_GRP',
        values: [],
      },
    ],
    type: {
      type: 'ee',
      code: 'EMPLOYEE',
    },
    seqNum: 1,
  }

  beforeEach(() => {
    global.fetch = jest.fn(() =>
      Promise.resolve({
        json: () => Promise.resolve([{ description: 'New York', code: 'NYC' }]),
      }),
    )
  })

  afterEach(() => {
    global.fetch.mockClear()
    delete global.fetch
  })

  const renderComponent = ({
    applicant,
    usageCode = stepConfig.usageCode,
    setRequirementsMet = () => false,
    onChangeSelection = () => {},
    onShowHealthHistoryDrawer = () => {},
  }) => {
    const ApplicantWrapper = ({ applicant, children }) => {
      const { updateEmployee } = useApplicantsDispatcher()
      useEffect(() => {
        updateEmployee(applicant)
      }, [applicant])

      return children
    }

    const StepHandlerWrapper = ({ children }) => {
      const [stepHandler, setStepHandler] = useState({})
      const onClickNext = stepHandler.onClickNext
      return <StepHandlerContext.Provider value={{ setStepHandler }}>{children}</StepHandlerContext.Provider>
    }

    const HookFormWrapper = ({ children }) => {
      const methods = useForm({
        mode: 'onTouched',
      })

      return <FormProvider {...methods}>{children}</FormProvider>
    }

    return render(
      <AppProvider>
        <ApplicantsProvider>
          <StepHandlerWrapper>
            <ApplicantWrapper applicant={applicant}>
              <HookFormWrapper>
                <RespiratoryLandingStep
                  applicant={applicant}
                  usageCode={usageCode}
                  setRequirementsMet={setRequirementsMet}
                  onChangeSelection={onChangeSelection}
                  onShowHealthHistoryDrawer={onShowHealthHistoryDrawer}
                />
              </HookFormWrapper>
            </ApplicantWrapper>
          </StepHandlerWrapper>
        </ApplicantsProvider>
      </AppProvider>,
    )
  }

  it('renders the respiratory landing step', async () => {
    await act(async () => renderComponent({ applicant }))

    await waitFor(() => {
      expect(
        screen.getByText(`You told us that ${applicant.firstName} has had a lung disorder or respiratory disease`, {
          exact: false,
        }),
      )
      expect(screen.getByLabelText('Asthma')).toBeInTheDocument()
    })
  })

  it('monitors checkbox changes for required fields', async () => {
    let isRequirementsMet = true

    const setRequirementsMet = (isMet) => {
      isRequirementsMet = isMet
      return isRequirementsMet
    }

    await act(async () => renderComponent({ applicant, setRequirementsMet }))

    await waitFor(() => {
      expect(screen.getByLabelText('Asthma', { checked: false }))
      fireEvent.click(screen.getByLabelText('Asthma'))
      expect(screen.getByLabelText('Asthma', { checked: true }))
      expect(isRequirementsMet).toBeTruthy()
    })
  })
})
