import { AppProvider } from '@/components/context/app.context'
import { ApplicantsProvider, useApplicantsDispatcher } from '@/components/context/Applicants.context'
import { StepHandlerContext } from '@/components/context/StepHandler.context'
import { HeartSteps } from '@/components/followUpQuestions/heartConditions/stepConfig'
import TestFollowUpStep from '@/components/followUpQuestions/heartConditions/steps/testFollowUp'
import { act, render, screen, waitFor } from '@testing-library/react'
import { useEffect, useState } from 'react'
import { FormProvider, useForm } from 'react-hook-form'
import { saveAnswersForTextValue } from '@/common/utils/api'
import { TST_GRP } from '@/common/enums/constant'

jest.mock('@/common/utils/api', () => ({
  saveAnswersForTextValue: jest.fn(),
}))
describe('TestFollowUpStep component', () => {
  const stepConfig = HeartSteps.steps.find((s) => s.stepId === 'TestFollowUp')
  const applicant = {
    firstName: 'testFirst',
    lastName: 'nameLast',
    genderCode: 'M',
    heightFeet: 5,
    heightInches: 11,
    weight: 150,
    dateOfBirth: '01/01/1991',
    street: '123 fake street',
    city: 'Boston',
    state: 'MA',
    zip: '02199',
    email: 'test@example.com',
    emailConfirm: 'test@example.com',
    phone: '255-345-9999',
    occupation: 'Software Engineer',
    locationCode: 'Boston',
    questions: [
      {
        benCd: 'COMMON',
        requirementId: 12,
        requirementOptionCd: 'EKG_Test',
        requirementOptionUsageCd: stepConfig.usageCode,
        displayType: 'CHECKBOX',
        dataType: 'TEXT',
        optionName: 'EKG/ECG Test',
        optionDescription: 'EKG/ECG Test Description',
        amountValue: null,
        textValue: 'YES',
        dateValue: null,
        valueId: null,
        applicantType: 'EMPLOYEE',
        seqNum: 1,
        provisionSeqNum: 1,
        values: [],
      },
      {
        benCd: 'COMMON',
        requirementId: 13,
        requirementOptionCd: 'Other_Test',
        requirementOptionUsageCd: stepConfig.usageCode,
        displayType: 'TEXTFIELD',
        dataType: 'TEXT',
        optionName: 'Other Test Results',
        optionDescription: 'Other Test Results Description',
        amountValue: null,
        textValue: '',
        dateValue: null,
        valueId: null,
        applicantType: 'EMPLOYEE',
        seqNum: 2,
        provisionSeqNum: 1,
        reqtOptSubGroupCd: TST_GRP,
        values: [],
      },
    ],
    type: {
      type: 'ee',
      code: 'EMPLOYEE',
    },
    seqNum: 1,
  }
  beforeEach(() => {
    jest.clearAllMocks()
    saveAnswersForTextValue.mockResolvedValue(true)
  })
  const renderComponent = ({ applicant, usageCode = stepConfig.usageCode, onChangeSelection = jest.fn() }) => {
    const ApplicantWrapper = ({ applicant, children }) => {
      const { updateEmployee } = useApplicantsDispatcher()
      useEffect(() => {
        updateEmployee(applicant)
      }, [applicant])
      return children
    }
    const StepHandlerWrapper = ({ children }) => {
      const [stepHandler, setStepHandler] = useState({})
      return <StepHandlerContext.Provider value={{ setStepHandler }}>{children}</StepHandlerContext.Provider>
    }
    const HookFormWrapper = ({ children }) => {
      const methods = useForm({
        mode: 'onTouched',
      })
      return <FormProvider {...methods}>{children}</FormProvider>
    }
    return render(
      <AppProvider>
        <ApplicantsProvider>
          <StepHandlerWrapper>
            <ApplicantWrapper applicant={applicant}>
              <HookFormWrapper>
                <TestFollowUpStep applicant={applicant} usageCode={usageCode} onChangeSelection={onChangeSelection} />
              </HookFormWrapper>
            </ApplicantWrapper>
          </StepHandlerWrapper>
        </ApplicantsProvider>
      </AppProvider>,
    )
  }
  it('renders the test follow-up step correctly', async () => {
    await act(async () => renderComponent({ applicant }))
    await waitFor(() => {
      expect(
        screen.getByText(`You told us that ${applicant.firstName} has had an electrocardiogram (EKG/ECG)`, {
          exact: false,
        }),
      ).toBeInTheDocument()

      expect(screen.getByText('EKG/ECG information')).toBeInTheDocument()
    })
  })
  it('handles question changes correctly', async () => {
    const onChangeSelection = jest.fn()
    await act(async () =>
      renderComponent({
        applicant,
        onChangeSelection,
      }),
    )
    await waitFor(() => {
      expect(onChangeSelection).toHaveBeenCalled()
    })
  })
})
