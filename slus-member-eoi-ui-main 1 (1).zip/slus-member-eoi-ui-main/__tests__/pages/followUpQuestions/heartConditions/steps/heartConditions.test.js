import { AppProvider } from '@/components/context/app.context'
import { ApplicantsProvider, useApplicantsDispatcher } from '@/components/context/Applicants.context'
import { StepHandlerContext } from '@/components/context/StepHandler.context'
import { HeartSteps } from '@/components/followUpQuestions/heartConditions/stepConfig'
import HeartConditionsLandingStep from '@/components/followUpQuestions/heartConditions/steps/heartConditions'
import { act, fireEvent, render, screen, waitFor } from '@testing-library/react'
import { useEffect, useState } from 'react'
import { FormProvider, useForm } from 'react-hook-form'

describe('HeartConditionsLandingStep component', () => {
  const stepConfig = HeartSteps.steps.find((s) => s.stepId === 'landing')

  const applicant = {
    firstName: 'testFirst',
    lastName: 'nameLast',
    genderCode: 'M',
    heightFeet: 5,
    heightInches: 11,
    weight: 150,
    dateOfBirth: '01/01/1991',
    street: '123 fake street',
    city: 'Boston',
    state: 'MA',
    zip: '02199',
    email: 'test@example.com',
    emailConfirm: 'test@example.com',
    phone: '255-345-9999',
    occupation: 'Software Engineer',
    locationCode: 'Boston',
    questions: [
      {
        benCd: 'COMMON',
        requirementId: 11,
        requirementOptionCd: 'Arrhythmia',
        requirementOptionUsageCd: stepConfig.usageCode,
        displayType: 'CHECKBOX',
        dataType: 'TEXT',
        optionName: 'Arrhythmia',
        optionDescription: 'Arrhythmia',
        amountValue: null,
        textValue: 'NO',
        dateValue: null,
        valueId: null,
        applicantType: 'EMPLOYEE',
        seqNum: 1,
        followUpRequirementId: 11,
        followUpRequirementOptionUsageCd: 'ArrhythmiaFolUp',
        provisionSeqNum: 1,
        reqtOptSubGroupCd: 'DIAG_GRP',
        values: [],
      },
    ],
    type: {
      type: 'ee',
      code: 'EMPLOYEE',
    },
    seqNum: 1,
  }

  beforeEach(() => {
    global.fetch = jest.fn(() =>
      Promise.resolve({
        json: () => Promise.resolve([{ description: 'New York', code: 'NYC' }]),
      }),
    )
  })

  afterEach(() => {
    global.fetch.mockClear()
    delete global.fetch
  })

  const renderComponent = ({
    applicant,
    usageCode = stepConfig.usageCode,
    setRequirementsMet = () => false,
    onChangeSelection = () => {},
    onShowHealthHistoryDrawer = () => {},
  }) => {
    const ApplicantWrapper = ({ applicant, children }) => {
      const { updateEmployee } = useApplicantsDispatcher()
      useEffect(() => {
        updateEmployee(applicant)
      }, [applicant])

      return children
    }

    const StepHandlerWrapper = ({ children }) => {
      const [stepHandler, setStepHandler] = useState({})
      const onClickNext = stepHandler.onClickNext
      return <StepHandlerContext.Provider value={{ setStepHandler }}>{children}</StepHandlerContext.Provider>
    }

    const HookFormWrapper = ({ children }) => {
      const methods = useForm({
        mode: 'onTouched',
      })

      return <FormProvider {...methods}>{children}</FormProvider>
    }

    return render(
      <AppProvider>
        <ApplicantsProvider>
          <StepHandlerWrapper>
            <ApplicantWrapper applicant={applicant}>
              <HookFormWrapper>
                <HeartConditionsLandingStep
                  applicant={applicant}
                  usageCode={usageCode}
                  setRequirementsMet={setRequirementsMet}
                  onChangeSelection={onChangeSelection}
                  onShowHealthHistoryDrawer={onShowHealthHistoryDrawer}
                />
              </HookFormWrapper>
            </ApplicantWrapper>
          </StepHandlerWrapper>
        </ApplicantsProvider>
      </AppProvider>,
    )
  }

  it('renders the heart conditions landing step', async () => {
    await act(async () => renderComponent({ applicant }))

    await waitFor(() => {
      expect(screen.getByText(`You told us that ${applicant.firstName} has experienced`, { exact: false }))
      expect(screen.getByLabelText('Arrhythmia')).toBeInTheDocument()
    })
  })

  it('monitors checkbox changes for required fields', async () => {
    let isRequirementsMet = true

    const setRequirementsMet = (isMet) => {
      isRequirementsMet = isMet
      return isRequirementsMet
    }

    await act(async () => renderComponent({ applicant, setRequirementsMet }))

    await waitFor(() => {
      expect(screen.getByLabelText('Arrhythmia', { checked: false }))
      fireEvent.click(screen.getByLabelText('Arrhythmia'))
      expect(screen.getByLabelText('Arrhythmia', { checked: true }))
      expect(isRequirementsMet).toBeTruthy()
    })
  })
})
