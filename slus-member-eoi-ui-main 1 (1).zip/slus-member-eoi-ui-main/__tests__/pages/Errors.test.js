import { act, render, screen, waitFor } from '@testing-library/react'
import Sunlife404 from '@/app/not-found'
import Sunlife500 from '@/app/error'
import { AppProvider } from '@/components/context/app.context'

describe('Error pages', () => {
  it('renders a 404 page', async () => {
    await act(async () => {
      render(
        <AppProvider defaultValues={{}}>
          <Sunlife404 />
        </AppProvider>,
      )
    })

    const heading = 'Oops, there’s a cloud. Let’s make it sunny again.'
    const pageMoved = 'The page you are trying to reach might have been moved, updated or deleted.'
    const alternatePage = 'Are one of these pages the one you’re looking for?'

    await waitFor(() => {
      expect(screen.queryByText(heading)).toBeInTheDocument()
      expect(screen.queryByText(pageMoved)).toBeInTheDocument()
      expect(screen.queryByText(alternatePage)).toBeInTheDocument()
      expect(screen.getAllByRole('link').length).toBeGreaterThan(0)
    })
  })

  it('renders a 500 page', async () => {
    await act(async () => {
      render(
        <AppProvider defaultValues={{}}>
          <Sunlife500 />
        </AppProvider>,
      )
    })

    const titleText = 'Technical difficulties'
    const text1 =
      'Details are currently unavailable but we have logged this event. Please try again later or contact us at 800-247-6875'
    const text2 = 'Or, you may have been wanting to reach one of these pages:'

    await waitFor(() => {
      expect(screen.queryByText(titleText)).toBeInTheDocument()
      expect(screen.queryByText(text1)).toBeInTheDocument()
      expect(screen.queryByText(text2)).toBeInTheDocument()
      expect(screen.getAllByRole('link').length).toBeGreaterThan(0)
    })
  })
})
