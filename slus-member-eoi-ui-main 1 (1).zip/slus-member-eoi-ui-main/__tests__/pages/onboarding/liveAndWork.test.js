import { act, render, screen, waitFor } from '@testing-library/react'
import { StepHandlerContext } from '@/components/context/StepHandler.context'
import { AppProvider } from '@/components/context/app.context'
import { ApplicantsProvider, useApplicantsDispatcher } from '@/components/context/Applicants.context'
import LiveAndWork from '@/components/onboarding/liveAndWork'
import { useEffect, useState } from 'react'

describe('LiveAndWork component', () => {
  const employee = {
    street: '123 Main St',
    city: 'Anytown',
    state: 'NY',
    zip: '12345',
    email: 'test@example.com',
    emailConfirm: 'test@example.com',
    phone: '123-456-7890',
    occupation: 'Software Engineer',
    locationCode: 'NYC',
  }

  beforeEach(() => {
    global.fetch = jest.fn(() =>
      Promise.resolve({
        json: () => Promise.resolve([{ description: 'New York', code: 'NYC' }]),
      }),
    )
  })

  afterEach(() => {
    global.fetch.mockClear()
    delete global.fetch
  })

  const UpdateContext = ({ employee, children }) => {
    const { updateEmployee } = useApplicantsDispatcher()
    useEffect(() => {
      updateEmployee(employee)
    }, [employee])

    return children
  }

  it('renders form fields correctly', async () => {
    await act(async () => {
      render(
        <AppProvider>
          <ApplicantsProvider>
            <LiveAndWork />
          </ApplicantsProvider>
        </AppProvider>,
      )
    })

    await waitFor(() => {
      expect(screen.getByLabelText(/Street address/i)).toBeInTheDocument()
      expect(screen.getByLabelText(/City/i)).toBeInTheDocument()
      expect(screen.getByLabelText(/Zip code/i)).toBeInTheDocument()
      expect(screen.getByLabelText(/^Email$/i)).toBeInTheDocument()
      expect(screen.getByLabelText(/Confirm Email/i)).toBeInTheDocument()
      expect(screen.getByLabelText(/Primary phone number/i)).toBeInTheDocument()
      expect(screen.getByLabelText(/Occupation/i)).toBeInTheDocument()
    })
  })

  it('renders form fields correctly with values', async () => {
    await act(async () => {
      render(
        <AppProvider>
          <ApplicantsProvider>
            <UpdateContext employee={employee}>
              <LiveAndWork />
            </UpdateContext>
          </ApplicantsProvider>
        </AppProvider>,
      )
    })

    await waitFor(() => {
      expect(screen.getByLabelText(/Street address/i)).toHaveValue(employee.street)
      expect(screen.getByLabelText(/City/i)).toHaveValue(employee.city)
      expect(screen.getByLabelText(/Zip code/i)).toHaveValue(employee.zip)
      expect(screen.getByLabelText(/^Email$/i)).toHaveValue(employee.email)
      expect(screen.getByLabelText(/Confirm Email/i)).toHaveValue(employee.emailConfirm)
      expect(screen.getByLabelText(/Primary phone number/i)).toHaveValue(employee.phone)
      expect(screen.getByLabelText(/Occupation/i)).toHaveValue(employee.occupation)
    })
  })

  it('triggers onClickNext and makes API call', async () => {
    let onClickNext

    const MockStepHandlerProvider = ({ children }) => {
      const [stepHandler, setStepHandler] = useState({})
      onClickNext = stepHandler.onClickNext
      return <StepHandlerContext.Provider value={{ setStepHandler }}>{children}</StepHandlerContext.Provider>
    }

    await act(async () => {
      render(
        <AppProvider>
          <ApplicantsProvider>
            <MockStepHandlerProvider>
              <UpdateContext employee={employee}>
                <LiveAndWork />
              </UpdateContext>
            </MockStepHandlerProvider>
          </ApplicantsProvider>
        </AppProvider>,
      )
    })

    await act(async () => {
      await onClickNext()
    })

    await waitFor(() => {
      expect(global.fetch).toHaveBeenCalledWith(
        `${process.env.NEXT_PUBLIC_BASE_URL}/applicants/liveAndWork`,
        expect.objectContaining({
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            streetAddress: employee.street,
            city: employee.city,
            state: employee.state,
            zipCode: employee.zip,
            email: employee.email,
            phoneNumber: employee.phone,
            occupation: employee.occupation,
            location: employee.locationCode,
          }),
        }),
      )
    })
  })

  it('shows error message and does not submit form with empty field', async () => {
    let onClickNext

    const MockStepHandlerProvider = ({ children }) => {
      const [stepHandler, setStepHandler] = useState({})
      onClickNext = stepHandler.onClickNext
      return <StepHandlerContext.Provider value={{ setStepHandler }}>{children}</StepHandlerContext.Provider>
    }

    await act(async () => {
      // Set street address to empty string to trigger validation
      employee.street = ''
      render(
        <AppProvider>
          <ApplicantsProvider>
            <MockStepHandlerProvider>
              <UpdateContext employee={employee}>
                <LiveAndWork />
              </UpdateContext>
            </MockStepHandlerProvider>
          </ApplicantsProvider>
        </AppProvider>,
      )
    })

    await act(async () => {
      await onClickNext()
    })

    await waitFor(() => {
      expect(global.fetch).not.toHaveBeenCalledWith(
        expect.stringContaining('/applicants/liveAndWork'),
        expect.any(Object),
      )
      expect(screen.getByText(/This field is required/i)).toBeInTheDocument()
    })
  })
})
