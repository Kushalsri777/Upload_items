---
tags:
---
# slus-member-eoi-ui : Getting Started

> **TODO: A brief description of the application**

## Introduction

### Summary

**TODO: A more in-depth overview of the application**

### Prerequisites

**TODO: List any steps required prior to continuing (e.g., client software downloads)**

## Configuration

### Authentication

**TODO: If applicable, list steps for establishing client credentials**

### Authorization

**TODO: If applicable, list authorization policies and role assignment**

## Accessing

### User Interface

**TODO: Provide links to application UI**

### API

**TODO: Provide link to application API**

**TODO: Link to Backstage API Doc**

## Key Concepts

There are certain concepts which are central to slus-member-eoi-ui design and functionality. Having a base understanding of each will make administering, configuring, and operating slus-member-eoi-ui easier.

- Kubernetes - https://kubernetes.io/
- Semantic Versioning - https://semver.org
- Conventional Commits - https://www.conventionalcommits.org/en/v1.0.0/#summary
- **TODO: provide list of concepts and reference links**
