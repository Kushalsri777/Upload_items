---
tags:
---
# slus-member-eoi-ui

> **TODO: Application description**

## Introduction and Goals

### Requirements

The primary purpose of Holocron is to 

#### Main Features

- Feature 1
- Feature 2

#### Quality Goals

| Nr.|   Quality   | Motivation                                                                |
| :- | :---------- | :------------------------------------------------------------------------ |
| 1  | Reliability | Collecting logs must be highly reliable due to the nature of the workload.|
| 2  | Security    | The assets within the system should be treated with a high level of sensitivity.|
| 3  | Durability  | Consumers should have a high level of assurance in the durability of the assets within the system.|
| 4  | Usability   | Using the system should be intuitive for consumers, with minimal effort to find what they are looking for.|

#### Stakeholders

| Role/Name          |   Goal/Boundaries                                                       |
| :----------------- | :---------------------------------------------------------------------- |
| Role 1             | Goal 1 |
| Role 2             | Goal 2 |
| Role 3             | Goal 3 |

## Architecture Constraints

The few constraints on this service are reflected in the final solution. This sections shows them and if applicable, their motivation.

### Technical Constraints

|     |  Constraint  | Background and/or Motivation                                              |
| :-- | :----------- | :------------------------------------------------------------------------ |
| TC1 | Constraint 1 | Describe constraint |
| TC2 | Constraint 2 | Describe constraint |
| TC3 | Constraint 3 | Describe constraint |

### Organizational Constraints

|     |   Constraint   | Background and/or Motivation                                              |
| :-- | :------------- | :------------------------------------------------------------------------ |
| OC1 | Team 1         | Describe constraint |
| OC2 | Team 2         | Describe constraint |

## System Scope and Context

This chapter describes the environment and context of Holocron: Who uses the system and on which other system does Galileo depend.

### Business Context

**TODO: include business context diagram**

#### Component 1

**TODO: Describe Component 1**

#### Component 2

**TODO: Describe Component 2**

### Technical Context

**TODO: include technical context diagram**

#### Component 1

**TODO: Describe Component 1**

#### Component 2

**TODO: Describe Component 2**

## Solution Strategy

### Deployment

### Configuration

#### Authentication Methods

#### Roles

### Runtime

#### slus-member-eoi-ui service

#### slus-member-eoi-ui pods

#### slus-member-eoi-ui cronjobs

#### slus-member-eoi-ui volumes

