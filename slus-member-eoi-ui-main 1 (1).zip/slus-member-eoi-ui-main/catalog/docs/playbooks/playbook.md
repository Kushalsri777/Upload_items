---
tags:
---

# slus-member-eoi-ui

!!! abstract
    slus-member-eoi-ui[^1] is **TODO: insert brief summary of application**

## Maintenance

### Configuration

**TODO: document any configuration required for the application to function**

### System Updates & Upgrades

**TODO: document process for version upgrades**

### Feature Toggles

**TODO: document any application feature toggles**

## Security

### User / Group Management

**TODO: if applicable, define process for user to gain access to application**

### Secrets


## Troubleshooting

### Scenario 1

**TODO: document scenarios and how to address**

[^1]: [slus-member-eoi-ui Architecture Documentation]
[^2]: [slus-member-eoi-ui Service Level Objectives]

  [slus-member-eoi-ui Architecture Documentation]: ../../arch-docs
  [slus-member-eoi-ui Service Level Objectives]: ../../slo

[VAULT]: <https://holocron.sso.sunlifeus.cloud/ui/vault/secrets//list/dxp-member-services/slus-member-eoi-ui/>
