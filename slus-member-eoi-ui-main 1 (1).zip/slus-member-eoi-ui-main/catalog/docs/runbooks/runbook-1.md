---
tags:
---

# Manual Activity

**TODO: insert brief summary of manual activity**

## Prerequisites

**TODO: Overview of prerequisites**

1. Install tools
1. Environment Variables
1. Other

## Steps

**TODO: Overview of steps**

1. Step 1
1. Step 2
1. Step 3

## Verfication Steps

**TODO: Overview of verification steps**

1. Step 1
1. Step 2
1. Step 3
