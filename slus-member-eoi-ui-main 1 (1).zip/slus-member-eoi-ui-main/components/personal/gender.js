import { Controller, useFormContext } from 'react-hook-form'
import { HelperText, Radio } from '@/components/helios-components'
import Form from 'react-bootstrap/Form'
import styles from './gender.module.css'

function Gender({ label = 'Sex at birth', isViewOnly = false, isRequired = true }) {
  const { control } = useFormContext()
  return (
    <div className="mb-2" data-cy="radio_gender_group">
      <Controller
        control={control}
        name="genderCode"
        rules={{
          required: {
            value: isRequired,
            message: 'Please make a selection',
          },
        }}
        render={({ field, fieldState }) => {
          const { ...fields } = field
          return (
            <>
              <Form.Group>
                <Form.Label className={styles.label}>{label}</Form.Label>
                <div>
                  <Radio
                    {...fields}
                    id="gender-radio-female"
                    label="Female"
                    value="F"
                    name="genderCode"
                    isInvalid={fieldState.invalid}
                    checked={field.value === 'F'}
                    data-cy="radio_gender_female"
                    inline
                    key={1}
                    disabled={isViewOnly}
                  />
                  <Radio
                    {...fields}
                    id="gender-radio-male"
                    label="Male"
                    value="M"
                    name="genderCode"
                    checked={field.value === 'M'}
                    data-cy="radio_gender_male"
                    inline
                    key={2}
                    disabled={isViewOnly}
                  />
                </div>
                {fieldState.invalid && (
                  <div>
                    <HelperText id={`gender-error`} className={styles.errorMessage} error>
                      {fieldState.error.message}
                    </HelperText>
                  </div>
                )}
              </Form.Group>
            </>
          )
        }}
      />
    </div>
  )
}

export default Gender
