import Name from './name.js'

const Fullname = ({ controls, isViewOnly = false, validatePlaceholder = false }) => {
  const [nameA, nameB] = controls

  return (
    <>
      <Name {...nameA} isViewOnly={isViewOnly} validatePlaceholder={validatePlaceholder} />
      <Name {...nameB} isViewOnly={isViewOnly} validatePlaceholder={validatePlaceholder} />
    </>
  )
}

export default Fullname
