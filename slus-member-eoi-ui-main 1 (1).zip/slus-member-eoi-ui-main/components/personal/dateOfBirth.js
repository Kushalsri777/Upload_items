import { useState, useEffect } from 'react'
import moment from 'moment'
import { useFormContext, Controller } from 'react-hook-form'
import InputMask from 'react-input-mask'
import { TextField } from '@/components/helios-components'
import { REQUIRED_FIELDS } from '@/common/enums/constant'
import { DATE_OF_BIRTH } from '@/common/enums/regex'

const {
  MM_DD_YYYY: { regex, pattern },
} = DATE_OF_BIRTH
const NAME = 'dateOfBirth'

const isMatchPattern = (dateString) => {
  return regex.test(dateString)
}

const getTimeToNow = (dateString) => {
  if (isMatchPattern(dateString)) {
    const dateMoment = moment(dateString, pattern)
    return `${dateMoment.toNow(true)} old`
  }
  return ''
}

const isDateValid = (dateString, minAge, maxAge) => {
  if (isMatchPattern(dateString)) {
    const dateMoment = moment(dateString, pattern)
    const maximumMoment = moment().subtract(minAge, 'years')
    const minimumMoment = moment().subtract(maxAge, 'years')
    return dateMoment.isBetween(minimumMoment, maximumMoment)
  }
  return false
}

function DateOfBirth({ label = 'Date of birth (MM/DD/YYYY)', isViewOnly = false, minAge = 0, maxAge = 150 }) {
  const { control, watch } = useFormContext()
  const dateOfBirth = watch(NAME)
  const [helperText, setHelperText] = useState('')

  useEffect(() => {
    handleOnChangeDateOfBirth(dateOfBirth)
  }, [dateOfBirth])

  const handleOnChangeDateOfBirth = (dateString) => {
    setHelperText(getTimeToNow(dateString))
  }

  const validateDateOfBirth = (dateString) => {
    if (isDateValid(dateString, minAge, maxAge)) {
      return true
    }

    if (minAge === 0) {
      return 'Please enter a valid date of birth'
    }
    return `You must be at least ${minAge} years old to apply`
  }

  return (
    <div className="w-full mb-3">
      <Controller
        control={control}
        name="dateOfBirth"
        render={({ field, fieldState }) => {
          const { ...fields } = field
          return (
            <InputMask
              {...fields}
              mask="99/99/9999"
              maskChar={null}
              formatChars={{ 9: '[0-9]' }}
              alwaysShowMask={false}
              permanents={[2, 5]}
              disabled={isViewOnly}>
              {(inputProps) => (
                <TextField
                  {...inputProps}
                  id={field.name}
                  error={fieldState.invalid}
                  helperText={fieldState.error?.message || helperText}
                  label={label}
                  disabled={isViewOnly}
                />
              )}
            </InputMask>
          )
        }}
        rules={{
          required: {
            value: true,
            message: REQUIRED_FIELDS,
          },
          pattern: {
            value: DATE_OF_BIRTH.MM_DD_YYYY.regex,
            message: DATE_OF_BIRTH.MM_DD_YYYY.message,
          },
          validate: validateDateOfBirth,
        }}
      />
    </div>
  )
}

export default DateOfBirth
