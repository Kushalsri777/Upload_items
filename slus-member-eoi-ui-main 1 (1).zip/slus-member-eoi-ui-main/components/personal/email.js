import { useFormContext, Controller } from 'react-hook-form'
import { TextField } from '@/components/helios-components'
import { EMAIL } from '@/common/enums/regex'

function Email({ label = 'Email address (optional)', controllerName = 'email', isViewOnly = false }) {
  const { control } = useFormContext()

  return (
    <div className="w-full mb-3">
      <Controller
        control={control}
        name={controllerName}
        render={({ field, fieldState }) => {
          const { ...fields } = field
          return (
            <TextField
              {...fields}
              icon="email"
              iconPosition="after"
              id={field.name}
              label={label}
              error={fieldState.invalid}
              helperText={fieldState?.error?.message || 'Optional'}
              disabled={isViewOnly}
            />
          )
        }}
        rules={{
          pattern: {
            value: EMAIL.regex,
            message: EMAIL.message,
          },
        }}
      />
    </div>
  )
}

export default Email
