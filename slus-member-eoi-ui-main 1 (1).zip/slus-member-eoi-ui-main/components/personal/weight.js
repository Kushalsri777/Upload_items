import { useFormContext, Controller } from 'react-hook-form'
import { TextField } from '@/components/helios-components'
import { WEIGHT } from '@/common/enums/regex'
import { REQUIRED_FIELDS } from '@/common/enums/constant'

function Weight({ name = 'weight', isViewOnly = false }) {
  const { control } = useFormContext()

  return (
    <div className="mb-4">
      <Controller
        control={control}
        name={name}
        render={({ field, fieldState }) => {
          const { ...fields } = field
          return (
            <TextField
              {...fields}
              id={field.name}
              label="Weight (lbs)"
              error={fieldState.invalid}
              helperText={fieldState.error?.message}
              disabled={isViewOnly}
            />
          )
        }}
        rules={{
          required: {
            value: true,
            message: REQUIRED_FIELDS,
          },
          pattern: {
            value: WEIGHT.LBS.regex,
            message: WEIGHT.LBS.message,
          },
        }}
      />
    </div>
  )
}

export default Weight
