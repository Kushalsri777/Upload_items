import { useFormContext, Controller } from 'react-hook-form'
import { TextField } from '@/components/helios-components'
import { HEIGHT } from '@/common/enums/regex'
import { REQUIRED_FIELDS } from '@/common/enums/constant'

function Height({
  title = 'Height',
  labels = ['Feet', 'Inches'],
  names = ['heightFeet', 'heightInches'],
  isViewOnly = false,
}) {
  const { control } = useFormContext()

  return (
    <div className="mb-4">
      <div className="mb-2">
        <span>{title}</span>
      </div>
      <div className="row">
        <div className="col-6">
          <Controller
            control={control}
            name={names[0]}
            render={({ field, fieldState }) => {
              const { ...fields } = field
              return (
                <TextField
                  {...fields}
                  id={field.name}
                  label={labels[0]}
                  error={fieldState.invalid}
                  helperText={fieldState.error?.message}
                  disabled={isViewOnly}
                />
              )
            }}
            rules={{
              required: {
                value: true,
                message: REQUIRED_FIELDS,
              },
              pattern: {
                value: HEIGHT.FEET.regex,
                message: HEIGHT.FEET.message,
              },
            }}
          />
        </div>
        <div className="col-6">
          <Controller
            control={control}
            name={names[1]}
            render={({ field, fieldState }) => {
              const { ...fields } = field
              return (
                <TextField
                  {...fields}
                  id={field.name}
                  label={labels[1]}
                  error={fieldState.invalid}
                  helperText={fieldState.error?.message}
                  disabled={isViewOnly}
                />
              )
            }}
            rules={{
              required: {
                value: true,
                message: REQUIRED_FIELDS,
              },

              pattern: {
                value: HEIGHT.INCHES.regex,
                message: HEIGHT.INCHES.message,
              },
            }}
          />
        </div>
      </div>
    </div>
  )
}

export default Height
