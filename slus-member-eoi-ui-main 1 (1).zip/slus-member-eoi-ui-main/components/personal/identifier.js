import { useFormContext, Controller } from 'react-hook-form'
import { TextField } from '@/components/helios-components'
import { SSN } from '@/common/enums/loginMethod'

function Identifier({ loginMethod = SSN, isViewOnly = true }) {
  const { control } = useFormContext()

  return (
    <>
      <Controller
        control={control}
        name="identifier"
        render={({ field }) => {
          const { ...fields } = field
          return <TextField {...fields} id={field.name} label={loginMethod.label} disabled={isViewOnly} />
        }}
      />
    </>
  )
}

export default Identifier
