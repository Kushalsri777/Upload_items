import { Controller, useFormContext } from 'react-hook-form'
import { TextField } from '@/components/helios-components'
import { NAME_FIELDS_REGEX } from '@/common/enums/regex'
import { INVALID_CHARACTERS, REQUIRED_FIELDS } from '@/common/enums/constant'
import clsx from 'clsx'
import demographicsViewOnlyStyles from '@/components/demographics.module.css'
import { validateEmptyString } from '@/common/utils/validation'

const Name = ({
  controllerName = '',
  label = 'Name',
  requiredErrorMessage = REQUIRED_FIELDS,
  isViewOnly = false,
  validatePlaceholder = false,
}) => {
  const { control } = useFormContext()

  const validateNameWithPlaceHolder = (name) => {
    if (validatePlaceholder) {
      const lowerCaseName = name.toLowerCase()
      if (
        name &&
        (lowerCaseName.includes('enter spouse first name') ||
          lowerCaseName.includes('enter spouse last name') ||
          lowerCaseName.includes('enter child first name') ||
          lowerCaseName.includes('enter child last name'))
      ) {
        return REQUIRED_FIELDS
      }
    }
    return true
  }

  return (
    <div className={clsx('mb-4', { [demographicsViewOnlyStyles.viewOnly]: isViewOnly })}>
      <Controller
        render={({ field, fieldState }) => {
          const { ref, ...fields } = field
          return (
            <TextField
              {...fields}
              id={field.name}
              label={label}
              error={fieldState.invalid}
              helperText={fieldState.error?.message}
              disabled={isViewOnly}
            />
          )
        }}
        rules={{
          required: {
            value: true,
            message: requiredErrorMessage,
          },
          pattern: {
            value: NAME_FIELDS_REGEX,
            message: INVALID_CHARACTERS,
          },
          validate: {
            validateEmptyString,
            validateNameWithPlaceHolder,
          },
        }}
        control={control}
        name={controllerName}
      />
    </div>
  )
}

export default Name
