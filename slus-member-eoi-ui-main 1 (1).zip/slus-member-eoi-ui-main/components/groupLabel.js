import styles from './groupLabel.module.css'

function GroupLabel({ label }) {
  return (
    <div className={styles.groupLabel}>
      <span>{label}</span>
    </div>
  )
}

export default GroupLabel
