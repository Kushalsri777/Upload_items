import { usePathname } from 'next/navigation'
import { Header } from '@/components/helios-components'
import { useRouter } from 'next/navigation'

const BASE_PATH = process.env.NEXT_PUBLIC_BASE_PATH || ''

function NavBarHelios({ disableNavManu }) {
  const pathname = usePathname()
  const router = useRouter()

  const mainNavItems = [
    {
      active: '/' === pathname,
      href: `${BASE_PATH}/`,
      label: 'EOI Home',
    },
  ]

  if ('/dashboard' === pathname || '/submitted' === pathname) {
    mainNavItems.push({
      active: '/dashboard' === pathname,
      href: '#',
      label: 'Application',
      onClick: () => {
        router.push('/onboarding')
      },
    })
  }

  if ('/dashboard/acknowledge' === pathname) {
    mainNavItems.length = 0
  }

  if ('/electronic-consent' === pathname) {
    mainNavItems.length = 0
  }

  return (
    <>
      <Header
        logos={[
          {
            href: `${BASE_PATH}/`,
            imageAlt: 'Sun Life',
            imageSrc: `${BASE_PATH}/images/SunLifeLogo.svg`,
            type: 'LEFT',
          },

          {
            href: `${BASE_PATH}/`,
            imageAlt: 'Sun Life',
            imageSrc: `${BASE_PATH}/images/SunLifeLogo.svg`,
            type: 'MOBILE',
          },
        ]}
        mainNavItems={disableNavManu ? null : mainNavItems}
        menuCloseButtonLabel="Close menu"
        menuToggleButtonLabel="Open menu"
        skipLinks={[]}
        utilityNavItems={[]}
      />
    </>
  )
}

export default NavBarHelios
