import { useFormContext, Controller } from 'react-hook-form'
import { Dropdown, TextField } from '@/components/helios-components'
import GroupLabel from './groupLabel'
import { NAME_FIELDS_REGEX } from '@/common/enums/regex'
import { useContext, useEffect } from 'react'
import { AppContext } from '@/components/context/app.context'
import { INVALID_CHARACTERS, REQUIRED_FIELDS } from '@/common/enums/constant'
import clsx from 'clsx'
import demographicsViewOnlyStyles from './demographics.module.css'

function Occupation({ isViewOnly = false }) {
  const { locations, updateLocations } = useContext(AppContext)
  const { control, setValue } = useFormContext()
  const onLocationChange = (selection) => {
    setValue('applicant.locationCode', selection.option.value, { shouldValidate: true })
  }

  useEffect(() => {
    const fetchLocations = async () => {
      const url = `${process.env.NEXT_PUBLIC_BASE_URL}/locations`
      const response = await fetch(url, {
        method: 'GET',
      })
      const responseValue = await response.json()
      const locationTransformed = responseValue.map((location) => {
        return {
          label: location.description,
          value: location.code,
        }
      })
      updateLocations(locationTransformed)
    }
    if (locations?.length === 0) {
      fetchLocations().catch(console.error)
    }
  }, [locations?.length, updateLocations])

  return (
    <>
      <div className="mb-5">
        <GroupLabel label="Occupation" />
        <div className={clsx('mb-4', { [demographicsViewOnlyStyles.viewOnly]: isViewOnly })}>
          <Controller
            render={({ field, fieldState }) => {
              const { ref, ...fields } = field
              return (
                <TextField
                  {...fields}
                  id={field.name}
                  label="Occupation"
                  error={fieldState.invalid}
                  helperText={fieldState.error?.message}
                  disabled={isViewOnly}
                />
              )
            }}
            rules={{
              required: {
                value: true,
                message: REQUIRED_FIELDS,
              },
              pattern: {
                value: NAME_FIELDS_REGEX,
                message: INVALID_CHARACTERS,
              },
            }}
            control={control}
            name="applicant.employeeOccupation"
          />
        </div>
        <div
          className={clsx('mb-4', { [demographicsViewOnlyStyles.viewOnly]: isViewOnly })}
          data-cy="location_dropdown">
          <Controller
            render={({ field, fieldState }) => {
              const { ref, ...fields } = field
              return (
                <Dropdown
                  {...fields}
                  id={field.name}
                  label="Location"
                  onChange={onLocationChange}
                  options={locations}
                  selected={field.value}
                  placeholder=""
                  error={fieldState.invalid}
                  helperText={fieldState.error?.message}
                  disabled={isViewOnly}
                />
              )
            }}
            rules={{
              required: {
                value: true,
                message: REQUIRED_FIELDS,
              },
            }}
            control={control}
            name="applicant.locationCode"
          />
        </div>
      </div>
    </>
  )
}

export default Occupation
