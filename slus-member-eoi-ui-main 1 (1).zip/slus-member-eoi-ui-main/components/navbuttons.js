import { Row, Col } from 'react-bootstrap'
import clsx from 'clsx'
import { Button } from '@/components/helios-components'
import styles from './navbuttons.module.css'

function NavButtons({
  labelSecondary = 'Back',
  labelPrimary = 'Next',
  onClickSecondary,
  onClickPrimary,
  disableSecondary = false,
  disablePrimary = false,
  primaryColClassName = '',
  secondaryColClassName = '',
  primarySpinning,
  ...rest
}) {
  return (
    <>
      <Row xs={1} sm={2} {...rest}>
        <Col className={clsx('col-sm-4 mb-4', secondaryColClassName)}>
          <Button variant="secondary" onClick={onClickSecondary} disabled={disableSecondary}>
            {labelSecondary}
          </Button>
        </Col>
        <Col className={clsx('col-sm-8', styles.bottomGap, primaryColClassName)}>
          <div className={clsx({ hidden: primarySpinning })}>
            <Button variant="primary" onClick={onClickPrimary} disabled={disablePrimary}>
              {labelPrimary}
            </Button>
          </div>
          <div className={clsx({ hidden: !primarySpinning })}>
            <Button variant="primary" onClick={onClickPrimary} disabled={disablePrimary}>
              <i className="fa-solid fa-spinner fa-spin" />
            </Button>
          </div>
        </Col>
      </Row>
    </>
  )
}

export default NavButtons
