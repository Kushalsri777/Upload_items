import { useFormContext, Controller } from 'react-hook-form'
import { isFunction } from 'lodash'
import { Dropdown, TextField } from '@/components/helios-components'
import GroupLabel from './groupLabel'
import unitedStates from './unitedStates'
import { ADDRESS_FIELDS_REGEX, CITY_REGEX, POSTAL_CODE_REGEX } from '@/common/enums/regex'
import { INVALID_CHARACTERS, REQUIRED_FIELDS } from '@/common/enums/constant'
import clsx from 'clsx'
import demographicsViewOnlyStyles from './demographics.module.css'

function Address({ controls, isViewOnly = false, triggerValidation }) {
  const { control, setValue } = useFormContext()
  const { street, city, usState, zip } = controls

  const onStateChange = (selection) => {
    setValue(usState.controllerName, selection.option.value, { shouldValidate: true })
    if (isFunction(triggerValidation)) {
      triggerValidation()
    }
  }

  const onInputChange = (e, field) => {
    field.onChange(e)
    if (isFunction(triggerValidation)) {
      triggerValidation()
    }
  }

  return (
    <>
      <div className={'mb-5'}>
        <GroupLabel label="Mailing Address" />
        <div className={clsx('mb-4', { [demographicsViewOnlyStyles.viewOnly]: isViewOnly })}>
          <Controller
            render={({ field, fieldState }) => {
              const { ref, onChange, ...fields } = field
              return (
                <TextField
                  {...fields}
                  id={field.name}
                  label={street.label}
                  error={fieldState.invalid}
                  helperText={fieldState.error?.message}
                  disabled={isViewOnly}
                  onChange={(e) => onInputChange(e, field)}
                />
              )
            }}
            rules={{
              required: {
                value: true,
                message: street?.requiredErrorMessage || REQUIRED_FIELDS,
              },
              pattern: {
                value: ADDRESS_FIELDS_REGEX,
                message: INVALID_CHARACTERS,
              },
            }}
            control={control}
            name={street.controllerName}
          />
        </div>
        <div className={clsx('mb-4', { [demographicsViewOnlyStyles.viewOnly]: isViewOnly })}>
          <Controller
            render={({ field, fieldState }) => {
              const { ref, onChange, ...fields } = field
              return (
                <TextField
                  {...fields}
                  id={field.name}
                  label={city.label}
                  error={fieldState.invalid}
                  helperText={fieldState.error?.message}
                  disabled={isViewOnly}
                  onChange={(e) => onInputChange(e, field)}
                />
              )
            }}
            rules={{
              required: {
                value: true,
                message: city?.requiredErrorMessage || REQUIRED_FIELDS,
              },
              pattern: {
                value: CITY_REGEX,
                message: INVALID_CHARACTERS,
              },
            }}
            control={control}
            name={city.controllerName}
          />
        </div>
        <div className={clsx({ [demographicsViewOnlyStyles.viewOnly]: isViewOnly, ['mb-4']: !isViewOnly })}>
          <div className="row">
            <div className="col-6" data-cy="us_state_dropdown">
              <Controller
                render={({ field, fieldState }) => {
                  const { ref, ...fields } = field
                  return (
                    <Dropdown
                      {...fields}
                      id={field.name}
                      label={usState.label}
                      onChange={onStateChange}
                      options={unitedStates}
                      selected={field.value || ''}
                      placeholder=""
                      error={fieldState.invalid}
                      helperText={fieldState.error?.message}
                      disabled={isViewOnly}
                    />
                  )
                }}
                rules={{
                  required: {
                    value: true,
                    message: usState?.requiredErrorMessage || REQUIRED_FIELDS,
                  },
                }}
                control={control}
                name={usState.controllerName}
              />
            </div>
            <div className={clsx('col-6', { [demographicsViewOnlyStyles.viewOnly]: isViewOnly })}>
              <Controller
                render={({ field, fieldState }) => {
                  const { ref, onChange, ...fields } = field
                  return (
                    <TextField
                      {...fields}
                      id={field.name}
                      label={zip.label}
                      error={fieldState.invalid}
                      helperText={fieldState.error?.message}
                      disabled={isViewOnly}
                      onChange={(e) => onInputChange(e, field)}
                    />
                  )
                }}
                rules={{
                  required: {
                    value: true,
                    message: zip?.requiredErrorMessage || REQUIRED_FIELDS,
                  },
                  pattern: {
                    value: POSTAL_CODE_REGEX,
                    message: 'Only valid Zip code format allowed. E.g: 12345 or 12345-6789 or 123456789',
                  },
                }}
                control={control}
                name={zip.controllerName}
              />
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

export default Address
