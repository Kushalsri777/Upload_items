import React, { useEffect, useState } from 'react'
import { Button, HelperText, Icon, Link } from '@/components/helios-components'
import styles from './listComponent.module.css'

function ListComponent({
  items: initialItems,
  children,
  onItemsUpdate,
  createNewItem,
  addLabel,
  newItemLabel = 'New item',
  canAdd = true,
}) {
  const [items, setItems] = useState(initialItems)
  const [editingItem, setEditingItem] = useState(null)
  const [addingNewItem, setAddingNewItem] = useState(false)

  useEffect(() => {
    if (items.length === 0) {
      addItem()
    }
  }, [items])

  const addItem = () => {
    if (addingNewItem || editingItem) {
      return
    }
    const newItem = createNewItem()
    setItems([...items, newItem])
    setAddingNewItem(true)
    setEditingItem(newItem)
  }

  const editItem = (index, updatedItem) => {
    const newItems = [...items]
    newItems[index] = updatedItem
    setItems(newItems)
    onItemsUpdate(newItems)
    setEditingItem(null)
    setAddingNewItem(false)
  }

  const removeItem = (index) => {
    if (addingNewItem || editingItem) {
      return
    }
    const newItems = [...items]
    newItems.splice(index, 1)
    setItems(newItems)
    onItemsUpdate(newItems)
  }

  const startEditing = (item) => {
    if (addingNewItem || editingItem) {
      return
    }
    setAddingNewItem(false)
    setEditingItem(item)
  }

  const cancelEdit = () => {
    if (addingNewItem) {
      setItems((prevItems) => {
        const newItems = [...prevItems]
        newItems.pop()
        return newItems
      })
      setAddingNewItem(false)
    } else {
      setAddingNewItem(false)
    }
    setEditingItem(null)
  }

  return (
    <>
      {items?.map((item, index) => (
        <>
          <div
            key={index}
            className={`${styles.itemContainer} ${
              editingItem && editingItem !== item
                ? styles.disabledItem
                : item.errorMessage && (!editingItem || editingItem !== item)
                  ? styles.errorItem
                  : ''
            }`}>
            <div className={styles.itemSummary}>
              {addingNewItem && editingItem === item ? (
                <div className={styles.header}>{newItemLabel}</div>
              ) : (
                <div>
                  <div className={styles.header}>{item.header}</div>
                  <div className={styles.description}>{item.description}</div>
                </div>
              )}
              {editingItem !== item && (
                <div className="hstack gap-2">
                  <Link
                    onClick={() => startEditing(item)}
                    style={editingItem && editingItem !== item ? { color: '#5B6062' } : {}}>
                    Edit
                  </Link>
                  {item.canRemove && (
                    <Link
                      onClick={() => removeItem(index)}
                      style={editingItem && editingItem !== item ? { color: '#5B6062' } : {}}>
                      Remove
                    </Link>
                  )}
                  {item.errorMessage && <Icon name="exclamation-triangle" color="error" nonInteractive={true} />}
                </div>
              )}
            </div>
            {editingItem === item && (
              <div className={styles.itemComponent}>
                {React.cloneElement(children, {
                  item: editingItem,
                  index: index,
                  onEdit: editItem,
                  onCancel: cancelEdit,
                })}
              </div>
            )}
          </div>
          {item.errorMessage && (
            <HelperText error id={`error_${index}`}>
              {item.errorMessage}
            </HelperText>
          )}
        </>
      ))}
      {canAdd && !addingNewItem && !editingItem && (
        <Button style={{ marginTop: '24px' }} onClick={addItem} variant="secondary">
          {addLabel}
        </Button>
      )}
    </>
  )
}

export default ListComponent
