function PageHeader({ children, title, sponsorName }) {
  return (
    <div className="w-full mt-14">
      <h1 className="mb-6">{title}</h1>
      <div className="flex items-center mb-6">
        <span className="font-sunlifeBold">Policyholder:&nbsp;</span>
        <span className="mr-5">{sponsorName}</span>
        {children}
      </div>
    </div>
  )
}

export default PageHeader
