export const ACTION_UPDATE = 'update'
export const ACTION_DELETE = 'delete'
export const actions = { ACTION_UPDATE, ACTION_DELETE }

export const APPLICATION_TYPE_CASE_FORM_DATA = 'caseFormData'
export const APPLICATION_TYPE_CASE_INFO = 'caseInfo'
export const APPLICATION_TYPE_LOGIN_METHOD = 'loginMethod'
export const APPLICATION_TYPE_LOGIN_METHOD_VALUE = 'loginMethodValue'
export const APPLICATION_TYPE_POLICY_INFO = 'policyInfo'
export const APPLICATION_TYPE_REDIRECT_URL = 'redirectUrl'
export const APPLICATION_TYPE_SESSION_INFO = 'sessionInfo'
export const APPLICATION_TYPE_TIMEOUT_INFO = 'timeoutInfo'

export const initialState = {
  caseFormData: null,
  caseInfo: null,
  loginMethod: null,
  loginMethodValue: null,
  policyInfo: null,
  redirectUrl: null,
  sessionInfo: null,
  timeoutInfo: {
    idleInactivityTimeoutInMilliseconds: 1000 * 60 * 13, // [780000ms] -> 13 minutes in milliseconds
    sessionTimeoutInMilliseconds: 1000 * 60 * 18, // [1080000ms] -> 18 minutes in milliseconds
    isUserLogged: false,
    idleEventTimerID: undefined,
    idleLogoutEventTimerID: undefined,
    lastTimeUpdated: undefined,
    displayTimeoutToast: false,
  },
}

export function applicationReducer(state, event) {
  switch (event.action) {
    case ACTION_UPDATE: {
      return updateStateUpdate(state, event)
    }
    case ACTION_DELETE: {
      return updateStateDelete(state, event)
    }
    default: {
      throw Error('Unknown action: ' + (event.action || event))
    }
  }
}

const updateStateUpdate = (state, event) => {
  switch (event.type) {
    case APPLICATION_TYPE_CASE_FORM_DATA: {
      return {
        ...state,
        caseFormData: event.value,
      }
    }
    case APPLICATION_TYPE_CASE_INFO: {
      return {
        ...state,
        caseInfo: event.value,
      }
    }
    case APPLICATION_TYPE_POLICY_INFO: {
      return {
        ...state,
        policyInfo: event.value,
      }
    }
    case APPLICATION_TYPE_LOGIN_METHOD: {
      return {
        ...state,
        loginMethod: event.value,
      }
    }
    case APPLICATION_TYPE_LOGIN_METHOD_VALUE: {
      return {
        ...state,
        loginMethodValue: event.value,
      }
    }
    case APPLICATION_TYPE_SESSION_INFO: {
      return {
        ...state,
        sessionInfo: event.value,
      }
    }
    case APPLICATION_TYPE_REDIRECT_URL: {
      return {
        ...state,
        redirectUrl: event.value,
      }
    }
    case APPLICATION_TYPE_TIMEOUT_INFO: {
      return {
        ...state,
        timeoutInfo: event.value,
      }
    }
    default: {
      throw Error('Unknown application type: ' + event.type)
    }
  }
}

const updateStateDelete = (state, event) => {
  switch (event.type) {
    case APPLICATION_TYPE_CASE_FORM_DATA: {
      return {
        ...state,
        caseFormData: null,
      }
    }
    case APPLICATION_TYPE_CASE_INFO: {
      return {
        ...state,
        caseInfo: null,
      }
    }
    case APPLICATION_TYPE_POLICY_INFO: {
      return {
        ...state,
        policyInfo: null,
      }
    }
    case APPLICATION_TYPE_LOGIN_METHOD: {
      return {
        ...state,
        loginMethod: null,
      }
    }
    case APPLICATION_TYPE_LOGIN_METHOD_VALUE: {
      return {
        ...state,
        loginMethodValue: null,
      }
    }
    case APPLICATION_TYPE_SESSION_INFO: {
      return {
        ...state,
        sessionInfo: null,
      }
    }
    case APPLICATION_TYPE_REDIRECT_URL: {
      return {
        ...state,
        redirectUrl: null,
      }
    }
    case APPLICATION_TYPE_TIMEOUT_INFO: {
      const { idleEventTimeID, idleLogoutEventTimerID } = state
      if (!!idleEventTimeID) clearTimeout(idleEventTimeID)
      if (!!idleLogoutEventTimerID) clearTimeout(idleLogoutEventTimerID)

      const { shouldClearLoggedUser = false, displayTimeoutToast = true } = event.value
      return {
        ...state,
        timeoutInfo: {
          ...state.timeoutInfo,
          idleEventTimerID: undefined,
          idleLogoutEventTimerID: undefined,
          lastTimeUpdated: undefined,
          isUserLogged: shouldClearLoggedUser ? false : true,
          displayTimeoutToast: displayTimeoutToast,
        },
      }
    }
    default: {
      throw Error('Unknown application type: ' + event.type)
    }
  }
}
