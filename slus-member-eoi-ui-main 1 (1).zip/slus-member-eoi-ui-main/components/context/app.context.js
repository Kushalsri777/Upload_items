import React, { createContext, useState } from 'react'
import _, { cloneDeep, merge } from 'lodash'
import { EMPLOYEE, SPOUSE, CHILD } from '@/common/enums/enroller'

export const AppContext = createContext()

const defaultApplicantValues = {
  coverages: [],
  applicantType: '',
  id: '',
  applicantStatusCode: '',
  applicantInfo: {
    demographics: {},
    health: {
      healthSections: [],
      physician: {
        physicianFirstName: '',
        physicianLastName: '',
        addressLine1: '',
        addressCity: '',
        addressStateCode: '',
        addressPostalCode: '',
      },
    },
  },
}

export const AppProvider = ({ defaultValues = {}, children }) => {
  const [caseInfo, setCaseInfo] = useState(null)
  const [policyInfo, setPolicyInfo] = useState(null)
  const [idTypeNumber, setIdTypeNumber] = useState(null)
  const [selectedApplicant, setSelectedApplicant] = useState({
    id: '',
    relationshipType: '',
    applicantFullName: '',
    sequenceNumber: '',
  })
  const [currentEnroller, setCurrentEnroller] = useState(null)
  const [previousEnroller, setPreviousEnroller] = useState(null)
  const [consentDecision, setConsentDecision] = useState(null)
  const [redirectUrl, setRedirectUrl] = useState(null)
  const [caseFormData, setCaseFormData] = useState({ applicants: [], employeeInfo: {} })
  const [locations, setLocations] = useState([])
  const [timeoutInfo, setTimeoutInfo] = useState({
    idleInactivityTimeoutInMilliseconds: 780000, // 13 minutes in milliseconds
    sessionTimeoutInMilliseconds: 1080000, // 18 minutes in milliseconds
    isUserLogged: false,
    idleEventTimerID: undefined,
    idleLogoutEventTimerID: undefined,
    lastTimeUpdated: undefined,
    displayTimeoutToast: false,
    clearTimeouts: (idleLogoutEventTimerID, idleEventTimeID) => {
      if (!!idleEventTimeID) {
        clearTimeout(idleEventTimeID)
      }
      if (!!idleLogoutEventTimerID) {
        clearTimeout(idleLogoutEventTimerID)
      }
    },
  })
  const [sessionInfo, setSessionInfo] = useState({
    policyNumber: '',
    employeeId: '',
    idType: '',
    employeeSelected: false,
    spouseSelected: false,
    childSelected: false,
    numberOfChildren: 0,
  })

  /**
   * ApplicantCompletionStatus are  NOT_STARTED | IN_PROGRESS | COMPLETED. Default value is NOT_STARTED.
   * When user clicks in the START button of an applicant card , the Status is changed to IN_PROGRESS
   * When user submit the applicant from the Review page , the Status is changed to COMPLETED.
   */
  const [applicantCompletionStatus, setApplicantCompletionStatus] = useState('NOT_STARTED')

  const updateCaseInfo = (caseInfo) => {
    setCaseInfo(caseInfo)
  }

  const getPartnerSpouse = () => {
    const { employee: { dependents = [] } = { dependents: [] } } = caseInfo
    return dependents.find((d) => d.relationshipCode === SPOUSE.code) || {}
  }

  const updateCaseInfoPartnerSpouse = (partnerSpouse) => {
    const { employee } = caseInfo
    if (!employee.dependents) {
      employee.dependents = []
    }

    const { dependents } = employee
    const spouseDependentIndex = dependents.findIndex((d) => d.relationshipCode === SPOUSE.code)
    if (spouseDependentIndex === -1) {
      partnerSpouse.relationshipCode = SPOUSE.code
      dependents.push(partnerSpouse)
    } else {
      dependents[spouseDependentIndex] = merge(dependents[spouseDependentIndex], partnerSpouse)
    }

    updateCaseInfo({
      ...caseInfo,
      employee,
    })
  }

  const updatePhysicianInformation = (applicantId, physician) => {
    const clonedCaseFormData = _.cloneDeep(caseFormData)
    const applicant = clonedCaseFormData.applicants.find(({ id }) => id === applicantId)
    if (!!applicant) {
      const clonedPhysician = _.cloneDeep(applicant.applicantInfo.health.physician)
      applicant.applicantInfo.health.physician = {
        ...clonedPhysician,
        ...physician,
      }
    } else {
      clonedCaseFormData.applicants.push({
        ...defaultApplicantValues,
        id: applicantId,
        applicantInfo: {
          health: {
            ...physician,
          },
        },
      })
    }
    setCaseFormData(clonedCaseFormData)
  }

  const getPhysicianInformation = (applicantId) => {
    const applicant = caseFormData.applicants.find(({ id }) => id === applicantId) ?? defaultApplicantValues
    return _.cloneDeep(applicant.applicantInfo.health.physician)
  }

  const updatePolicyInfo = (policyInfo) => {
    setPolicyInfo(policyInfo)
  }

  const updateIdTypeNumber = (idTypeNumber) => {
    setIdTypeNumber(idTypeNumber)
  }

  const updateCurrentEnroller = (currentEnroller) => {
    setCurrentEnroller(currentEnroller)
  }

  const updateSelectedApplicant = (selectedApplicant) => {
    setSelectedApplicant(selectedApplicant)
  }

  const updatePreviousEnroller = (previousEnroller) => {
    setPreviousEnroller(previousEnroller)
  }

  const getOneApplicantByCode = (code) => caseFormData?.applicants?.find((a) => a.applicantType === code)
  const getManyApplicantsByCode = (code) => caseFormData?.applicants?.filter((a) => a.applicantType === code)
  const getCaseFormDataEmployee = () => getOneApplicantByCode(EMPLOYEE.code)
  const getCaseFormDataSpouse = () => getOneApplicantByCode(SPOUSE.code)
  const getCaseFormDataChildren = () => getManyApplicantsByCode(CHILD.code)

  const updateCaseFormData = (caseFormData) => {
    if (caseFormData?.applicants?.length) {
      caseFormData.applicants = caseFormData.applicants.map((applicant) => {
        applicant.applicantInfo = {
          ..._.cloneDeep(defaultApplicantValues.applicantInfo),
          ...applicant.applicantInfo,
        }

        return {
          ..._.cloneDeep(defaultApplicantValues),
          ...applicant,
        }
      })
    }

    if (!caseFormData.employeeInfo) {
      caseFormData = { ...caseFormData, employeeInfo: {} }
    }
    setCaseFormData(caseFormData)
  }

  const updateConsentDecision = (consentDecision) => {
    setConsentDecision(consentDecision)
  }

  const updateLocations = (locations) => {
    setLocations(locations)
  }

  const updateTimeoutInfo = (timeoutInfo) => {
    setTimeoutInfo(_.cloneDeep(timeoutInfo))
  }

  const clearTimeouts = (shouldClearLoggedUser = false, displayTimeoutToast = true) => {
    timeoutInfo.clearTimeouts(timeoutInfo?.idleLogoutEventTimerID, timeoutInfo?.idleEventTimerID)
    const timeoutInfoClone = cloneDeep(timeoutInfo)
    timeoutInfoClone.idleLogoutEventTimerID = undefined
    timeoutInfoClone.idleEventTimerID = undefined
    timeoutInfoClone.lastTimeUpdated = undefined
    if (shouldClearLoggedUser) {
      timeoutInfoClone.isUserLogged = false
      timeoutInfoClone.displayTimeoutToast = displayTimeoutToast
    }
    updateTimeoutInfo(timeoutInfoClone)
  }

  const updateSessionInfo = (sessionInfo) => {
    setSessionInfo(sessionInfo)
  }

  const [showDashboardModal, setShowDashboardModal] = useState(true)
  const [showHistoryModal, setShowHistoryModal] = useState(true)

  const updateShowDashboardModal = (show) => setShowDashboardModal(show)
  const updateShowHistoryModal = (show) => setShowHistoryModal(show)

  const updateApplicantCompletionStatus = (applicantCompletionStatus) => {
    setApplicantCompletionStatus(cloneDeep(applicantCompletionStatus))
  }

  const updateRedirectUrl = (url) => {
    setRedirectUrl(url)
  }

  const initialState = {
    caseInfo,
    updateCaseInfo,
    updateCaseInfoPartnerSpouse,
    getPartnerSpouse,
    policyInfo,
    updatePolicyInfo,
    idTypeNumber,
    updateIdTypeNumber,
    currentEnroller,
    updateCurrentEnroller,
    selectedApplicant,
    updateSelectedApplicant,
    previousEnroller,
    updatePreviousEnroller,
    caseFormData,
    updateCaseFormData,
    consentDecision,
    updateConsentDecision,
    updatePhysicianInformation,
    getPhysicianInformation,
    updateLocations,
    locations,
    timeoutInfo,
    updateTimeoutInfo,
    clearTimeouts,
    sessionInfo,
    updateSessionInfo,
    showDashboardModal,
    updateShowDashboardModal,
    showHistoryModal,
    updateShowHistoryModal,
    applicantCompletionStatus,
    updateApplicantCompletionStatus,
    redirectUrl,
    updateRedirectUrl,
    getCaseFormDataEmployee,
    getCaseFormDataSpouse,
    getCaseFormDataChildren,
  }

  return <AppContext.Provider value={{ ...initialState, ...defaultValues }}>{children}</AppContext.Provider>
}
