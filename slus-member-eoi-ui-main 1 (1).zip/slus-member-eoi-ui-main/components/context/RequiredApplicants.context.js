import { createContext, useContext, useReducer } from 'react'
import {
  requiredApplicantsReducer as reducer,
  initialState,
  ACTION_CHANGE,
  ACTION_TOGGLE,
  APPLICANT_TYPE_EMPLOYEE,
  APPLICANT_TYPE_SPOUSE,
  APPLICANT_TYPE_CHILDREN,
} from './RequiredApplicants.reducer'

const RequiredApplicantsContext = createContext(null)
const RequiredApplicantsDispatchContext = createContext(null)

export function RequiredApplicantsProvider({ children }) {
  const [requiredApplicants, dispatch] = useReducer(reducer, initialState)
  const dispatchEvent = (type, action, value) => dispatch({ type, action, value })

  const dispatcher = {
    toggleEmployeeRequired: () => dispatchEvent(APPLICANT_TYPE_EMPLOYEE, ACTION_TOGGLE),
    toggleSpouseRequired: () => dispatchEvent(APPLICANT_TYPE_SPOUSE, ACTION_TOGGLE),
    toggleChildrenRequired: () => dispatchEvent(APPLICANT_TYPE_CHILDREN, ACTION_TOGGLE),

    setEmployeeRequired: (value) => dispatchEvent(APPLICANT_TYPE_EMPLOYEE, ACTION_CHANGE, value),
    setSpouseRequired: (value) => dispatchEvent(APPLICANT_TYPE_SPOUSE, ACTION_CHANGE, value),
    setChildrenRequired: (value) => dispatchEvent(APPLICANT_TYPE_CHILDREN, ACTION_CHANGE, value),
  }

  return (
    <RequiredApplicantsContext.Provider value={requiredApplicants}>
      <RequiredApplicantsDispatchContext.Provider value={dispatcher}>
        {children}
      </RequiredApplicantsDispatchContext.Provider>
    </RequiredApplicantsContext.Provider>
  )
}

export function useRequiredApplicants() {
  return useContext(RequiredApplicantsContext)
}

export function useRequiredApplicantsDispatcher() {
  return useContext(RequiredApplicantsDispatchContext)
}
