import { createContext, useContext, useReducer } from 'react'
import {
  applicantsReducer as reducer,
  initialState,
  ACTION_UPDATE,
  ACTION_DELETE,
  APPLICANT_TYPE_EMPLOYEE,
  APPLICANT_TYPE_SPOUSE,
  APPLICANT_TYPE_CHILDREN,
  APPLICANT_TYPE_CHILD,
  APPLICANT_TYPE_IS_KNOWN_USER,
  APPLICANT_TYPE_QUESTIONS,
  APPLICANT_TYPE_QUESTIONS_ALL,
  APPLICANT_TYPE_POLICY,
} from './Applicants.reducer'
import { EMPLOYEE, SPOUSE, CHILD } from '@/common/enums/enroller'

const ApplicantsContext = createContext(null)
const ApplicantsDispatchContext = createContext(null)

export function useApplicants() {
  return useContext(ApplicantsContext)
}

export function useApplicantsDispatcher() {
  return useContext(ApplicantsDispatchContext)
}

export function ApplicantsProvider({ children }) {
  const [applicants, dispatch] = useReducer(reducer, initialState)
  const dispatchEvent = (type, action, value, child) => dispatch({ type, action, value, child })
  const createAcknowlegmentObj = (curr, ackStep, value) => {
    const result = {
      acknowledgements: {
        ...curr,
        [ackStep]: value,
      },
    }
    return result
  }

  const dispatcher = {
    updateEmployee: (value) => dispatchEvent(APPLICANT_TYPE_EMPLOYEE, ACTION_UPDATE, value),
    updateSpouse: (value) => dispatchEvent(APPLICANT_TYPE_SPOUSE, ACTION_UPDATE, value),
    updateChildren: (value) => dispatchEvent(APPLICANT_TYPE_CHILDREN, ACTION_UPDATE, value),
    updateIsKnownUser: (value) => dispatchEvent(APPLICANT_TYPE_IS_KNOWN_USER, ACTION_UPDATE, value),
    updateQuestions: (value) => dispatchEvent(APPLICANT_TYPE_QUESTIONS, ACTION_UPDATE, value),
    updatePolicy: (value) => dispatchEvent(APPLICANT_TYPE_POLICY, ACTION_UPDATE, value),

    setAcknowledge: (applicant, ackStep, value) => {
      const { type, acknowledgements } = applicant
      switch (type) {
        case EMPLOYEE: {
          const ackObj = createAcknowlegmentObj(acknowledgements, ackStep, value)
          dispatchEvent(APPLICANT_TYPE_EMPLOYEE, ACTION_UPDATE, ackObj)
          break
        }
        case SPOUSE: {
          const ackObj = createAcknowlegmentObj(acknowledgements, ackStep, value)
          dispatchEvent(APPLICANT_TYPE_SPOUSE, ACTION_UPDATE, ackObj)
          break
        }
        case CHILD: {
          const ackObj = createAcknowlegmentObj(acknowledgements, ackStep, value)
          dispatchEvent(APPLICANT_TYPE_CHILD, ACTION_UPDATE, ackObj, applicant)
          break
        }
        default: {
          throw new Error(`Unknown enroller type: ${type}`)
        }
      }
    },

    deleteEmployee: () => dispatchEvent(APPLICANT_TYPE_EMPLOYEE, ACTION_DELETE),
    deleteSpouse: () => dispatchEvent(APPLICANT_TYPE_SPOUSE, ACTION_DELETE),
    deleteChild: (value) => dispatchEvent(APPLICANT_TYPE_CHILDREN, ACTION_DELETE, value),
    deleteQuestions: (value) => dispatchEvent(APPLICANT_TYPE_QUESTIONS, ACTION_DELETE, value),
    deleteIsKnownUser: () => dispatchEvent(APPLICANT_TYPE_IS_KNOWN_USER, ACTION_UPDATE),
  }

  return (
    <ApplicantsContext.Provider value={applicants}>
      <ApplicantsDispatchContext.Provider value={dispatcher}>{children}</ApplicantsDispatchContext.Provider>
    </ApplicantsContext.Provider>
  )
}
