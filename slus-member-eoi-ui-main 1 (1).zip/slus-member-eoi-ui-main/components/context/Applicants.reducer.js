import { EMPLOYEE, SPOUSE, CHILD } from '@/common/enums/enroller'

export const ACTION_UPDATE = 'update'
export const ACTION_DELETE = 'delete'
export const actions = { ACTION_UPDATE, ACTION_DELETE }

export const APPLICANT_TYPE_EMPLOYEE = 'employee'
export const APPLICANT_TYPE_SPOUSE = 'spouse'
export const APPLICANT_TYPE_CHILDREN = 'children'
export const APPLICANT_TYPE_CHILD = 'child'
export const APPLICANT_TYPE_IS_KNOWN_USER = 'isKnownUser'
export const APPLICANT_TYPE_QUESTIONS = 'questions'
export const APPLICANT_TYPE_POLICY = 'policy'

export const initialState = {
  isKnownUser: null,
  policy: {
    id: null,
    idType: null,
    legalEntityCode: null,
    policyNumber: null,
    situsState: null,
    sponsorName: null,
  },
  employee: {
    firstName: null,
    lastName: null,
    genderCode: null,
    heightFeet: null,
    heightInches: null,
    weight: null,
    dateOfBirth: null,
    street: null,
    city: null,
    state: null,
    zip: null,
    email: null,
    emailConfirm: null,
    phone: null,
    occupation: null,
    locationCode: null,
    coverages: [],
    applicantStatusCode: null,
    questions: [],
    status: null,
    acknowledgements: {
      fraudWarning: false,
      hipaaAuth: false,
    },
  },
  spouse: {
    firstName: null,
    lastName: null,
    genderCode: null,
    dateOfBirth: null,
    email: null,
    questions: [],
    status: null,
    acknowledgements: {
      fraudWarning: false,
      hipaaAuth: false,
    },
  },
  children: [],
}

export function applicantsReducer(state, event) {
  switch (event.action) {
    case ACTION_UPDATE: {
      return updateStateUpdate(state, event)
    }
    case ACTION_DELETE: {
      return updateStateDelete(state, event)
    }
    default: {
      throw Error('Unknown action: ' + event.action)
    }
  }
}

const mergeQuestions = (questions, newQuestions) => {
  if (!questions) {
    return newQuestions
  }
  const existingQuestions = questions.reduce((acc, q) => {
    const key = `${q.requirementOptionCd}-${q.requirementOptionUsageCd}-${q.provisionSeqNum}`
    acc[key] = q
    return acc
  }, {})
  newQuestions?.forEach((q) => {
    const key = `${q.requirementOptionCd}-${q.requirementOptionUsageCd}-${q.provisionSeqNum}`
    existingQuestions[key] = q
  })
  return Object.values(existingQuestions)
}

const updateStateUpdate = (state, event) => {
  switch (event.type) {
    case APPLICANT_TYPE_EMPLOYEE: {
      const { employee } = state
      const newEmployee = {
        ...(employee || {}),
        ...event.value,
        ...{ type: EMPLOYEE, seqNum: 1 },
      }
      return {
        ...state,
        employee: newEmployee,
      }
    }
    case APPLICANT_TYPE_SPOUSE: {
      const { spouse } = state
      const newSpouse = {
        ...(spouse || {}),
        ...event.value,
        ...{ type: SPOUSE, seqNum: 1 },
      }
      return {
        ...state,
        spouse: newSpouse,
      }
    }
    case APPLICANT_TYPE_CHILDREN: {
      const newChildren = event.value.map((c) => ({
        ...c,
        type: CHILD,
      }))
      return {
        ...state,
        children: newChildren,
      }
    }
    case APPLICANT_TYPE_CHILD: {
      const { child, value } = event
      const { children } = state
      const newChildren = children.map((c) => {
        if (c.seqNum === child.seqNum) {
          return {
            ...c,
            ...value,
          }
        }
        return c
      })

      return {
        ...state,
        children: newChildren,
      }
    }
    case APPLICANT_TYPE_IS_KNOWN_USER: {
      return {
        ...state,
        isKnownUser: !!event.value,
      }
    }
    case APPLICANT_TYPE_QUESTIONS: {
      const { value } = event
      const { employee, spouse, children } = state

      const employeeQuestions = value.filter((q) => q.applicantType === EMPLOYEE.code)
      const spouseQuestions = value.filter((q) => q.applicantType === SPOUSE.code)

      const ch_questions = value
        .filter((q) => q.applicantType === CHILD.code)
        .reduce((childQsObj, question) => {
          const { seqNum } = question

          let seqNumArr = childQsObj[seqNum]
          if (seqNumArr) {
            seqNumArr.push(question)
          } else {
            seqNumArr = [question]
          }

          childQsObj[seqNum] = seqNumArr
          return childQsObj
        }, {})

      /**
       * ch_questions is a JS Object (not an array like ee and sp) and
       *   should look like below (order is not guarenteed) where key
       *   is "seqNum" value:
       * {
       *      "2": [ ...questions ],
       *      "1": [ ...questions ],
       *      "3": [ ...questions ],
       * }
       */

      const newChildren = children.map((c) => {
        const { seqNum } = c
        const { [seqNum]: questions } = ch_questions
        const newQuestions = mergeQuestions(c.questions, questions)
        return {
          ...c,
          questions: newQuestions,
        }
      })

      return {
        ...state,
        employee: {
          ...employee,
          questions: mergeQuestions(state.employee.questions, employeeQuestions),
        },
        spouse: {
          ...spouse,
          questions: mergeQuestions(state?.spouse?.questions, spouseQuestions),
        },
        children: newChildren,
      }
    }
    case APPLICANT_TYPE_POLICY: {
      const { value } = event
      return {
        ...state,
        policy: value,
      }
    }
    default: {
      throw Error('Unknown applicant type: ' + event.type)
    }
  }
}

const removeQuestions = (questions, employeeQuestions) => {
  if (!questions) {
    return []
  }
  const existingQuestions = questions.reduce((acc, q) => {
    const key = `${q.requirementOptionCd}-${q.requirementOptionUsageCd}-${q.provisionSeqNum}`
    acc[key] = q
    return acc
  }, {})
  employeeQuestions?.forEach((q) => {
    const key = `${q.requirementOptionCd}-${q.requirementOptionUsageCd}-${q.provisionSeqNum}`
    delete existingQuestions[key]
  })
  return Object.values(existingQuestions)
}

const updateStateDelete = (state, event) => {
  const { children } = state
  switch (event.type) {
    case APPLICANT_TYPE_EMPLOYEE: {
      return {
        ...state,
        employee: null,
      }
    }
    case APPLICANT_TYPE_SPOUSE: {
      return {
        ...state,
        spouse: null,
      }
    }
    case APPLICANT_TYPE_CHILD:
    case APPLICANT_TYPE_CHILDREN: {
      const {
        value: { seqNum },
      } = event
      return {
        ...state,
        children: children.filter((c) => c.seqNum !== seqNum),
      }
    }
    case APPLICANT_TYPE_IS_KNOWN_USER: {
      return {
        ...state,
        isKnownUser: null,
      }
    }
    case APPLICANT_TYPE_POLICY: {
      return {
        ...state,
        policy: null,
      }
    }
    case APPLICANT_TYPE_QUESTIONS: {
      const { value } = event
      const { employee, spouse } = state

      const employeeQuestions = value.filter((q) => q.applicantType === EMPLOYEE.code)
      const spouseQuestions = value.filter((q) => q.applicantType === SPOUSE.code)

      const chQuestions = value
        .filter((q) => q.applicantType === CHILD.code)
        .reduce((childQsObj, question) => {
          const { seqNum } = question

          let seqNumArr = childQsObj[seqNum]
          if (seqNumArr) {
            seqNumArr.push(question)
          } else {
            seqNumArr = [question]
          }

          childQsObj[seqNum] = seqNumArr
          return childQsObj
        }, {})

      const newChildren = children.map((c) => {
        const { seqNum } = c
        const { [seqNum]: questions } = chQuestions
        const newQuestions = removeQuestions(c.questions, questions)
        return {
          ...c,
          questions: newQuestions,
        }
      })

      return {
        ...state,
        employee: {
          ...employee,
          questions: removeQuestions(state.employee.questions, employeeQuestions),
        },
        spouse: {
          ...spouse,
          questions: removeQuestions(state?.spouse?.questions, spouseQuestions),
        },
        children: newChildren,
      }
    }
    default: {
      throw Error('Unknown applicant type: ' + event.type)
    }
  }
}
