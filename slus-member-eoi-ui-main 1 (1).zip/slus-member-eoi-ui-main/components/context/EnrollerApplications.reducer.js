import { cloneDeep } from 'lodash'
import { EMPLOYEE, SPOUSE, CHILD } from '@/common/enums/enroller'

export const ACTION_UPDATE = 'update'
export const ACTION_DELETE = 'delete'

export const initialState = {
  employee: {
    answers: {},
  },
  spouse: {
    answers: {},
  },
  children: [],
  getCurrentEnroller: (type) => {
    switch (type) {
      case EMPLOYEE: {
        return initialState.employee
      }
      case SPOUSE: {
        return initialState.spouse
      }
      case CHILD: {
        return initialState.children
      }
      default: {
        throw Error(`Unknown enroller type: ${type}`)
      }
    }
  },
}

export function enrollerApplicationsReducer(state, event) {
  switch (event.action) {
    case ACTION_UPDATE: {
      return stateUpdate(state, event)
    }
    case ACTION_DELETE: {
      return stateDelete(state, event)
    }
    default: {
      throw Error('Unknown action: ' + event.action)
    }
  }
}

const stateUpdate = (state, event) => {
  switch (event.type) {
    case EMPLOYEE: {
      const { id, answer } = event.value
      const newAnswers = cloneDeep(state.employee.answers)
      newAnswers[id] = answer

      const result = {
        ...state,
        employee: {
          answers: newAnswers,
        },
      }
      return result
    }
    case SPOUSE: {
      const { id, answer } = event.value
      const newAnswers = cloneDeep(state.spouse.answers)
      newAnswers[id] = answer

      const result = {
        ...state,
        spouse: {
          answers: newAnswers,
        },
      }
      return result
    }
    default: {
      throw Error('Unknown data type: ' + event.type)
    }
  }
}

const stateDelete = (state, event) => {
  switch (event.type) {
    case EMPLOYEE: {
      const { id } = event.value
      const newAnswers = cloneDeep(state.employee.answers)
      delete newAnswers[id]

      const result = {
        ...state,
        employee: {
          answers: newAnswers,
        },
      }
      return result
    }
    case SPOUSE: {
      const { id } = event.value
      const newAnswers = cloneDeep(state.spouse.answers)
      delete newAnswers[id]

      const result = {
        ...state,
        spouse: {
          answers: newAnswers,
        },
      }
      return result
    }
    default: {
      throw Error('Unknown data type: ' + event.type)
    }
  }
}
