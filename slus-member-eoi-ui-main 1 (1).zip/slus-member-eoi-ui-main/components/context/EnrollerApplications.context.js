import { createContext, useContext, useReducer } from 'react'
import {
  enrollerApplicationsReducer as reducer,
  initialState,
  ACTION_UPDATE,
  ACTION_DELETE,
} from './EnrollerApplications.reducer'
import { EMPLOYEE, SPOUSE, CHILD } from '@/common/enums/enroller'

const EnrollerApplicationsContext = createContext(null)
const EnrollerApplicationsDispatchContext = createContext(null)

export function useEnrollerApplications() {
  return useContext(EnrollerApplicationsContext)
}

export function useEnrollerApplicationsDispatcher() {
  return useContext(EnrollerApplicationsDispatchContext)
}

export function EnrollerApplicationsProvider({ children }) {
  const [enrollerApplications, dispatch] = useReducer(reducer, initialState)
  const dispatchEvent = (type, action, value) => dispatch({ type, action, value })

  const dispatcher = {
    getAnswer: (id, enroller) => {
      switch (enroller) {
        case EMPLOYEE: {
          return enrollerApplications.employee.answer?.[id]
        }
        case SPOUSE: {
          return enrollerApplications.spouse.answer?.[id]
        }
        case CHILD: {
          throw Error('TODO -- needs to be implemented!')
        }
        default: {
          throw Error('Unknown enroller type: ' + enroller)
        }
      }
    },
    updateAnswer: (id, enroller, answer) => dispatchEvent(enroller, ACTION_UPDATE, { id, answer }),
    deleteAnswer: (id, enroller, answer) => dispatchEvent(enroller, ACTION_DELETE, { id, answer }),
  }

  return (
    <EnrollerApplicationsContext.Provider value={enrollerApplications}>
      <EnrollerApplicationsDispatchContext.Provider value={dispatcher}>
        {children}
      </EnrollerApplicationsDispatchContext.Provider>
    </EnrollerApplicationsContext.Provider>
  )
}
