import { createContext, useContext, useReducer } from 'react'
import {
  healthHistoryStepsReducer as reducer,
  initialState,
  ACTION_UPDATE_QUESTIONS,
  ACTION_UPDATE_ANSWER,
} from './HealthHistorySteps.reducer'

const HealthHistoryStepsContext = createContext(null)
const HealthHistoryStepsDispatchContext = createContext(null)

export function useHealthHistorySteps() {
  return useContext(HealthHistoryStepsContext)
}

export function useHealthHistoryStepsDispatcher() {
  return useContext(HealthHistoryStepsDispatchContext)
}

export function HealthHistoryStepsProvider({ children }) {
  const [healthHistorySteps, dispatch] = useReducer(reducer, initialState)
  const dispatchEvent = (type, action, value) => dispatch({ type, action, value })

  const dispatcher = {
    updateQuestions: (stepId, questions) => dispatchEvent(stepId, ACTION_UPDATE_QUESTIONS, { questions }),
    updateAnswer: (stepId, id, answer, type) => dispatchEvent(stepId, ACTION_UPDATE_ANSWER, { id, answer, type }),
  }

  return (
    <HealthHistoryStepsContext.Provider value={healthHistorySteps}>
      <HealthHistoryStepsDispatchContext.Provider value={dispatcher}>
        {children}
      </HealthHistoryStepsDispatchContext.Provider>
    </HealthHistoryStepsContext.Provider>
  )
}
