import { createContext, useContext, useReducer } from 'react'
import {
  applicationReducer as reducer,
  initialState,
  ACTION_UPDATE,
  ACTION_DELETE,
  APPLICATION_TYPE_CASE_FORM_DATA,
  APPLICATION_TYPE_CASE_INFO,
  APPLICATION_TYPE_LOGIN_METHOD,
  APPLICATION_TYPE_LOGIN_METHOD_VALUE,
  APPLICATION_TYPE_POLICY_INFO,
  APPLICATION_TYPE_REDIRECT_URL,
  APPLICATION_TYPE_SESSION_INFO,
  APPLICATION_TYPE_TIMEOUT_INFO,
} from './LegacyApplication.reducer'

const LegacyApplicationContext = createContext(null)
const LegacyApplicationDispatchContext = createContext(null)

export function useLegacyApplication() {
  return useContext(LegacyApplicationContext)
}

export function useLegacyApplicationDispatcher() {
  return useContext(LegacyApplicationDispatchContext)
}

export function LegacyApplicationProvider({ children }) {
  const [application, dispatch] = useReducer(reducer, initialState)
  const dispatchEvent = (type, action, value) => dispatch({ type, action, value })

  const dispatcher = {
    updateCaseFormData: (value) => dispatchEvent(APPLICATION_TYPE_CASE_FORM_DATA, ACTION_UPDATE, value),
    updateCaseInfo: (value) => dispatchEvent(APPLICATION_TYPE_CASE_INFO, ACTION_UPDATE, value),
    updateLoginMethod: (value) => dispatchEvent(APPLICATION_TYPE_LOGIN_METHOD, ACTION_UPDATE, value),
    updateLoginMethodValue: (value) => dispatchEvent(APPLICATION_TYPE_LOGIN_METHOD_VALUE, ACTION_UPDATE, value),
    updatePolicyInfo: (value) => dispatchEvent(APPLICATION_TYPE_POLICY_INFO, ACTION_UPDATE, value),
    updateRedirectUrl: (value) => dispatchEvent(APPLICATION_TYPE_REDIRECT_URL, ACTION_UPDATE, value),
    updateSessionInfo: (value) => dispatchEvent(APPLICATION_TYPE_SESSION_INFO, ACTION_UPDATE, value),
    updateTimeoutInfo: (value) => dispatchEvent(APPLICATION_TYPE_TIMEOUT_INFO, ACTION_UPDATE, value),

    deleteCaseFormData: () => dispatchEvent(APPLICATION_TYPE_CASE_FORM_DATA, ACTION_DELETE),
    deleteCaseInfo: () => dispatchEvent(APPLICATION_TYPE_CASE_INFO, ACTION_DELETE),
    deleteLoginMethod: () => dispatchEvent(APPLICATION_TYPE_LOGIN_METHOD, ACTION_DELETE),
    deleteLoginMethodValue: () => dispatchEvent(APPLICATION_TYPE_LOGIN_METHOD_VALUE, ACTION_DELETE),
    deletePolicyInfo: () => dispatchEvent(APPLICATION_TYPE_POLICY_INFO, ACTION_DELETE),
    deleteRedirectUrl: () => dispatchEvent(APPLICATION_TYPE_REDIRECT_URL, ACTION_DELETE),
    deleteSessionInfo: () => dispatchEvent(APPLICATION_TYPE_SESSION_INFO, ACTION_DELETE),
    deleteTimeoutInfo: (value) => dispatchEvent(APPLICATION_TYPE_TIMEOUT_INFO, ACTION_DELETE, value),
  }

  return (
    <LegacyApplicationContext.Provider value={application}>
      <LegacyApplicationDispatchContext.Provider value={dispatcher}>
        {children}
      </LegacyApplicationDispatchContext.Provider>
    </LegacyApplicationContext.Provider>
  )
}
