import React from 'react'

export const StepHandlerContext = React.createContext({
  stepHandler: () => {},
  setStepHandler: () => {},
})
