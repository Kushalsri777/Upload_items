import { cloneDeep } from 'lodash'
import {
  DATA_STEP_ID_CANCER,
  DATA_STEP_ID_NEUROLOGICAL,
  DATA_STEP_ID_ADDICTION,
  DATA_STEP_ID_MEDICATIONS,
  DATA_STEP_ID_REVIEW,
} from '@/common/enums/healthHistorySteps'

export const ACTION_UPDATE_QUESTIONS = 'updateQuestion'
export const ACTION_UPDATE_ANSWER = 'updateAnswer'

/***
  const single_questions_template = {
    id: 0,
    type: "",
    answer: null,
  }
*/

export const initialState = {
  stepCancer: {
    id: DATA_STEP_ID_CANCER,
    label: 'Cancer, circulatory, and respiratory conditions',
    questions: [],
  },
  stepNeurological: {
    id: DATA_STEP_ID_NEUROLOGICAL,
    label: 'Neurological, psychiatric, internal, and infectious conditions',
    questions: [],
  },
  stepAddiction: {
    id: DATA_STEP_ID_ADDICTION,
    label: 'Addiction, diabetes, and chronic pain',
    questions: [],
  },
  stepMedications: {
    id: DATA_STEP_ID_MEDICATIONS,
    label: 'Medications, missed work and other questions',
    questions: [],
  },
  stepReview: {
    id: DATA_STEP_ID_REVIEW,
    label: 'Review your answers',
    questions: [],
  },
}

export function healthHistoryStepsReducer(state, event) {
  const { action } = event
  switch (action) {
    case ACTION_UPDATE_QUESTIONS: {
      return updateQuestions(state, event)
    }
    case ACTION_UPDATE_ANSWER: {
      return updateAnswer(state, event)
    }
    default: {
      throw Error(`Unknown action: ${action}`)
    }
  }
}

const updateQuestions = (state, event) => {
  const { type, value } = event
  let result = null
  switch (type) {
    case DATA_STEP_ID_CANCER: {
      const { questions } = value
      result = {
        ...state,
        stepCancer: {
          ...state.stepCancer,
          questions,
        },
      }
      break
    }
    case DATA_STEP_ID_NEUROLOGICAL: {
      const { questions } = value
      result = {
        ...state,
        stepNeurological: {
          ...state.stepNeurological,
          questions,
        },
      }
      break
    }
    case DATA_STEP_ID_ADDICTION: {
      const { questions } = value
      result = {
        ...state,
        stepAddiction: {
          ...state.stepAddiction,
          questions,
        },
      }
      break
    }
    case DATA_STEP_ID_MEDICATIONS: {
      const { questions } = value
      result = {
        ...state,
        stepMedications: {
          ...state.stepMedications,
          questions,
        },
      }
      break
    }
    case DATA_STEP_ID_REVIEW: {
      const { questions } = value
      result = {
        ...state,
        stepReview: {
          ...state.stepReview,
          questions,
        },
      }
      break
    }
    default: {
      throw Error(`Unknown event type: ${type}`)
    }
  }
  return result
}

const updateAnswer = (state, event) => {
  const { type } = event
  if (
    ![
      DATA_STEP_ID_CANCER,
      DATA_STEP_ID_NEUROLOGICAL,
      DATA_STEP_ID_ADDICTION,
      DATA_STEP_ID_MEDICATIONS,
      DATA_STEP_ID_REVIEW,
    ].includes(type)
  ) {
    throw Error(`Unknown event type: ${type}`)
  }

  const {
    value: { id: qId, answer, type: qType },
  } = event
  const { questions: stateQuestions } = state[type]
  const clonedQuestions = cloneDeep(stateQuestions)

  const updatedQuestion = { id: qId, answer, type: qType }
  const index = clonedQuestions.findIndex((q) => q.id === qId)
  if (index > -1) {
    clonedQuestions[index] = updatedQuestion
  } else {
    clonedQuestions.push(updatedQuestion)
  }

  return {
    ...state,
    [type]: {
      ...state[type],
      questions: clonedQuestions,
    },
  }
}
