import { createContext, useContext, useReducer } from 'react'
import {
  continuanceReducer as reducer,
  initialState,
  ACTION_UPDATE,
  ACTION_DELETE,
  DATA_TYPE_APP_LOCATION,
  DATA_TYPE_APP_LOCATION_ID,
  DATA_TYPE_IS_USER_IN_PROGRESS,
  DATA_TYPE_IS_FINISHED_ONBOARDING,
  DATA_TYPE_CURRENT_STEP_INDEX,
  DATA_TYPE_IS_PLACEHOLDER,
} from './Continuance.reducer'

const ContinuanceContext = createContext(null)
const ContinuanceDispatchContext = createContext(null)

export function useContinuance() {
  return useContext(ContinuanceContext)
}

export function useContinuanceDispatcher() {
  return useContext(ContinuanceDispatchContext)
}

export function ContinuanceProvider({ children }) {
  const [continuance, dispatch] = useReducer(reducer, initialState)
  const dispatchEvent = (type, action, value) => dispatch({ type, action, value })

  const dispatcher = {
    updateAppLocation: (value) => dispatchEvent(DATA_TYPE_APP_LOCATION, ACTION_UPDATE, value),
    updateAppLocationId: (value) => dispatchEvent(DATA_TYPE_APP_LOCATION_ID, ACTION_UPDATE, value),
    updateCurrentStepIndex: (value) => dispatchEvent(DATA_TYPE_CURRENT_STEP_INDEX, ACTION_UPDATE, value),
    updateIsUserInProgress: (value) => dispatchEvent(DATA_TYPE_IS_USER_IN_PROGRESS, ACTION_UPDATE, value),
    updateIsFinishedOnboarding: (value) => dispatchEvent(DATA_TYPE_IS_FINISHED_ONBOARDING, ACTION_UPDATE, value),
    updateIsPlaceholder: (value) => dispatchEvent(DATA_TYPE_IS_PLACEHOLDER, ACTION_UPDATE, value),

    deleteAppLocation: () => dispatchEvent(DATA_TYPE_APP_LOCATION, ACTION_DELETE),
    deleteAppLocationId: () => dispatchEvent(DATA_TYPE_APP_LOCATION_ID, ACTION_DELETE),
    deleteCurrentStepIndex: () => dispatchEvent(DATA_TYPE_CURRENT_STEP_INDEX, ACTION_DELETE),
    deleteIsUserInProgress: () => dispatchEvent(DATA_TYPE_IS_USER_IN_PROGRESS, ACTION_DELETE),
    deleteIsFinishedOnboarding: () => dispatchEvent(DATA_TYPE_IS_FINISHED_ONBOARDING, ACTION_DELETE),
  }

  return (
    <ContinuanceContext.Provider value={continuance}>
      <ContinuanceDispatchContext.Provider value={dispatcher}>{children}</ContinuanceDispatchContext.Provider>
    </ContinuanceContext.Provider>
  )
}
