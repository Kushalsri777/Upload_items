export const ACTION_CHANGE = 'change'
export const ACTION_TOGGLE = 'toggle'
export const actions = { ACTION_CHANGE, ACTION_TOGGLE }

export const APPLICANT_TYPE_EMPLOYEE = 'employee'
export const APPLICANT_TYPE_SPOUSE = 'spouse'
export const APPLICANT_TYPE_CHILDREN = 'children'
export const applicantTypes = { APPLICANT_TYPE_EMPLOYEE, APPLICANT_TYPE_SPOUSE, APPLICANT_TYPE_CHILDREN }

export const initialState = {
  requireEmployee: false,
  requireSpouse: false,
  requireChildren: false,
}

const updateStateChange = (state, event) => {
  switch (event.type) {
    case APPLICANT_TYPE_EMPLOYEE: {
      return {
        ...state,
        requireEmployee: event.value,
      }
    }
    case APPLICANT_TYPE_SPOUSE: {
      return {
        ...state,
        requireSpouse: event.value,
      }
    }
    case APPLICANT_TYPE_CHILDREN: {
      return {
        ...state,
        requireChildren: event.value,
      }
    }
    default: {
      throw Error('Unknown applicant type: ' + event.type)
    }
  }
}

const updateStateToggle = (state, event) => {
  switch (event.type) {
    case APPLICANT_TYPE_EMPLOYEE: {
      return {
        ...state,
        requireEmployee: !state.requireEmployee,
      }
    }
    case APPLICANT_TYPE_SPOUSE: {
      return {
        ...state,
        requireSpouse: !state.requireSpouse,
      }
    }
    case APPLICANT_TYPE_CHILDREN: {
      return {
        ...state,
        requireChildren: !state.requireChildren,
      }
    }
    default: {
      throw Error('Unknown applicant type: ' + event.type)
    }
  }
}

export function requiredApplicantsReducer(state, event) {
  switch (event.action) {
    case ACTION_CHANGE: {
      return updateStateChange(state, event)
    }
    case ACTION_TOGGLE: {
      return updateStateToggle(state, event)
    }
    default: {
      throw Error('Unknown action: ' + event.action)
    }
  }
}
