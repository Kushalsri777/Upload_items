export const ACTION_UPDATE = 'update'
export const ACTION_DELETE = 'delete'

export const DATA_TYPE_APP_LOCATION = 'appLocation'
export const DATA_TYPE_APP_LOCATION_ID = 'appLocationId'
export const DATA_TYPE_CURRENT_STEP_INDEX = 'currentStepIndex'
export const DATA_TYPE_IS_USER_IN_PROGRESS = 'isUserInProgress'
export const DATA_TYPE_IS_FINISHED_ONBOARDING = 'isFinishedOnboarding'
export const DATA_TYPE_IS_PLACEHOLDER = 'isPlaceholder'

export const initialState = {
  appLocation: null,
  appLocationId: null,
  currentStepIndex: null,
  isUserInProgress: null,
  isFinishedOnboarding: null,
  isPlaceholder: false,
}

export function continuanceReducer(state, event) {
  switch (event.action) {
    case ACTION_UPDATE: {
      return stateUpdate(state, event)
    }
    case ACTION_DELETE: {
      return stateDelete(state, event)
    }
    default: {
      throw Error('Unknown action: ' + event.action)
    }
  }
}

const stateUpdate = (state, event) => {
  switch (event.type) {
    case DATA_TYPE_APP_LOCATION: {
      return {
        ...state,
        appLocation: event.value,
      }
    }
    case DATA_TYPE_APP_LOCATION_ID: {
      return {
        ...state,
        appLocationId: event.value,
      }
    }
    case DATA_TYPE_CURRENT_STEP_INDEX: {
      return {
        ...state,
        currentStepIndex: event.value,
      }
    }
    case DATA_TYPE_IS_USER_IN_PROGRESS: {
      return {
        ...state,
        isUserInProgress: event.value,
      }
    }
    case DATA_TYPE_IS_FINISHED_ONBOARDING: {
      return {
        ...state,
        isFinishedOnboarding: event.value,
      }
    }
    case DATA_TYPE_IS_PLACEHOLDER: {
      return {
        ...state,
        isPlaceholder: event.value,
      }
    }
    default: {
      throw Error('Unknown data type: ' + event.type)
    }
  }
}

const stateDelete = (state, event) => {
  switch (event.type) {
    case DATA_TYPE_APP_LOCATION: {
      const result = {
        ...state,
        appLocation: null,
      }
      return result
    }
    case DATA_TYPE_APP_LOCATION_ID: {
      const result = {
        ...state,
        appLocationId: null,
      }
      return result
    }
    case DATA_TYPE_CURRENT_STEP_INDEX: {
      const result = {
        ...state,
        currentStepIndex: null,
      }
      return result
    }
    case DATA_TYPE_IS_USER_IN_PROGRESS: {
      const result = {
        ...state,
        isUserInProgress: null,
      }
      return result
    }
    case DATA_TYPE_IS_FINISHED_ONBOARDING: {
      const result = {
        ...state,
        isFinishedOnboarding: null,
      }
      return result
    }
    default: {
      throw Error('Unknown data type: ' + event.type)
    }
  }
}
