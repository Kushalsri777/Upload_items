import { COMPLETED, NOT_STARTED, STARTED } from '@/common/enums/guidedExperienceStepStatus'
import { useApplicants } from '@/components/context/Applicants.context'
import { StepHandlerContext } from '@/components/context/StepHandler.context'
import { getApplicantQuestions } from '@/components/healthHistoryQuestions/steps/util'
import { Drawer, GuidedExperience, HelperText } from '@/components/helios-components'
import { cloneDeep, isNil } from 'lodash'
import { useEffect, useState } from 'react'
import { FormProvider, useForm } from 'react-hook-form'
import styles from '../healthHistoryQuestions/healthHistoryDrawer.module.css'

export function FollowUpQuestionDrawer({ applicant, steps, showDrawer, onClose, onShowHealthHistoryDrawer }) {
  const [activeIndex, setActiveIndex] = useState(0)
  const [stepHandler, setStepHandler] = useState({ onClickNext: async () => true })
  const [stepConfig, setStepConfig] = useState(steps)
  const [nextStepRequirementsMet, setNextStepRequirementsMet] = useState(true)
  const applicants = useApplicants()

  const methods = useForm({
    mode: 'onTouched',
  })

  useEffect(() => {
    let index = stepConfig.steps.findIndex((s) => {
      const status = getStepStatus(s.stepId)
      return status === NOT_STARTED || status === STARTED
    })
    if (index < 0) {
      index = stepConfig.steps.length - 1
    }
    setActiveIndex(index)
  }, [])

  const hasStarted = () => {
    return getApplicantQuestions(applicant, applicants).filter((q) => q.textValue).length > 0
  }

  const getStepStatus = (stepId) => {
    if (stepId !== 'landing') {
      return hasStarted() ? STARTED : NOT_STARTED
    }

    const stepQuestions = getApplicantQuestions(applicant, applicants).filter(
      (q) => q.requirementOptionUsageCd === stepId && q.displayType !== 'LABEL',
    )

    let completedCount = stepQuestions.filter((q) => {
      return q.textValue
    })?.length

    completedCount = completedCount || 0

    if (completedCount === 0) {
      if (stepId === 'landing') {
        return STARTED
      }
      return NOT_STARTED
    }

    if (completedCount < stepQuestions.length) {
      return STARTED
    }

    if (completedCount === stepQuestions.length) {
      return COMPLETED
    }
  }

  const isAllStepYesNoQuestionsAnsweredNo = () => {
    return getApplicantQuestions(applicant, applicants)
      .filter(({ displayType: d }) => d === 'SLIDER')
      .every(({ textValue: v }) => !v || v === 'NO')
  }

  const handleOnClickActionPrevious = async () => {
    const isValid = await isCurrentStepValid()
    if (isValid) {
      onClose()
    }
  }

  const isCurrentStepValid = async () => {
    const { onClickNext } = stepHandler
    return await onClickNext()
  }

  const handleOnClickActionNext = async () => {
    const isValid = await isCurrentStepValid()

    if (!isValid) {
      return false
    }

    const newActiveIndex = Math.min(stepConfig.steps.length - 1, activeIndex + 1)
    if (activeIndex === newActiveIndex) {
      // this means we are on the last step trying to proceed
      onClose()
    } else {
      setActiveIndex(newActiveIndex)
    }
  }

  const handleOnStepClick = async (currId, clickedId) => {
    const indexOfDash = clickedId.lastIndexOf('-')
    const newActiveIndexSubstr = clickedId.substring(indexOfDash + 1)
    const newActiveIndex = parseInt(newActiveIndexSubstr)
    const isValid = await stepHandler.onClickNext(true)
    if (isValid) {
      setActiveIndex(newActiveIndex)
    }
  }

  const getFinalButtonText = () => {
    const isLastStep = stepConfig.steps.length - 1 === activeIndex

    return !isLastStep ? 'Next Step' : 'Countinue to follow-up questions'
  }

  const getActionButtons = () => {
    const isLastStep = stepConfig.steps.length - 1 === activeIndex
    const isAllAnsweredNo = isAllStepYesNoQuestionsAnsweredNo()
    if (isLastStep && isAllAnsweredNo) {
      return [
        {
          id: 2,
          children: 'Save and finish',
          variant: 'primary',
          onClick: handleOnClickActionNext,
        },
      ]
    }

    return [
      {
        id: 1,
        children: 'Save and return to dashboard',
        variant: 'secondary',
        onClick: handleOnClickActionPrevious,
      },
      {
        id: 2,
        children: getFinalButtonText(),
        variant: 'primary',
        disabled: !nextStepRequirementsMet,
        onClick: handleOnClickActionNext,
      },
    ]
  }

  const getInvalidQuestions = (stepId) => {
    const questions = getApplicantQuestions(applicant, applicants)
    return questions.filter((question) => {
      return question.requirementOptionUsageCd === stepId && question.errorMessage
    })
  }

  const getStepDescription = ({ stepId }) => {
    const invalidQuestions = getInvalidQuestions(stepId)

    if (invalidQuestions?.length === 0) {
      return null
    } else {
      const helperText = (() => {
        const count = invalidQuestions.length

        return count === 1
          ? 'There is 1 question with an error on this page'
          : `There are ${count} questions with an error on this page`
      })()

      return [
        <HelperText error key="helper-text">
          {helperText}
        </HelperText>,
      ]
    }
  }

  const getCurrentSteps = () => {
    const currentSteps = stepConfig.steps
      .filter((step) => step.enabled)
      .map((step, index) => {
        return {
          id: `step-${index}`,
          label: step.label,
          status: getStepStatus(step.stepId),
          title: !isNil(step.title) ? step.title : step.label,
          description: getStepDescription(step),
        }
      })

    return currentSteps
  }

  const getCurrentActiveComponent = () => {
    const currentSteps = stepConfig?.steps.filter((c) => c.enabled)
    const currentUsageCode = currentSteps.at(activeIndex).usageCode

    const onChange = (questions) => {
      setStepConfig((currentConfig) => {
        const updatedConfig = cloneDeep(currentConfig)

        updatedConfig.steps = updatedConfig.steps.map((s) => {
          if (s.locked) {
            return s
          }
          const updatedQuestion = questions.find((q) => q.requirementOptionCd === s.stepId)
          if (updatedQuestion) {
            const { textValue } = updatedQuestion
            s.enabled = 'YES' === textValue
          }
          return s
        })
        return updatedConfig
      })
    }

    const ActiveComponent = currentSteps.at(activeIndex).component

    return (
      <FormProvider {...methods}>
        <ActiveComponent
          applicant={applicant}
          applicants={applicants}
          usageCode={currentUsageCode}
          setRequirementsMet={setNextStepRequirementsMet}
          onChangeSelection={onChange}
          onShowHealthHistoryDrawer={onShowHealthHistoryDrawer}
        />
      </FormProvider>
    )
  }

  return (
    <Drawer
      className={styles?.drawer}
      aria-describedby="follow-up-drawer-body"
      closeLabel="Close"
      id="follow-up-drawer"
      onExit={onClose}
      onExited={onClose}
      size="large"
      show={showDrawer}
      actions={getActionButtons()}>
      <StepHandlerContext.Provider value={{ stepHandler, setStepHandler }}>
        <GuidedExperience
          className={styles.guidedExp}
          action={{}} // using actions on the drawer component
          heading={stepConfig.heading}
          activeStep={`step-${activeIndex}`}
          onStepClick={handleOnStepClick}
          steps={getCurrentSteps()}>
          {getCurrentActiveComponent()}
        </GuidedExperience>
      </StepHandlerContext.Provider>
    </Drawer>
  )
}
