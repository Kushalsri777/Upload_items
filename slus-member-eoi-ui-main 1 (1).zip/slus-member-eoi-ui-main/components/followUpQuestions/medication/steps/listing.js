import { MED_GRP } from '@/common/enums/constant'
import { saveMedicationAnswers } from '@/common/utils/api'
import { useApplicants, useApplicantsDispatcher } from '@/components/context/Applicants.context'
import { StepHandlerContext } from '@/components/context/StepHandler.context'
import { MedicationList } from '@/components/followUpQuestions/medication/medicationList'
import { isEmpty } from 'lodash'
import { useContext, useEffect, useState } from 'react'

const StepMedicationListing = ({ applicant, usageCode, onChangeAnswer, onChangeSelection }) => {
  const { setStepHandler } = useContext(StepHandlerContext)
  const [updatedQuestions, setUpdatedQuestions] = useState([])
  const [removedQuestions, setRemovedQuestions] = useState([])
  const [medicationTemplate, setMedicationTemplate] = useState([])
  const { updateQuestions, deleteQuestions } = useApplicantsDispatcher()

  const applicants = useApplicants()

  useEffect(() => {
    setStepHandler({
      onClickNext: async () => {
        const isOk = await saveMedicationAnswers(applicant, updatedQuestions, removedQuestions)
        if (isOk) {
          const currentQuestions = !isEmpty(updatedQuestions) ? updatedQuestions : medicationTemplate
          updateQuestions(currentQuestions)
          deleteQuestions(removedQuestions)
          setRemovedQuestions([])
          return true
        }
        return false
      },
    })
  }, [updatedQuestions, updateQuestions, removedQuestions])

  const handleQuestionsSaved = (updatedQuestions) => {
    setUpdatedQuestions(updatedQuestions)
    onChangeSelection(updatedQuestions)
  }

  const handleQuestionsDeleted = (deletedMedicalQuestions) => {
    setUpdatedQuestions((previousQuestions) => {
      const updatedQuestions = [...previousQuestions].filter((question) => !deletedMedicalQuestions.includes(question))

      onChangeSelection(updatedQuestions)
      return updatedQuestions
    })

    setRemovedQuestions((previousQuestions) => {
      const newRemovedQuestions = deletedMedicalQuestions.filter((question) => {
        return !previousQuestions.some(
          (prevQuestion) =>
            prevQuestion.benCd === question.benCd &&
            prevQuestion.requirementId === question.requirementId &&
            prevQuestion.requirementOptionCd === question.requirementOptionCd &&
            prevQuestion.requirementOptionUsageCd === question.requirementOptionUsageCd &&
            prevQuestion.provisionSeqNum === question.provisionSeqNum,
        )
      })

      const updatedQuestions = [...previousQuestions, ...newRemovedQuestions]
      return updatedQuestions
    })
  }

  return (
    <>
      <div className="mb-4">
        Here’s a list of the medications you told us {applicant.firstName} has taken. But we need to know if there are
        other medications prescribed to {applicant.firstName} for any other condition(s).
      </div>
      <div className="mb-4">
        For questions or help completing this form, you can call Customer Service at 800-247-6875 on Monday through
        Friday from 8:00 a.m. – 8:00 p.m., ET
      </div>
      <div className="mb-2">
        <span style={{ fontSize: '1.5rem' }}>Medication information</span>
      </div>
      <MedicationList
        applicant={applicant}
        applicants={applicants}
        usageCode={usageCode}
        subgroupCode={MED_GRP}
        medicationTemplate={medicationTemplate}
        onTemplateUpdated={setMedicationTemplate}
        onQuestionsSaved={handleQuestionsSaved}
        onQuestionsDeleted={handleQuestionsDeleted}
      />
    </>
  )
}

export default StepMedicationListing
