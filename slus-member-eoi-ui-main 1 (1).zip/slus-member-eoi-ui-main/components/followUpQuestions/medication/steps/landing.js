import { useApplicantsDispatcher } from '@/components/context/Applicants.context'
import { StepHandlerContext } from '@/components/context/StepHandler.context'
import { useContext, useEffect, useState } from 'react'

const StepLanding = ({ applicant, usageCode, onChangeSelection, onShowHealthHistoryDrawer }) => {
  const { setStepHandler } = useContext(StepHandlerContext)
  const [currentQuestions, setCurrentQuestions] = useState([])
  const [removedQuestions, setRemovedQuestions] = useState([])
  const { updateQuestions, deleteQuestions } = useApplicantsDispatcher()

  useEffect(() => {}, [])

  const handleQuestionsSaved = (questions) => {}

  const handleQuestionsDeleted = (questions) => {}

  return <></>
}

export default StepLanding
