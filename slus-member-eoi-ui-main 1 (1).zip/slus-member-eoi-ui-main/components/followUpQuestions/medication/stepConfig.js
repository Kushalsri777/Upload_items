import StepMedicationListing from './steps/listing'
import StepLanding from './steps/landing'
import StepReview from './steps/review'

export const MedicationSteps = {
  heading: 'Medications',
  steps: [
    {
      stepId: 'landing',
      label: 'Follow-up questions',
      component: StepLanding,
      enabled: true,
      locked: true,
    },
    {
      stepId: 'MedicationsFlUp',
      usageCode: 'MedicationsFlUp',
      label: 'Medication follow-up',
      title: '',
      component: StepMedicationListing,
      enabled: true,
      locked: true,
    },
    {
      stepId: 'review',
      label: 'Review',
      component: StepReview,
      enabled: true,
      locked: true,
    },
  ],
}
