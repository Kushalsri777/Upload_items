import { MED_GRP } from '@/common/enums/constant'
import { getApplicantQuestionsBySubgroupCode } from '@/components/healthHistoryQuestions/steps/util'
import { Button } from '@/components/helios-components'
import { isEmpty } from 'lodash'
import moment from 'moment/moment'
import { useEffect, useState } from 'react'
import { FormProvider, useForm } from 'react-hook-form'
import AddMedicationForm from '../../healthHistoryQuestions/medication/addMedicationForm'
import AnsweredMedicationForm from '../../healthHistoryQuestions/medication/answeredMedicationForm'

export function MedicationList({
  applicant,
  applicants,
  usageCode,
  medicationGroupCode = MED_GRP,
  medicationTemplate,
  onTemplateUpdated,
  onQuestionsSaved,
  onQuestionsDeleted,
}) {
  const [medicationQuestions, setMedicationQuestions] = useState([])
  const [editExistingQuestionsIndex, setEditExistingQuestionsIndex] = useState(null)
  const [watchedFields, setWatchedFields] = useState([])

  const methods = useForm({
    mode: 'onTouched',
  })

  const buildTemplateQuestions = (questions) => {
    return questions.map((question) => ({
      ...question,
      textValue: null,
      dateValue: null,
      provisionSeqNum: null,
    }))
  }

  const groupQuestionsBySequenceNumber = (questions) => {
    return Object.values(
      questions.reduce((acc, question) => {
        if (!acc[question.provisionSeqNum]) {
          acc[question.provisionSeqNum] = []
        }
        acc[question.provisionSeqNum].push(question)
        return acc
      }, []),
    )
  }

  const questionsHaveSequenceNumber = (questions) => {
    const checkSequenceNumber = (question) => question.provisionSeqNum !== null
    return questions.some(checkSequenceNumber)
  }

  useEffect(() => {
    const medicationQuestions = getApplicantQuestionsBySubgroupCode(applicant, applicants, medicationGroupCode)
    const medicationUsageCodeQuestions = medicationQuestions.filter(
      (question) => question.requirementOptionUsageCd === usageCode,
    )

    const medicationTemplate = groupQuestionsBySequenceNumber(medicationUsageCodeQuestions)
      .map(buildTemplateQuestions)
      .at(0)

    const groupedMedicationQuestions = (() => {
      const groupedQuestions = groupQuestionsBySequenceNumber(
        medicationQuestions.filter((question) => question.provisionSeqNum),
      )

      return !isEmpty(groupedQuestions) ? groupedQuestions : [[...medicationTemplate]]
    })()

    if (groupedMedicationQuestions.length === 1 && !questionsHaveSequenceNumber(groupedMedicationQuestions.at(0))) {
      setEditExistingQuestionsIndex(0)
    } else {
      const methodsToWatch = groupedMedicationQuestions
        .at(0)
        .map((question) => {
          if (question.depAction === 'DISABLE') {
            return methods.watch(question.depRequirementOptionCd)
          } else {
            return null
          }
        })
        .filter((method) => method)

      if (methodsToWatch.length > 0) {
        setWatchedFields(methodsToWatch)
      }
    }

    onTemplateUpdated(medicationTemplate)
    setMedicationQuestions(groupedMedicationQuestions)
  }, [])

  useEffect(() => {
    if (editExistingQuestionsIndex !== null) {
      const methodsToWatch = medicationQuestions
        .at(editExistingQuestionsIndex)
        .map((question) => {
          if (question.depAction === 'DISABLE') {
            return methods.watch(question.depRequirementOptionCd)
          } else {
            return null
          }
        })
        .filter((method) => method)

      if (methodsToWatch.size > 0) {
        setWatchedFields(methodsToWatch)
      }
    }
  }, [editExistingQuestionsIndex])

  useEffect(() => {
    medicationQuestions.forEach((groupedQuestions) => {
      groupedQuestions.forEach((question) => {
        if (isDisabled(question)) {
          if (question.displayType === 'CALENDAR') {
            methods.setValue(question.requirementOptionCd, { input: null, selected: null })
          } else {
            methods.setValue(question.requirementOptionCd, null)
          }
        }
      })
    })
  }, [watchedFields, methods])

  const handleCancel = (index) => {
    methods.reset()

    const isCancelledQuestionsExisting = medicationQuestions.at(index).at(0).provisionSeqNum !== null

    const isCanceledQuestionsNew =
      medicationQuestions.length > 1 &&
      index === medicationQuestions.length - 1 &&
      medicationQuestions.at(index).at(0).provisionSeqNum === null

    if (isCanceledQuestionsNew) {
      setMedicationQuestions(medicationQuestions.slice(0, -1))
      setEditExistingQuestionsIndex(null)
    } else if (isCancelledQuestionsExisting) {
      setEditExistingQuestionsIndex(null)
    }
  }

  const handleEdit = (index) => {
    medicationQuestions.at(index).forEach((question) => {
      if (question.displayType === 'CALENDAR') {
        const dateValue = question.dateValue ? moment(question.dateValue).format('MM/DD/YYYY') : null
        methods.setValue(question.requirementOptionCd, { input: dateValue, selected: dateValue })
      } else {
        methods.setValue(question.requirementOptionCd, question.textValue)
      }
    })

    setEditExistingQuestionsIndex(index)
  }

  const handleAdd = () => {
    const medicationQuestionsToAdd = [...medicationTemplate]

    setEditExistingQuestionsIndex(medicationQuestions.length)
    setMedicationQuestions([...medicationQuestions, medicationQuestionsToAdd])
    medicationQuestionsToAdd.forEach((question) => {
      if (question.displayType === 'CALENDAR') {
        methods.setValue(question.requirementOptionCd, {})
      } else {
        methods.setValue(question.requirementOptionCd, null)
      }
    })
  }

  const handleSave = async () => {
    const isFormValid = await methods.trigger()
    if (isFormValid) {
      const formData = methods.getValues()

      const updatedQuestions = [...medicationQuestions].map((questionGroup, index) => {
        const updatedQuestionGroup = questionGroup.map((question) => {
          return { ...question, provisionSeqNum: index + 1 }
        })
        return updatedQuestionGroup
      })

      const selectedQuestions = updatedQuestions.at(editExistingQuestionsIndex)
      selectedQuestions.forEach((question) => {
        const value = formData[question.requirementOptionCd]
        if (question.displayType === 'CALENDAR') {
          question.dateValue = value ? formData[question.requirementOptionCd].input : null
        } else {
          question.textValue = value ? formData[question.requirementOptionCd] : null
        }
      })

      setMedicationQuestions(updatedQuestions)
      setEditExistingQuestionsIndex(null)
      onQuestionsSaved(updatedQuestions.flat())
    }
  }

  const handleDelete = (index) => {
    const questionsToDelete = medicationQuestions[index]

    const updatedQuestions = (() => {
      if (medicationQuestions.length <= 1) {
        const defaultMedicationQuestions = [...medicationTemplate]

        defaultMedicationQuestions.forEach((question) => {
          if (question.displayType === 'CALENDAR') {
            methods.setValue(question.requirementOptionCd, {})
          } else {
            methods.setValue(question.requirementOptionCd, null)
          }
        })
        setEditExistingQuestionsIndex(0)
        return [defaultMedicationQuestions]
      } else {
        return medicationQuestions.filter((_, i) => i !== index)
      }
    })()

    setMedicationQuestions(updatedQuestions)
    onQuestionsDeleted(questionsToDelete)
  }

  const isDisabled = (question) => {
    if (question.depAction === 'DISABLE') {
      const depValue = methods.getValues()[question.depRequirementOptionCd]
      return depValue !== question.depRequirementValue
    }
    return false
  }

  return (
    <>
      <FormProvider {...methods}>
        {medicationQuestions.map((currentQuestions, index) => {
          return editExistingQuestionsIndex !== null && editExistingQuestionsIndex === index ? (
            <AddMedicationForm
              key={`add-medication-${index}`}
              applicant={applicant}
              formMethods={methods}
              formQuestions={currentQuestions}
              index={index}
              isDisabled={isDisabled}
              onCancel={handleCancel}
              onSave={handleSave}
            />
          ) : (
            <AnsweredMedicationForm
              key={`answered-medication-${index}`}
              formQuestions={currentQuestions}
              index={index}
              isDisabled={editExistingQuestionsIndex !== null}
              onEdit={handleEdit}
              onDelete={handleDelete}
            />
          )
        })}
        <div className="mt-6">
          <Button variant="secondary" disabled={editExistingQuestionsIndex !== null} onClick={handleAdd}>
            Add medication
          </Button>
        </div>
      </FormProvider>
    </>
  )
}
