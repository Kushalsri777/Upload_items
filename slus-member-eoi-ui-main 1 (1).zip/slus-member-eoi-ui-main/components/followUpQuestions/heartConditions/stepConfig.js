import StepHighBloodPressure from './steps/highBloodPressure'
import StepFollowUpQuestions from './steps/heartConditions'
import StepArrhythmia from './steps/arrhythmia'
import StepTestFollowUp from './steps/testFollowUp'
export const HeartSteps = {
  heading: 'High blood pressure/hypertension and other heart-related conditions',
  steps: [
    {
      stepId: 'landing',
      usageCode: 'HghBldPreFolUp',
      label: 'Follow-up questions',
      component: StepFollowUpQuestions,
      enabled: true,
      locked: false,
    },
    {
      stepId: 'TestFollowUp',
      usageCode: 'HghBldPreTstFol',
      label: 'Test follow-up',
      component: StepTestFollowUp,
      enabled: true,
      locked: false,
    },
    {
      stepId: 'HghBldPress',
      usageCode: 'HghBldTstDiagFl',
      label: 'High blood pressure/hypertension follow-up',
      component: StepHighBloodPressure,
      enabled: true,
      locked: false,
    },
    {
      stepId: 'Arrhythmia',
      usageCode: 'ArrhythmiaFolUp',
      label: 'Arrhythmia follow-up',
      component: StepArrhythmia,
      enabled: true,
      locked: false,
    },
  ],
}
