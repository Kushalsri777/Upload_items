import { useContext, useEffect, useState } from 'react'
import { StepHandlerContext } from '@/components/context/StepHandler.context'
import { QuestionList } from '@/components/healthHistoryQuestions/questionList'
import { getApplicantQuestionsByUsageCode } from '@/components/healthHistoryQuestions/steps/util'
import { useApplicantsDispatcher } from '@/components/context/Applicants.context'
import { saveAnswersForTextValue } from '@/common/utils/api'

const HighBloodPressureStep = ({ applicant, applicants, usageCode, onChangeAnswer, onChangeSelection }) => {
  const { setStepHandler } = useContext(StepHandlerContext)
  const [questions, setQuestions] = useState([])
  const { updateQuestions } = useApplicantsDispatcher()

  useEffect(() => {
    try {
      if (!applicants) {
        console.error('applicants is undefined in HighBloodPressureStep')
        setQuestions([])
        return
      }
      const usageCodeQuestions = getApplicantQuestionsByUsageCode(applicant, applicants, usageCode)
      setQuestions(usageCodeQuestions)
    } catch (error) {
      console.error('Error fetching high blood pressure questions:', error)
      setQuestions([])
    }
  }, [applicant, applicants, usageCode])

  useEffect(() => {
    setStepHandler({
      onClickNext: async () => {
        try {
          const isOk = await saveAnswersForTextValue(applicant, questions)
          if (isOk) {
            updateQuestions(questions)
            return true
          }
          return false
        } catch (error) {
          console.error('Error saving high blood pressure answers:', error)
          return false
        }
      },
    })
  }, [applicant, questions, setStepHandler, updateQuestions])

  const handleQuestionsChange = (updatedQuestions) => {
    setQuestions(updatedQuestions)
    onChangeSelection(updatedQuestions)
  }

  return (
    <>
      <div className="mb-4">
        You told us that {applicant.firstName} has experienced high blood pressure/hypertension. Please help us
        understand the situation by answering the following questions.
      </div>
      <QuestionList
        applicant={applicant}
        usageCode={usageCode}
        onQuestionsChange={handleQuestionsChange}
        className="mb-0"
      />
    </>
  )
}

export default HighBloodPressureStep
