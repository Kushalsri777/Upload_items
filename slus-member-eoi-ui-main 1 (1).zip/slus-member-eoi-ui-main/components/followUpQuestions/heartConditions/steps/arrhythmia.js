import { useContext, useEffect, useState } from 'react'
import { StepHandlerContext } from '@/components/context/StepHandler.context'
import { QuestionList } from '@/components/healthHistoryQuestions/questionList'
import { getApplicantQuestionsByUsageCode } from '@/components/healthHistoryQuestions/steps/util'
import { useApplicantsDispatcher } from '@/components/context/Applicants.context'
import { saveAnswersForTextValue } from '@/common/utils/api'

const textAreaConfig = {
  ArrhyTreatPlan: {
    placeholder: 'Arrhythmia treatment plan',
    maxLength: 500,
    showExternalLabel: true,
    rows: 8,
    className: 'mt-8 max-w-md',
    style: {
      minHeight: '160px',
      resize: 'none',
      borderRadius: 0,
      borderColor: '#e5e7eb',
    },
  },
}

const ArrhythmiaStep = ({ applicant, applicants, usageCode, onChangeAnswer, onChangeSelection }) => {
  const { setStepHandler } = useContext(StepHandlerContext)
  const [questions, setQuestions] = useState([])
  const { updateQuestions } = useApplicantsDispatcher()
  useEffect(() => {
    try {
      if (!applicants) {
        console.error('applicants is undefined in ArrhythmiaStep')
        setQuestions([])
        return
      }
      const usageCodeQuestions = getApplicantQuestionsByUsageCode(applicant, applicants, usageCode)
      setQuestions(usageCodeQuestions)
    } catch (error) {
      console.error('Error fetching arrhythmia questions:', error)
      setQuestions([])
    }
  }, [applicant, applicants, usageCode])
  useEffect(() => {
    setStepHandler({
      onClickNext: async () => {
        try {
          const isOk = await saveAnswersForTextValue(applicant, questions)
          if (isOk) {
            updateQuestions(questions)
            return true
          }
          return false
        } catch (error) {
          console.error('Error saving arrhythmia answers:', {
            message: error.message || error.toString(),
            stack: error.stack,
            applicantId: applicant?.id,
            questionsCount: questions?.length || 0,
            questionTypes: questions?.map((q) => q.requirementOptionCd) || [],
            statusCode: error.response?.status,
            responseData: error.response?.data,
          })
          return false
        }
      },
    })
  }, [applicant, questions, setStepHandler, updateQuestions])
  const handleQuestionsChange = (updatedQuestions) => {
    setQuestions(updatedQuestions)
    onChangeSelection(updatedQuestions)
  }
  return (
    <>
      <div className="mb-4">
        You told us that {applicant.firstName} has experienced an arrhythmia. Please help us understand the situation by
        answering the following questions.
      </div>
      <QuestionList
        applicant={applicant}
        usageCode={usageCode}
        onQuestionsChange={handleQuestionsChange}
        className="mb-0"
        textAreaConfig={textAreaConfig}
      />
    </>
  )
}
export default ArrhythmiaStep
