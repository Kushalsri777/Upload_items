import { saveAnswersForTextValue } from '@/common/utils/api'
import { useApplicantsDispatcher } from '@/components/context/Applicants.context'
import { StepHandlerContext } from '@/components/context/StepHandler.context'
import { QuestionList } from '@/components/healthHistoryQuestions/questionList'
import { useContext, useEffect, useState } from 'react'
const TestFollowUpStep = ({ applicant, usageCode, onChangeSelection }) => {
  const { setStepHandler } = useContext(StepHandlerContext)
  const [updatedQuestions, setUpdatedQuestions] = useState([])
  const { updateQuestions } = useApplicantsDispatcher()

  useEffect(() => {
    setStepHandler({
      onClickNext: async () => {
        const isOk = await saveAnswersForTextValue(applicant, updatedQuestions)
        if (isOk) {
          updateQuestions(updatedQuestions)
          return true
        }
        return false
      },
    })
  }, [updatedQuestions])

  const handleQuestionsChange = (updatedQuestions) => {
    setUpdatedQuestions(updatedQuestions)
    onChangeSelection(updatedQuestions)
  }
  return (
    <>
      <div className="mb-4">
        You told us that {applicant.firstName} has had an electrocardiogram (EKG/ECG) and/or a stress test. Please help
        us understand the situation by answering the following questions.
      </div>
      <div className="mb-4">
        <span style={{ fontSize: '1.5rem' }}>EKG/ECG information</span>
      </div>
      <QuestionList
        applicant={applicant}
        usageCode={usageCode}
        onQuestionsChange={handleQuestionsChange}
        className="mb-4"
      />
    </>
  )
}
export default TestFollowUpStep
