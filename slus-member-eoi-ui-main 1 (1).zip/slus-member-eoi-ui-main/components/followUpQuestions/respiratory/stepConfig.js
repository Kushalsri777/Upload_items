import StepAsthma from './steps/asthma'
import StepBronchitis from './steps/bronchitis'
import StepCysticFibrosis from './steps/cysticFibrosis'
import StepFollowUpQuestions from './steps/respiratory'
import StepOther from './steps/other'
import StepReview from './steps/review'
import StepSleepApnea from './steps/sleepApnea'

export const RespiratorySteps = {
  heading: 'Lung disorders and respiratory diseases',
  steps: [
    {
      stepId: 'landing',
      usageCode: 'LungDiseaseFlUp',
      label: 'Follow-up questions',
      component: StepFollowUpQuestions,
      enabled: true,
      locked: true,
    },
    {
      stepId: 'Asthma',
      usageCode: 'AsthmaFlUp',
      label: 'Asthma follow-up',
      component: StepAsthma,
      enabled: true,
      locked: false,
    },
    {
      stepId: 'BronChronEmp',
      usageCode: 'BronhChronFlUp',
      label: 'Chronic bronchitics, emphysema, or COPD follow-up',
      title: 'Bronchitis, chronic bronchitics, emphysema, or COPD follow-up',
      component: StepBronchitis,
      enabled: true,
      locked: false,
    },
    {
      stepId: 'CysticFibrosis',
      usageCode: '',
      label: 'Cystic Fibrosis follow-up',
      component: StepCysticFibrosis,
      enabled: false,
      locked: false,
    },
    {
      stepId: 'SleepApnea',
      usageCode: 'SleepApneaFlUp',
      label: 'Sleep Apnea follow-up',
      component: StepSleepApnea,
      enabled: false,
      locked: false,
    },
    {
      stepId: 'LungOthTyp',
      usageCode: 'LungOtherFlUp',
      label: 'A different respiratory disease or disorder follow-up',
      title: 'A different respiratory disease or disorder follow-up',
      component: StepOther,
      enabled: true,
      locked: false,
    },
    {
      stepId: 'review',
      label: 'Review your answers',
      component: StepReview,
      enabled: true,
      locked: true,
    },
  ],
}
