import { saveAnswersForTextValue } from '@/common/utils/api'
import { useApplicantsDispatcher } from '@/components/context/Applicants.context'
import { StepHandlerContext } from '@/components/context/StepHandler.context'
import { QuestionList } from '@/components/healthHistoryQuestions/questionList'
import { useContext, useEffect, useState } from 'react'

const AsthmaStep = ({ applicant, usageCode, onChangeSelection }) => {
  const { setStepHandler } = useContext(StepHandlerContext)
  const [questions, setQuestions] = useState([])
  const { updateQuestions } = useApplicantsDispatcher()

  useEffect(() => {
    setStepHandler({
      onClickNext: async () => {
        const isOk = await saveAnswersForTextValue(applicant, questions)
        if (isOk) {
          updateQuestions(questions)
          return true
        }
        return false
      },
    })
  }, [questions])

  const handleQuestionsChange = (updatedQuestions) => {
    setQuestions(updatedQuestions)
    onChangeSelection(updatedQuestions)
  }

  return (
    <>
      <div className="mb-4">
        You told us that {applicant.firstName} has had asthma. Please help us understand the situation by answering the
        following questions.
      </div>
      <QuestionList
        applicant={applicant}
        usageCode={usageCode}
        onQuestionsChange={handleQuestionsChange}
        className="mb-0"
      />
    </>
  )
}

export default AsthmaStep
