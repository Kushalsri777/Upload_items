import { StepHandlerContext } from '@/components/context/StepHandler.context'
import { Bold } from '@/components/healthHistoryQuestions/steps/util'
import { Notification } from '@/components/helios-components'
import { useContext, useState } from 'react'

const StepReview = ({ applicant, usageCode }) => {
  const { setStepHandler } = useContext(StepHandlerContext)
  const [showNotification, setShowNotification] = useState(false)
  const [notificationMessage, setNotificationMessage] = useState('')

  const getExperienceAnswers = () => {
    return [] //TODO
  }

  const getMedicationAnswers = () => {
    return [] //TODO
  }

  return (
    <>
      <div className="mb-4">
        {showNotification && (
          <Notification actions={{}} closeLabel="Close" onClose={() => setShowNotification(false)} variant="danger">
            <>{notificationMessage}</>
          </Notification>
        )}
      </div>
      <div className="mb-4">Please review the answer you gave us and make sure they&apos;re correct.</div>
      <div className="mb-2">
        <Bold>You told us that {applicant.firstName} has experienced:</Bold>
      </div>
      <div className="mb-4">
        <ol className="list-decimal">
          {getExperienceAnswers().map((question, i) => (
            <li key={`experience-answer-${i}`}>{question}</li>
          ))}
        </ol>
      </div>
      <div className="mb-4">We will ask you follow up questions for these conditions next.</div>
      <div className="mb-2">
        <Bold>You also told us that {applicant.firstName}:</Bold>
      </div>
      <div className="mb-4">
        <ol className="list-decimal">
          {getMedicationAnswers().map((question, i) => (
            <li key={`medication-answer-${i}`}>{question}</li>
          ))}
        </ol>
      </div>
      <div className="mb-2">
        <Bold>The primary physician taking care of {applicant.firstName} is:</Bold>
      </div>
    </>
  )
}

export default StepReview
