import { saveAnswersForTextValue } from '@/common/utils/api'
import { useApplicantsDispatcher } from '@/components/context/Applicants.context'
import { StepHandlerContext } from '@/components/context/StepHandler.context'
import { useContext, useEffect, useState } from 'react'

const CysticFibrosisStep = ({ applicant, usageCode, onChangeSelection }) => {
  const { setStepHandler } = useContext(StepHandlerContext)
  const [questions, setQuestions] = useState([])
  const { updateQuestions } = useApplicantsDispatcher()

  useEffect(() => {
    setStepHandler({
      onClickNext: async () => {
        const isOk = await saveAnswersForTextValue(applicant, questions)
        if (isOk) {
          updateQuestions(questions)
          return true
        }
        return false
      },
    })
  }, [questions])

  const handleQuestionsChange = (updatedQuestions) => {
    setQuestions(updatedQuestions)
    onChangeSelection(updatedQuestions)
  }

  return (
    <>
      <div className="mb-4">You told us that {applicant.firstName} has had Cystic fibrosis.</div>
    </>
  )
}

export default CysticFibrosisStep
