import { DIAG_GRP } from '@/common/enums/constant'
import { saveAnswersForTextValue } from '@/common/utils/api'
import { useApplicantsDispatcher } from '@/components/context/Applicants.context'
import { StepHandlerContext } from '@/components/context/StepHandler.context'
import { QuestionList } from '@/components/healthHistoryQuestions/questionList'
import { Link } from '@/components/helios-components'
import { isEmpty } from 'lodash'
import { useContext, useEffect, useState } from 'react'
import { useFormContext } from 'react-hook-form'

const RespiratoryLandingStep = ({
  applicant,
  usageCode,
  setRequirementsMet,
  onChangeSelection,
  onShowHealthHistoryDrawer,
}) => {
  const { setStepHandler } = useContext(StepHandlerContext)
  const [requiredFields, setRequiredFields] = useState([])
  const [updatedQuestions, setUpdatedQuestions] = useState([])
  const [removedQuestions, setRemovedQuestions] = useState([])
  const { updateQuestions, deleteQuestions } = useApplicantsDispatcher()

  const { watch, getValues } = useFormContext()

  let fieldsToWatch = []

  useEffect(() => {
    fieldsToWatch.push(watch(requiredFields))
  }, [requiredFields])

  useEffect(() => {
    setRequirementsMet(getValues(requiredFields).some((fieldValue) => fieldValue === 'YES'))
  }, [fieldsToWatch])

  useEffect(() => {
    setStepHandler({
      onClickNext: async () => {
        const isOk = await saveAnswersForTextValue(applicant, updatedQuestions, removedQuestions)
        if (isOk) {
          updateQuestions(updatedQuestions)
          deleteQuestions(removedQuestions)
          setRemovedQuestions([])
          return true
        }
        return false
      },
    })
  }, [updatedQuestions, removedQuestions])

  const handleQuestionsChange = (updatedQuestions) => {
    if (isEmpty(requiredFields)) {
      const required = updatedQuestions
        .filter((question) => question.reqtOptSubGroupCd === DIAG_GRP)
        .map((question) => question.requirementOptionCd)
      setRequiredFields(required)
    }
    setUpdatedQuestions(updatedQuestions)
    onChangeSelection(updatedQuestions)
  }

  const handleQuestionsRemoved = (removedQuestions) => {
    setRemovedQuestions((prevRemovedQuestions) => {
      const newRemovedQuestions = removedQuestions.filter((newQuestion) => {
        return !prevRemovedQuestions.some(
          (prevQuestion) =>
            prevQuestion.benCd === newQuestion.benCd &&
            prevQuestion.requirementId === newQuestion.requirementId &&
            prevQuestion.requirementOptionCd === newQuestion.requirementOptionCd &&
            prevQuestion.requirementOptionUsageCd === newQuestion.requirementOptionUsageCd &&
            prevQuestion.provisionSeqNum === newQuestion.provisionSeqNum,
        )
      })
      return [...prevRemovedQuestions, ...newRemovedQuestions]
    })
  }

  return (
    <>
      <div className="mb-4">
        You told us that {applicant.firstName} has had a lung disorder or respiratory disease. Please help us understand
        the situation by answering the following questions.
      </div>
      <div className="mb-4">
        For questions or help completing this form, you can call Customer Service at 800-247-6875 on Monday through
        Friday from 8:00 a.m. - 8:00 p.m., ET
      </div>
      <div className="mb-4">
        If this was a mistake, you can&nbsp;
        <Link onClick={onShowHealthHistoryDrawer}>go back to the health history questions and change your answer.</Link>
      </div>
      <QuestionList
        applicant={applicant}
        usageCode={usageCode}
        onQuestionsChange={handleQuestionsChange}
        onQuestionsRemoved={handleQuestionsRemoved}
        className="mb-0"
      />
    </>
  )
}

export default RespiratoryLandingStep
