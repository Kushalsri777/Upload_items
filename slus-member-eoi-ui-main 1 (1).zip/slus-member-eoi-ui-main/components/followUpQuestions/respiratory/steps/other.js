import { saveAnswersForTextValue } from '@/common/utils/api'
import { useApplicantsDispatcher } from '@/components/context/Applicants.context'
import { StepHandlerContext } from '@/components/context/StepHandler.context'
import { QuestionList } from '@/components/healthHistoryQuestions/questionList'
import { useContext, useEffect, useState } from 'react'

const buildTextAreaConfig = (name = '') => {
  const textAreaConfig = {
    LungOthSympTr: {
      placeholder: `Symptoms that ${name} has experienced`,
      maxLength: 500,
      showExternalLabel: true,
      rows: 8,
      className: 'mt-2 max-w-md',
      style: {
        minHeight: '160px',
        resize: 'none',
        borderRadius: 0,
        borderColor: '#e5e7eb',
      },
    },
    LungOthTreatTr: {
      placeholder: 'Treatment plan',
      maxLength: 500,
      showExternalLabel: true,
      rows: 8,
      className: 'mt-2 max-w-md',
      style: {
        minHeight: '160px',
        resize: 'none',
        borderRadius: 0,
        borderColor: '#e5e7eb',
      },
    },
  }

  return textAreaConfig
}

const OtherStep = ({ applicant, usageCode, onChangeSelection }) => {
  const { setStepHandler } = useContext(StepHandlerContext)
  const [questions, setQuestions] = useState([])
  const { updateQuestions } = useApplicantsDispatcher()

  useEffect(() => {
    setStepHandler({
      onClickNext: async () => {
        const isOk = await saveAnswersForTextValue(applicant, questions)
        if (isOk) {
          updateQuestions(questions)
          return true
        }
        return false
      },
    })
  }, [applicant, questions, setStepHandler, updateQuestions])

  const handleQuestionsChange = (updatedQuestions) => {
    setQuestions(updatedQuestions)
    onChangeSelection(updatedQuestions)
  }

  return (
    <>
      <div className="mb-4">
        <div>
          You told us that {applicant.firstName} has experienced a different respiratory disease or disorder. Please
          help us understand the situation by answering the following questions.
        </div>
      </div>
      <QuestionList
        applicant={applicant}
        usageCode={usageCode}
        onQuestionsChange={handleQuestionsChange}
        className="mb-0"
        textAreaConfig={buildTextAreaConfig(applicant.firstName)}
      />
    </>
  )
}

export default OtherStep
