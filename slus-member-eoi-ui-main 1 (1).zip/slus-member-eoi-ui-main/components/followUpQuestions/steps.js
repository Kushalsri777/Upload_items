import { RespiratorySteps } from './respiratory/stepConfig'
import { HeartSteps } from './heartConditions/stepConfig'
import { MedicationSteps } from './medication/stepConfig'

class FollowUpStepConfig {
  constructor(name, steps) {
    this.name = name
    this.steps = steps
  }
}

const FollowUpSteps = [
  {
    usageCode: 'LungDiseaseFlUp',
    steps: RespiratorySteps,
  },
  {
    usageCode: 'HghBldPreFolUp',
    steps: HeartSteps,
  },
  {
    usageCode: 'MedicationsFlUp',
    steps: MedicationSteps,
  },
]

export const buildFollowUpStepConfigs = (affirmativeQuestions) => {
  return affirmativeQuestions.map((affirmativeQuestion) => {
    const followUpStepName = affirmativeQuestion.optionName
    const followUpUsageCode = affirmativeQuestion.followUpRequirementOptionUsageCd
    const followUpSteps = FollowUpSteps.find((steps) => steps.usageCode === followUpUsageCode).steps
    return new FollowUpStepConfig(followUpStepName, followUpSteps)
  })
}
