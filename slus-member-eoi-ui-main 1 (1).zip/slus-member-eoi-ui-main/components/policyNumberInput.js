import { useEffect, useRef, useState } from 'react'
import { Controller, useFormContext } from 'react-hook-form'
import ReCAPTCHA from 'react-google-recaptcha'
import clsx from 'clsx'
import { Button, TextField, Toasts } from '@/components/helios-components'
import { useLegacyApplication, useLegacyApplicationDispatcher } from './context/LegacyApplication.context'
import { useApplicantsDispatcher } from './context/Applicants.context'
import { DEFAULT, REQUIRED, POLICY } from '@/common/enums/errorMessage'
import CriticalIllnessModal from '@/components/login/criticalIllnessModal'
import { useRouter } from 'next/navigation'

const FIELD_NAME = 'policyNumber'

function PolicyNumberInput({ children, onClick }) {
  const recaptchaRef = useRef()
  const router = useRouter()
  const { control, handleSubmit, getFieldState, trigger, watch, setValue } = useFormContext()
  const policyNumber = watch(FIELD_NAME)

  const { sessionInfo } = useLegacyApplication()

  const { updateLoginMethod, updatePolicyInfo, updateRedirectUrl } = useLegacyApplicationDispatcher()

  const { updatePolicy } = useApplicantsDispatcher()

  const [toastError, setToastError] = useState(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const [recaptchaSiteKey, setRecaptchaSiteKey] = useState(null)
  const [showCriticalIllnessModal, setShowCriticalIllnessModal] = useState(false)

  useEffect(() => {
    async function fetchData() {
      await fetchReCaptchaSiteKey()
      if (sessionInfo?.policyNumber) {
        setValue(FIELD_NAME, sessionInfo.policyNumber)
      }
    }
    fetchData()
  }, [sessionInfo?.policyNumber, setValue])

  const closeCriticalIllnessModal = () => {
    setShowCriticalIllnessModal(false)
  }

  const fetchPolicy = async () => {
    if (!policyNumber) {
      console.log('Policy number required to fetch policy')
      setToastError(REQUIRED)
      return
    }

    try {
      const url = `${process.env.NEXT_PUBLIC_BASE_URL}/policies/${policyNumber}`
      const response = await fetch(url, {
        method: 'GET',
      })
      const responseValue = await response.json()

      if (responseValue?.redirectUrl) {
        updateRedirectUrl(responseValue.redirectUrl)
        updatePolicyInfo(responseValue)
        updatePolicy(responseValue)

        await router.push('/redirect')
        return
      }

      if ('Not Found' === responseValue.message) {
        setToastError(POLICY)
      } else if (response.status === 409 && 'CRITICAL_ILLNESS_POLICY' === responseValue.message) {
        setShowCriticalIllnessModal(true)
      } else {
        updatePolicyInfo(responseValue)
        updatePolicy(responseValue)
        updateLoginMethod(responseValue.idType)

        return responseValue
      }
    } catch (error) {
      console.log(error)
      setToastError(POLICY)
    }
  }

  const startSession = async (recaptchaKey) => {
    if (!recaptchaKey) {
      console.log('ReCaptcha token required to start session')
      setToastError(POLICY)
      return
    }

    try {
      const url = `${process.env.NEXT_PUBLIC_BASE_URL}/sessions`
      await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `g-recaptcha-response=${recaptchaKey}`,
      })
    } catch (error) {
      console.log(error)
      setToastError(POLICY)
    }
  }

  const fetchReCaptchaToken = async () => {
    try {
      const newRecaptchaToken = await recaptchaRef.current.executeAsync()
      recaptchaRef.current.reset()
      return newRecaptchaToken
    } catch (error) {
      console.log(error)
      setToastError(DEFAULT)
    }
  }

  const fetchReCaptchaSiteKey = async () => {
    try {
      const url = `${process.env.NEXT_PUBLIC_BASE_URL}/settings`
      const response = await fetch(url, {
        method: 'GET',
      })
      const responseValue = await response.json()
      setRecaptchaSiteKey(responseValue?.recaptchaKeySite)
    } catch (error) {
      console.log(error)
    }
  }

  const isFieldValid = async () => {
    return await trigger(FIELD_NAME).then((res) => {
      if (!res) {
        const fieldState = getFieldState(FIELD_NAME)
        if (fieldState.invalid) {
          console.log(`toastError: ${fieldState.error?.type}`)
          const error = fieldState.error.type
          if ('required' === error) {
            setToastError(REQUIRED)
          } else if ('pattern' === error) {
            setToastError(REQUIRED)
          } else if ('validate' === error) {
            setToastError(POLICY)
          }
        }
      }
      return res
    })
  }

  const processForm = async () => {
    setToastError(null)
    setIsProcessing(true)

    /*** check for valid policy number ***/
    const isValid = await isFieldValid()
    if (!isValid) {
      console.log('policy number field is not valid')
      setIsProcessing(false)
      return
    }

    /*** fetch recaptcha token ***/
    const recaptchaKey = await fetchReCaptchaToken()
    if (!recaptchaKey) {
      console.log('failed to receive recaptcha token')
      setIsProcessing(false)
      return
    }

    await startSession(recaptchaKey)

    /*** fetch policy object ***/
    const policy = await fetchPolicy()
    if (policy) {
      updatePolicyInfo(policy)
      updatePolicy(policy)
      onClick(policy)
    } else {
      console.log('failed to receive policy')
    }

    setIsProcessing(false)
  }

  const handleFormSubmit = () => {
    processForm()
  }

  const handleOnClickLogin = () => {
    processForm()
  }

  return (
    <>
      <form onSubmit={handleSubmit(handleFormSubmit)}>
        <Controller
          render={({ field, fieldState }) => {
            const { ref, ...fields } = field
            return (
              <TextField
                {...fields}
                id={field.name}
                className="my-sl16"
                label="Group Policy Number"
                error={fieldState.invalid}
                helperText={fieldState.error?.message}
                autoComplete="off"
              />
            )
          }}
          control={control}
          name={FIELD_NAME}
          rules={{
            required: {
              value: true,
              message: '',
            },
            pattern: {
              value: /^(\d+)$/,
              message: '',
            },
            validate: (value) => {
              if (value > 0) {
                setToastError(null)
                return true
              } else {
                return ''
              }
            },
          }}
        />
        {children}
        <div className="mb-sl16" style={{ marginTop: '40px' }}>
          <div className={clsx({ hidden: !isProcessing })}>
            <Button disabled={isProcessing}>
              <i className="fa-solid fa-spinner fa-spin" />
            </Button>
          </div>
          <div className={clsx({ hidden: isProcessing })}>
            <Button onClick={handleOnClickLogin}>Log in</Button>
          </div>
        </div>
      </form>
      {toastError ? (
        <Toasts
          items={[
            {
              id: 'toast_error_message_id',
              children: toastError,
              variant: 'danger',
            },
          ]}
          onClick={() => setToastError(null)}
        />
      ) : null}
      {recaptchaSiteKey ? <ReCAPTCHA sitekey={recaptchaSiteKey} ref={recaptchaRef} size="invisible" /> : null}
      <CriticalIllnessModal showModal={showCriticalIllnessModal} closeModal={closeCriticalIllnessModal} />
    </>
  )
}

export default PolicyNumberInput
