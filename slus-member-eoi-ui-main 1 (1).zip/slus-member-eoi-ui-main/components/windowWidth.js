import { useState, useEffect, useRef } from 'react'

const DEFAULT_SIZES = [
  {
    name: 'xs',
    value: 360,
    dSize: '100%',
  },
  {
    name: 'sm',
    value: 600,
    dSize: '100%',
  },
  {
    name: 'md',
    value: 905,
    dSize: '50%',
  },
  {
    name: 'lg',
    value: 1240,
    dSize: '50%',
  },
]

function WindowWidth({ timeout = 500, onChange, sizes = DEFAULT_SIZES }) {
  const hasWindow = typeof window !== 'undefined'
  const [windowWidth, setWindowWidth] = useState(hasWindow ? window.innerWidth : null)
  const [breakpointSizeArray, setBreakpointSizeArray] = useState(DEFAULT_SIZES)
  const timeoutId = useRef()

  useEffect(() => {
    setBreakpointSizeArray(sizes?.sort((a, b) => a.value - b.value))
  }, [sizes])

  useEffect(() => {
    const handleEventListenerAction = () => {
      clearTimeout(timeoutId.current)
      timeoutId.current = setTimeout(() => {
        setWindowWidth(window.innerWidth)
      }, timeout)
    }

    window.addEventListener('resize', handleEventListenerAction)
    return () => {
      window.removeEventListener('resize', handleEventListenerAction)
    }
  }, [timeout])

  useEffect(() => {
    let sizeObj = breakpointSizeArray.find((s) => windowWidth <= s.value)
    if (!sizeObj) {
      sizeObj = breakpointSizeArray[breakpointSizeArray.length - 1]
    }

    if (typeof onChange === 'function') {
      onChange(sizeObj)
    }
  }, [windowWidth, onChange, breakpointSizeArray])

  return <></>
}

export default WindowWidth
