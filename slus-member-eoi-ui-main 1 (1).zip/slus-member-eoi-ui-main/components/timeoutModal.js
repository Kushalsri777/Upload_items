import { useCallback, useContext, useEffect, useState } from 'react'
import { Modal, ModalBody, ModalFooter, Toasts } from '@/components/helios-components'
import { TIMEOUT_MODAL, TIMEOUT_TOAST } from '@/common/utils/pageText'
import NavButtons from '@/components/navbuttons'
import styles from './timeout.module.css'
import { useRouter } from 'next/navigation'
import { AppContext } from '@/components/context/app.context'
import { cloneDeep } from 'lodash'

const {
  heading,
  body: { values },
} = TIMEOUT_MODAL
const { content } = TIMEOUT_TOAST

function TimeoutModal() {
  const [modalShow, setModalShow] = useState(false)
  const closeModal = () => setModalShow(false)
  const router = useRouter()
  const { timeoutInfo, updateTimeoutInfo, clearTimeouts } = useContext(AppContext)

  const [toastTimeout] = useState(content)

  useEffect(() => {
    /**
     * Overwritten the fetch function , in order to simulate an interceptor for any API call.
     * This is needed to add the logic of the timeout feature in only on place.
     * @type {(input: (RequestInfo | URL), init?: RequestInit) => Promise<Response>}
     */
    const fetch = window.fetch
    window.fetch = (...args) =>
      (async (args) => {
        const response = await fetch(...args)

        if (
          timeoutInfo.isUserLogged &&
          response.ok &&
          response.url.includes('/api/') &&
          !response.url.endsWith('/api/settings') &&
          !response.url.endsWith('/api/sessions')
        ) {
          clearTimeouts()
        }

        const isMethodTypeForSessionCreation = args[1]?.method?.toLowerCase() === 'post'

        if (
          !timeoutInfo.isUserLogged &&
          response.ok &&
          response.url.endsWith('/api/sessions') &&
          isMethodTypeForSessionCreation
        ) {
          const timeoutInfoClone = cloneDeep(timeoutInfo)
          timeoutInfoClone.isUserLogged = true
          timeoutInfoClone.displayTimeoutToast = false
          updateTimeoutInfo(cloneDeep(timeoutInfoClone))
        }
        return response
      })(args)
  }, [clearTimeouts, timeoutInfo, updateTimeoutInfo])

  const pingServer = useCallback(async () => {
    const url = `${process.env.NEXT_PUBLIC_BASE_URL}/health/ping`
    try {
      await fetch(url, {
        method: 'GET',
      })
      clearTimeouts()
    } catch (error) {
      console.error('Error trying to call the health/ping API')
    }
  }, [clearTimeouts])

  useEffect(() => {
    ;(async () => {
      let idleTimeout = timeoutInfo.idleInactivityTimeoutInMilliseconds
      let idleLogout = timeoutInfo.sessionTimeoutInMilliseconds
      const timeoutInfoClone = cloneDeep(timeoutInfo)

      const logOut = async () => {
        clearTimeoutsObjects()
        closeModal()
        await router.push('/login')
      }

      const clearTimeoutsObjects = () => {
        clearTimeouts(true)
      }

      const sessionTimeout = () => {
        if (!timeoutInfoClone.isUserLogged) {
          logOut()
          return
        }

        timeoutInfoClone.idleEventTimerID = setTimeout(() => {
          setModalShow(true)
        }, idleTimeout)

        timeoutInfoClone.idleLogoutEventTimerID = setTimeout(async () => {
          await logOut()
        }, idleLogout)

        timeoutInfoClone.lastTimeUpdated = new Date()
        updateTimeoutInfo(timeoutInfoClone)
      }

      if (
        timeoutInfoClone.idleLogoutEventTimerID &&
        timeoutInfoClone.idleEventTimerID &&
        !timeoutInfoClone.isUserLogged
      ) {
        await logOut()
        return
      }
      if (
        !timeoutInfoClone.idleLogoutEventTimerID &&
        !timeoutInfoClone.idleEventTimerID &&
        timeoutInfoClone.isUserLogged
      ) {
        sessionTimeout()
      }
    })()

    /**
     * EventHandler will be executed when any of the next events is triggered [Click , KeyPress].
     * This handler will Ping the server to extend the session only if the user is logged previously and
     * if the idleInactivityTimeout already passed. E.x(after 13 minutes) ,if any of the events mentioned above is
     * triggered , it will call the API '/health/ping' to extend the session.
     *
     * @returns {Promise<void>}
     */
    const eventHandler = async (event) => {
      const didUserClickCloseButton = event?.target?.innerHTML === 'Close'
      if (timeoutInfo.isUserLogged && timeoutInfo.lastTimeUpdated && !modalShow && !didUserClickCloseButton) {
        const currentDate = new Date()
        const diffInMilliseconds = Math.abs(currentDate - timeoutInfo.lastTimeUpdated)
        if (diffInMilliseconds >= timeoutInfo.idleInactivityTimeoutInMilliseconds) {
          await pingServer()
          closeModal()
        }
      }
    }

    const events = ['click', 'keypress']

    for (const e in events) {
      window.addEventListener(events[e], eventHandler)
    }

    return () => {
      for (let e in events) {
        window.removeEventListener(events[e], eventHandler)
      }
    }
  }, [clearTimeouts, modalShow, pingServer, router, timeoutInfo, updateTimeoutInfo])

  const onClickPrimary = async () => {
    await pingServer()
    closeModal()
  }
  const closeToastTimeout = () => {
    const timeoutInfoClone = cloneDeep(timeoutInfo)
    timeoutInfoClone.displayTimeoutToast = false
    updateTimeoutInfo(cloneDeep(timeoutInfoClone))
  }

  return (
    <>
      {timeoutInfo.displayTimeoutToast ? (
        <Toasts
          className={styles.timeoutToast}
          items={[
            {
              id: 'toastTimeout',
              children: toastTimeout,
              variant: 'info',
            },
          ]}
          onClose={() => closeToastTimeout()}
        />
      ) : null}

      <Modal show={modalShow} id="show-modal" heading={heading} lang="en" onHide={() => closeModal()}>
        <ModalBody>
          {values.map((p, i) => {
            if (i === values.length - 1) {
              return <div key={`timeout_modal_para_${i}`}>{p}</div>
            }
            return (
              <div className="mb-4" key={`timeout_modal_para_${i}`}>
                {p}
              </div>
            )
          })}
        </ModalBody>
        <ModalFooter>
          <NavButtons
            primaryColClassName={styles.continueButton}
            secondaryColClassName={styles.closeButton}
            labelPrimary="Continue application"
            onClickPrimary={onClickPrimary}
            onClickSecondary={closeModal}
            labelSecondary={'Close'}
          />
        </ModalFooter>
      </Modal>
    </>
  )
}

export default TimeoutModal
