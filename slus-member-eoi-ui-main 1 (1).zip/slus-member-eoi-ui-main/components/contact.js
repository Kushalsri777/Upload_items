import { useFormContext, Controller } from 'react-hook-form'
import { TextField } from '@/components/helios-components'
import GroupLabel from './groupLabel'
import { EMAIL_REGEX, PHONE_NUMBER_REGEX } from '@/common/enums/regex'
import { INVALID_PHONE_NUMBER, REQUIRED_FIELDS } from '@/common/enums/constant'
import clsx from 'clsx'
import demographicsViewOnlyStyles from './demographics.module.css'

function Contact({ isViewOnly = false }) {
  const { control, getValues } = useFormContext()

  return (
    <>
      <div className="mb-5">
        <GroupLabel label="Contact Information" />
        <div className={clsx('mb-4', { [demographicsViewOnlyStyles.viewOnly]: isViewOnly })}>
          <Controller
            render={({ field, fieldState }) => {
              const { ref, ...fields } = field
              return (
                <TextField
                  {...fields}
                  icon="email"
                  iconPosition="after"
                  id={field.name}
                  label="Email"
                  error={fieldState.invalid}
                  helperText={fieldState.error?.message}
                  disabled={isViewOnly}
                />
              )
            }}
            rules={{
              required: {
                value: true,
                message: REQUIRED_FIELDS,
              },
              pattern: {
                value: EMAIL_REGEX,
                message: 'Only valid email allowed',
              },
            }}
            control={control}
            name="applicant.employeeEmailAddress"
          />
        </div>
        <div className={clsx('mb-4', { [demographicsViewOnlyStyles.viewOnly]: isViewOnly })}>
          <Controller
            render={({ field, fieldState }) => {
              const { ref, ...fields } = field
              return (
                <TextField
                  {...fields}
                  id={field.name}
                  icon="email"
                  iconPosition="after"
                  label="Confirm Email"
                  className="my-sl16"
                  error={fieldState.invalid}
                  helperText={fieldState.error?.message}
                  disabled={isViewOnly}
                />
              )
            }}
            rules={{
              required: {
                value: true,
                message: REQUIRED_FIELDS,
              },

              validate: (value) => {
                const email = getValues('applicant.employeeEmailAddress')
                if (email !== value) {
                  return 'Confirm email must match with the email field.'
                }
                return true
              },
            }}
            control={control}
            name="applicant.confirmEmail"
          />
        </div>
        <div className={clsx('mb-4', { [demographicsViewOnlyStyles.viewOnly]: isViewOnly })}>
          <Controller
            render={({ field, fieldState }) => {
              const { ref, ...fields } = field
              return (
                <TextField
                  {...fields}
                  id={field.name}
                  icon="call"
                  iconPosition="before"
                  label="Primary phone number"
                  error={fieldState.invalid}
                  helperText={fieldState.error?.message}
                  disabled={isViewOnly}
                />
              )
            }}
            rules={{
              required: {
                value: true,
                message: REQUIRED_FIELDS,
              },
              pattern: {
                value: PHONE_NUMBER_REGEX,
                message: INVALID_PHONE_NUMBER,
              },
            }}
            control={control}
            name="applicant.employeeWorkPhoneNumber"
          />
        </div>
      </div>
    </>
  )
}
export default Contact
