'use client'

import Container from 'react-bootstrap/Container'
import Head from 'next/head'
import Navbar from '@/components/navbar'
import Footer from '@/components/footer'

const BASE_PATH = process.env.NEXT_PUBLIC_BASE_PATH || ''

function Layout({ children, disableContainer, disableFooter, disableContactInfo }) {
  return (
    <>
      <Head>
        <title>EOI Member</title>
        <meta name="description" content="EOI Member" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="format-detection" content="telephone=no, date=no, email=no, address=no" />
        <link rel="shortcut icon" href={`${BASE_PATH}/favicon.svg`} type="image/svg+xml" />
        <link rel="apple-touch-icon" href={`${BASE_PATH}/favicon.svg`} />
      </Head>
      <Navbar />
      {disableContainer ? <>{children}</> : <Container>{children}</Container>}
      {disableFooter ? null : <Footer disableContactInfo={disableContactInfo} />}
    </>
  )
}

export default Layout
