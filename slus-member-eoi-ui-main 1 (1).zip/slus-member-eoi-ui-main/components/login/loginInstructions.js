import styles from './loginInstructions.module.css'

import Container from 'react-bootstrap/Container'
import { Link } from '@/components/helios-components'
import { Bold } from '../healthHistoryQuestions/steps/util'

export default function LoginInstructions() {
  return (
    <>
      <Container>
        <div className={styles.explanation}>
          <h2>What to expect with EOI</h2>
          <p>
            Our application will lead you step by step through the process, which usually takes{' '}
            <Bold>less than 15 minutes</Bold>. Your EOI response is <Bold>strictly confidential</Bold> and used to
            determine your eligibility for the insurance coverage you are requesting
          </p>
        </div>
        <div className={styles.steps}>
          <div className={styles.stepItem}>
            <h3>Before you start</h3>
            <p>We&apos;re going to need some medical information, including:</p>
            <ul>
              <li>Doctor&apos;s name and info</li>
              <li>Current list of prescriptions</li>
              <li>Health history</li>
            </ul>
            <p>
              <i>This information will be needed for all applicants</i>.
            </p>
          </div>
          <div className={styles.stepItemLeftBorder}>
            <h3>Providing your history</h3>
            <p>
              You will be asked to answer <Bold>&quot;yes&quot;</Bold> or <Bold>&quot;no&quot;</Bold> to questions about
              certain medical conditions.
            </p>{' '}
            <p>
              If you answer &quot;yes&quot; to any question(s), you are asked to{' '}
              <Bold>provide details of the condition</Bold>, such as dates, treatments, and names of physicians.
              Providing incomplete information may delay your EOI application decision.
            </p>
          </div>
          <div className={styles.stepItemLeftBorder}>
            <h3>After you submit</h3>
            <p>
              We will send you an <Bold>official acknowledgment by email</Bold> that your EOI application was approved
              or we need more information in order to make a decision. This may take up to <Bold>10 business days</Bold>
              .
            </p>
          </div>
        </div>
      </Container>
      <div className={styles.bannerBlock}>
        <div className={styles.bannerBlockInner}>
          <h3>Better coverage in minutes</h3>
          <p>
            To make the right decision for your coverage plan, we need to know a little more about you. By filling out
            the Evidence of Insurability, <Bold>your good health can mean better premiums</Bold>. Collect your necessary
            medical documents to get started for yourself and any accompanying family members.
          </p>
          <p>In no time at all, you&apos;ll be on the road to a tailored solution that meets your needs.</p>
          <div className={styles.beginButton}>
            <Link href="#" showIcon>
              Let&apos;s Begin
            </Link>
          </div>
        </div>
      </div>
    </>
  )
}
