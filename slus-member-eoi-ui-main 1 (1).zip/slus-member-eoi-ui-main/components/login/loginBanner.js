import styles from './loginBanner.module.css'

import React, { Fragment, useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { FormProvider, useForm } from 'react-hook-form'
import { Banner } from '@/components/helios-components'
import LoginConfirmationModal from '@/components/login/loginConfirmationModal'
import OpenStatusEoiApplicationErrorModal from '@/components/login/openStatusEoiApplicationErrorModal'
import LoginModal from '@/components/login/loginModal'
import PolicyNumberInput from '@/components/policyNumberInput'
import { useLegacyApplication, useLegacyApplicationDispatcher } from '../context/LegacyApplication.context'
import { useContinuance } from '../context/Continuance.context'

const BASE_PATH = process.env.NEXT_PUBLIC_BASE_PATH || ''
const BASE_URL = process.env.NEXT_PUBLIC_BASE_URL || ''

export default function LoginBanner() {
  const methods = useForm({
    defaultValues: {
      policyNumber: '',
      loginValue: '',
    },
    mode: 'onTouched',
  })
  const router = useRouter()

  const { policyInfo: policy, caseFormData } = useLegacyApplication()

  const { updateSessionInfo } = useLegacyApplicationDispatcher()

  const { isFinishedOnboarding } = useContinuance()

  const [showLoginModal, setShowLoginModal] = useState(false)
  const [showLoginConfirmModal, setShowLoginConfirmModal] = useState(false)
  const [showOpenStatusEoiApplicationErrorModal, setOpenStatusEoiApplicationErrorModal] = useState(false)

  useEffect(() => {
    const fetchSessionData = async () => {
      try {
        const url = `${BASE_URL}/sessions`
        const response = await fetch(url, { method: 'GET' })
        const responseValue = await response.json()
        updateSessionInfo(responseValue || {})
      } catch (error) {
        console.log(error)
      }
    }

    fetchSessionData()
  }, [])

  const handleOnClickLoginModal = (caseStatusCode) => {
    setShowLoginModal(false)
    if (caseStatusCode === 'COMPLETE') {
      setOpenStatusEoiApplicationErrorModal(true)
    } else {
      setShowLoginConfirmModal(true)
    }
  }

  const handleOnClickConfirmModalPrimary = () => {
    setShowLoginConfirmModal(false)
    if (isFinishedOnboarding) {
      router.push('/dashboard')
    } else {
      router.push('/onboarding')
    }
  }

  const handleOnClickConfirmModalSecondary = () => {
    setShowLoginConfirmModal(false)
    setShowLoginModal(true)
  }

  const handleOnClickPolicyNumberInput = (policy) => {
    if (policy) {
      setShowLoginModal(true)
    }
  }

  return (
    <div className={styles.bannerContainer}>
      <Banner
        heading="Safeguard your tomorrow."
        body="With our digital EOI form, you’ll be on the fast-track to coverage in a few simple steps."
        imageSrc={{
          xl: `${BASE_PATH}/images/login-bg-1440px.png`,
          lg: `${BASE_PATH}/images/login-bg-1440px.png`,
          md: `${BASE_PATH}/images/login-bg-1240px.png`,
          sm: `${BASE_PATH}/images/login-bg-905px.png`,
          xs: `${BASE_PATH}/images/login-bg-600px.png`,
        }}
        variant="login">
        <Fragment key=".0">
          <div data-cy="welcome_home_page" className="mb-6 text-3xl" style={{ fontSize: '28px' }}>
            Start your Evidence of Insurability application
          </div>
          <FormProvider {...methods}>
            <PolicyNumberInput onClick={handleOnClickPolicyNumberInput} />
            <LoginModal showModal={showLoginModal} setShowModal={setShowLoginModal} onClick={handleOnClickLoginModal} />
            <OpenStatusEoiApplicationErrorModal
              showModal={showOpenStatusEoiApplicationErrorModal}
              setShowModal={setOpenStatusEoiApplicationErrorModal}
            />
            <LoginConfirmationModal
              policy={policy}
              employee={caseFormData?.employeeInfo}
              showModal={showLoginConfirmModal}
              setShowModal={setShowLoginConfirmModal}
              onClickPrimary={handleOnClickConfirmModalPrimary}
              onClickSecondary={handleOnClickConfirmModalSecondary}
            />
          </FormProvider>
        </Fragment>
      </Banner>
    </div>
  )
}
