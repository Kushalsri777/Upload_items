import { Button, Modal, ModalBody, ModalFooter } from '@/components/helios-components'
import { useLegacyApplicationDispatcher } from '../context/LegacyApplication.context'
import { useFormContext } from 'react-hook-form'
function OpenStatusEoiApplicationErrorModal({ showModal, setShowModal }) {
  const { deleteLoginMethodValue } = useLegacyApplicationDispatcher
  const { resetField } = useFormContext()

  const closeModal = () => {
    resetField('loginValue')
    deleteLoginMethodValue()
    setShowModal(false)
  }

  return (
    <>
      <Modal
        show={showModal}
        id="show-modal"
        heading="Application submitted and pending"
        lang="en"
        onHide={() => closeModal()}>
        <ModalBody>
          <div>
            <p>
              An application has already been submitted for the credentials provided. If you have already submitted an
              application please check your email for an acknowledgment.
              <br />
              <br />
              Please allow 10 business days for processing. If you have any questions, please contact your employer.
            </p>
          </div>
        </ModalBody>
        <ModalFooter>
          <Button variant="primary" id="action-button" onClick={closeModal}>
            Okay
          </Button>
        </ModalFooter>
      </Modal>
    </>
  )
}

export default OpenStatusEoiApplicationErrorModal
