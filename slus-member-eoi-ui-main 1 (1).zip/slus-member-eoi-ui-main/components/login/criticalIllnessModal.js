import { Button, Modal, ModalBody, ModalFooter } from '@/components/helios-components'

function CriticalIllnessModal({ showModal, closeModal }) {
  return (
    <>
      <Modal show={showModal} id="show-modal" heading="Critical Illness" lang="en" onHide={() => closeModal()}>
        <ModalBody>
          <div>
            <p>
              Group Statement of Health applications for Critical Illness benefits cannot be submitted online. To obtain
              a paper form, please contact your Benefits Administrator or our Customer Service Center at 1-800-247-6875
            </p>
          </div>
        </ModalBody>
        <ModalFooter>
          <Button variant="primary" id="action-button" onClick={closeModal}>
            Okay
          </Button>
        </ModalFooter>
      </Modal>
    </>
  )
}

export default CriticalIllnessModal
