import { useEffect, useState } from 'react'
import { Controller, useFormContext } from 'react-hook-form'
import { v4 as uuid } from 'uuid'
import InputMask from 'react-input-mask'
import { Button, Modal, ModalBody, ModalFooter, TextField, Toasts } from '@/components/helios-components'
import { useLegacyApplication, useLegacyApplicationDispatcher } from '../context/LegacyApplication.context'
import { useRequiredApplicantsDispatcher } from '../context/RequiredApplicants.context'
import { useApplicantsDispatcher } from '../context/Applicants.context'
import { useContinuanceDispatcher } from '../context/Continuance.context'
import { SSN, getLoginMethod } from '@/common/enums/loginMethod'
import { DEFAULT } from '@/common/enums/errorMessage'
import enroller, { TYPE_SORT } from '@/common/enums/enroller'
import { DATE_OF_BIRTH } from '@/common/enums/regex'
import { IN_PROGRESS } from '@/common/enums/caseStatusCode'
import { DASHBOARD, ONBOARDING } from '@/common/enums/applicationContinuanceLocation'

const { MM_DD_YYYY } = DATE_OF_BIRTH

function LoginModal({ showModal, setShowModal, onClick }) {
  const { policyInfo, sessionInfo, loginMethod } = useLegacyApplication()

  const { updateCaseFormData, updateCaseInfo, updateLoginMethodValue, deleteLoginMethodValue } =
    useLegacyApplicationDispatcher()

  const { updateEmployee, updateSpouse, updateChildren, updateIsKnownUser } = useApplicantsDispatcher()

  const { setEmployeeRequired, setSpouseRequired, setChildrenRequired } = useRequiredApplicantsDispatcher()

  const {
    updateAppLocation,
    updateCurrentStepIndex,
    updateIsUserInProgress,
    updateIsFinishedOnboarding,
    updateIsPlaceholder,
  } = useContinuanceDispatcher()

  const { control, resetField, trigger, watch, setValue } = useFormContext()
  const [toastError, setToastError] = useState(null)
  const [loginMethodObj, setLoginMethodObj] = useState(SSN)
  const [isProcessing, setIsProcessing] = useState(false)

  const loginValue = watch('loginValue')

  useEffect(() => {
    if (policyInfo?.idType) {
      setLoginMethodObj(getLoginMethod(loginMethod))
      if (showModal && sessionInfo?.idType === loginMethod && sessionInfo?.employeeId !== '') {
        setValue('loginValue', sessionInfo.employeeId)
      }
    }
  }, [policyInfo?.idType, sessionInfo?.employeeId, sessionInfo?.idType, setValue, showModal])

  const fetchApplicantCase = async () => {
    if (!loginValue) {
      console.log('Login value required to fetch applicant case')
      return
    }

    try {
      setIsProcessing(true)
      const url = `${process.env.NEXT_PUBLIC_BASE_URL}/cases/search`
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ employeeId: encodeURIComponent(loginValue) }),
      })
      const responseValue = await response.json()
      updateCaseInfo(responseValue)
      updateLoginMethodValue(loginValue)

      const {
        employeeApplicantFlag,
        spouseApplicantFlag,
        childApplicantFlag,
        employee,
        caseStatusCode,
        currentStepIndex,
        finishedOnboarding,
        placeholder,
      } = responseValue

      updateIsKnownUser(caseStatusCode === IN_PROGRESS)

      setEmployeeRequired(employeeApplicantFlag)
      setSpouseRequired(spouseApplicantFlag)
      setChildrenRequired(childApplicantFlag)

      updateIsUserInProgress(currentStepIndex > 0)
      updateCurrentStepIndex(currentStepIndex)
      updateAppLocation(finishedOnboarding ? DASHBOARD : ONBOARDING)
      updateIsFinishedOnboarding(finishedOnboarding)
      updateIsPlaceholder(placeholder)

      const transformDependent = ({
        seqNum,
        firstName,
        lastName,
        gender,
        dateOfBirth,
        lastUpdatedDate,
        processStatus,
        heightFeet,
        heightInches,
        weight,
      }) => ({
        seqNum: seqNum,
        firstName: firstName,
        lastName: lastName,
        genderCode: gender,
        dateOfBirth: MM_DD_YYYY.convert(dateOfBirth),
        heightFeet: heightFeet,
        heightInches: heightInches,
        weight: weight,
        status: processStatus,
        lastUpdatedDate: lastUpdatedDate,
        acknowledgements: {
          fraudWarning: false,
          hipaaAuth: false,
        },
      })

      const children = responseValue?.children?.map(transformDependent)
      updateChildren(children || [])

      if (responseValue?.partner) {
        updateSpouse({
          firstName: responseValue?.partner?.firstName,
          lastName: responseValue?.partner?.lastName,
          genderCode: responseValue?.partner?.gender,
          dateOfBirth: MM_DD_YYYY.convert(responseValue?.partner?.dateOfBirth),
          email: responseValue?.partner?.email,
          heightFeet: responseValue?.partner?.heightFeet,
          heightInches: responseValue?.partner?.heightInches,
          weight: responseValue?.partner?.weight,
          status: responseValue?.partner?.processStatus,
          lastUpdatedDate: responseValue?.partner?.lastUpdatedDate,
        })
      }

      updateEmployee({
        firstName: responseValue.employeeInfo?.firstName,
        lastName: responseValue.employeeInfo?.lastName,
        genderCode: responseValue.employeeInfo?.gender,
        heightFeet: responseValue.employeeInfo?.heightFeet,
        heightInches: responseValue.employeeInfo?.heightInches,
        weight: responseValue.employeeInfo?.weight,
        dateOfBirth: MM_DD_YYYY.convert(responseValue.employeeInfo?.dateOfBirth),
        street: responseValue?.liveAndWork?.streetAddress,
        city: responseValue?.liveAndWork?.city,
        state: responseValue?.liveAndWork?.state,
        zip: responseValue?.liveAndWork?.zipCode,
        email: responseValue?.liveAndWork?.email,
        emailConfirm: responseValue?.liveAndWork?.email,
        phone: responseValue?.liveAndWork?.phoneNumber,
        occupation: responseValue?.liveAndWork?.occupation,
        locationCode: responseValue?.liveAndWork?.location,
        coverages: employee?.coverages,
        applicantStatusCode: employee?.applicantStatusCode,
        status: responseValue.employeeInfo?.processStatus,
        lastUpdatedDate: responseValue?.partner?.lastUpdatedDate,
      })

      const isKnownUser = responseValue?.caseStatusCode === IN_PROGRESS
      updateIsKnownUser(isKnownUser)

      const applicants = []
      const employeeInfo = {}
      if (isKnownUser) {
        if (responseValue?.liveAndWork) {
          employeeInfo.employeeAddressLine1 = responseValue?.liveAndWork?.streetAddress
          employeeInfo.employeeAddressCity = responseValue?.liveAndWork?.city
          employeeInfo.employeeAddressStateCode = responseValue?.liveAndWork?.state
          employeeInfo.employeeAddressPostalCode = responseValue?.liveAndWork?.zipCode
          employeeInfo.employeeOccupation = responseValue?.liveAndWork?.occupation
          employeeInfo.locationCode = responseValue?.liveAndWork?.location
          employeeInfo.employeeEmailAddress = responseValue?.liveAndWork?.email
          employeeInfo.confirmEmail = responseValue?.liveAndWork?.email
          employeeInfo.employeeWorkPhoneNumber = responseValue?.liveAndWork?.phoneNumber
          employeeInfo.employeeMobilePhoneNumber = responseValue?.liveAndWork?.phoneNumber
        }
        if (responseValue?.employeeInfo) {
          employeeInfo.firstName = responseValue?.employeeInfo?.firstName
          employeeInfo.lastName = responseValue?.employeeInfo?.lastName
          employeeInfo.genderCode = responseValue?.employeeInfo?.gender
          employeeInfo.dateOfBirth = responseValue?.employeeInfo?.dateOfBirth
          employeeInfo.idType = loginValue
        }
        if (responseValue?.employeeApplicantFlag) {
          const applicant = {
            heightFeet: responseValue?.employeeInfo?.heightFeet,
            heightInches: responseValue?.employeeInfo?.heightInches,
            weight: responseValue?.employeeInfo?.weight,
            sequenceNumber: responseValue?.employee?.sequenceNumber,
            firstName: responseValue?.employeeInfo?.firstName,
            lastName: responseValue?.employeeInfo?.lastName,
          }
          applicants.push({
            id: uuid(),
            coverages: responseValue?.employee?.coverages,
            applicantStatusCode: responseValue?.employee?.applicantStatusCode,
            type: enroller.EMPLOYEE.type,
            applicantType: enroller.EMPLOYEE.code,
            applicantInfo: {
              demographics: {
                ...applicant,
              },
            },
          })
        }
        const dependents = responseValue?.employee?.dependents
        if (dependents?.length) {
          dependents.forEach((dependent) => {
            const applicant = {
              idType: loginValue,
              firstName: dependent?.dependentFirstName,
              lastName: dependent?.dependentLastName,
              genderCode: dependent?.dependentGenderCode,
              dateOfBirth: dependent?.dependentDateOfBirth,
              heightFeet: dependent?.dependentHeightFeet,
              heightInches: dependent?.dependentHeightInches,
              weight: dependent?.dependentWeight,
              sequenceNumber: dependent?.sequenceNumber,
            }

            applicants.push({
              id: uuid(),
              type: enroller[dependent.relationshipCode].type,
              applicantStatusCode: dependent.applicantStatusCode,
              coverages: dependent.coverages,
              applicantType: enroller[dependent.relationshipCode].code,
              applicantInfo: {
                demographics: {
                  ...applicant,
                },
              },
            })
          })
        }
      } else if (responseValue?.caseStatusCode === 'NEW') {
        employeeInfo.idType = loginValue
      }
      applicants.sort((a, b) => TYPE_SORT.indexOf(a.applicantType) - TYPE_SORT.indexOf(b.applicantType))
      updateCaseFormData({ applicants: applicants, employeeInfo: employeeInfo })
      onClick(responseValue?.caseStatusCode)
    } catch (error) {
      console.log(error)
      setToastError(DEFAULT)
    }
    setIsProcessing(false)
  }

  const handleButtonOnClick = () => {
    trigger('loginValue').then((isFieldValid) => {
      if (isFieldValid) {
        fetchApplicantCase()
        return true
      } else {
        console.log("form isn't valid")
      }
      return isFieldValid
    })
  }

  const closeModal = () => {
    resetField('loginValue')
    deleteLoginMethodValue()
    setShowModal(false)
  }

  return (
    <>
      <Modal
        id="show-login-modal"
        show={showModal}
        heading={
          <div
            className="text-3xl"
            style={{ fontSize: '28px' }}>{`Great! Next please enter your ${loginMethodObj?.abr}`}</div>
        }
        onHide={closeModal}>
        <ModalBody>
          <div data-cy="login_modal">
            <div className="mb-6">
              <span>We need your {loginMethodObj?.abr} to create your application</span>
            </div>
            <div className="w-96">
              <Controller
                render={({ field, fieldState }) => {
                  const { ref, ...fields } = field
                  return (
                    <InputMask
                      {...fields}
                      mask={loginMethodObj?.mask}
                      maskChar={loginMethodObj?.maskChar}
                      value={fields.value}
                      onChange={fields.onChange}
                      formatChars={loginMethodObj?.formatChars}
                      alwaysShowMask={false}>
                      {(inputProps) => (
                        <TextField
                          {...inputProps}
                          id={field.name}
                          label={loginMethodObj?.label}
                          error={fieldState.invalid}
                          helperText={fieldState.error?.message}
                          isPassword={loginMethodObj?.isPassword}
                          autoComplete={loginMethodObj?.autoComplete}
                        />
                      )}
                    </InputMask>
                  )
                }}
                control={control}
                name="loginValue"
                rules={{
                  required: {
                    value: true,
                    message: `Please enter your ${loginMethodObj?.label}`,
                  },
                  pattern: loginMethodObj?.pattern,
                  validate: loginMethodObj?.validate,
                }}
              />
            </div>
          </div>
          {toastError ? (
            <Toasts
              items={[
                {
                  id: 'toast_error_message_id',
                  children: toastError,
                  variant: 'danger',
                },
              ]}
              onClick={() => setToastError(null)}
            />
          ) : null}
        </ModalBody>
        <ModalFooter>
          <div className="md:flex flex-nowrap w-full">
            <div className="flex-none basis-3/5">
              {isProcessing && (
                <Button disabled>
                  <i className="fa-solid fa-spinner fa-spin" />
                  &nbsp;&nbsp;Processing...
                </Button>
              )}
              {!isProcessing && (
                <Button id="action-button" variant="primary" onClick={handleButtonOnClick}>
                  Next: Confirmation
                </Button>
              )}
            </div>
            <div className="grid flex-1 basis-2/5">
              <span className="text-right self-end text-xs font-bold not-italic"></span>
            </div>
          </div>
        </ModalFooter>
      </Modal>
    </>
  )
}

export default LoginModal
