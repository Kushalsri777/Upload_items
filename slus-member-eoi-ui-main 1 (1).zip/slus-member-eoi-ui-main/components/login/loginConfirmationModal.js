import { useEffect, useState } from 'react'
import { Button, Checkbox, HelperText, Modal, ModalBody, ModalFooter } from '@/components/helios-components'
import moment from 'moment'
import { LOGIN } from '@/common/utils/pageText'
import { EXTERNAL } from '@/common/enums/imageIcons'
import NewTabLink from '../newTabLink'
import { navigateToPaperForm } from '@/common/utils/util'

const {
  confirmation: {
    policyholder: { body },
    checkboxText,
    checkboxErrorText,
    info: { message, link },
  },
} = LOGIN

function LoginConfirmationModal({ policy, employee, showModal, setShowModal, onClickSecondary, onClickPrimary }) {
  const [name, setName] = useState()
  const [dob, setDob] = useState()
  const [isChecked, setIsChecked] = useState(false)
  const [isValidating, setIsValidating] = useState(false)

  useEffect(() => {
    if (!employee) {
      setName(null)
      setDob(null)
      return
    }

    if (employee?.firstName && employee?.lastName) {
      const newName = `${employee?.firstName} ${employee?.lastName}`
      setName(newName)
    }

    if (employee?.dateOfBirth) {
      const newDob = moment(employee?.dateOfBirth).format('MM/YYYY')
      setDob(newDob)
    }
  }, [employee])

  const handleOnChangeCheckbox = () => {
    setIsChecked(!isChecked)
  }

  const handleOnClickPrimary = () => {
    setIsValidating(true)
    if (isChecked) {
      onClickPrimary()
    }
  }

  const isInvalid = () => isValidating && !isChecked

  return (
    <>
      <Modal
        id="show-login-confirmation-modal"
        show={showModal}
        heading={<div style={{ fontSize: '28px', marginBottom: '5px' }}>Please confirm your details</div>}
        onHide={() => setShowModal(false)}>
        <ModalBody>
          <div data-cy="login_confirmation_modal">
            {name || dob ? (
              <div className="mb-7">
                <div className="mb-0.5">Employee found</div>
                <div className="mb-0.5">
                  <span className="font-sunlifeBold">Name:&nbsp;</span>
                  <span>{name}</span>
                </div>
                <div>
                  <span className="font-sunlifeBold">DOB:&nbsp;</span>
                  <span>{dob}</span>
                </div>
              </div>
            ) : null}
            <div className="mb-2">
              <span className="font-sunlifeBold">Policyholder: </span>
              <span>{policy?.sponsorName}</span>
            </div>
            <div className="mb-[36px]">
              <span>{body}</span>
            </div>
            <div className="flex">
              <span>
                <Checkbox
                  id="cb-elec-cons-i-accept"
                  label={checkboxText}
                  checked={isChecked}
                  onChange={handleOnChangeCheckbox}
                  isInvalid={isInvalid()}
                />
                {isInvalid() ? (
                  <div className="-mt-4 mb-2">
                    <HelperText id="checkbox-error-text" error>
                      {checkboxErrorText}
                    </HelperText>
                  </div>
                ) : null}
              </span>
              <span className="pt-2">
                <NewTabLink image={<EXTERNAL />} href="/electronic-consent" />
              </span>
            </div>
            <div className="flex whitespace-nowrap" style={{ fontSize: '14px' }}>
              <span className="font-sunlifeBold">{message}</span>&nbsp;
              <NewTabLink label={link} onClick={navigateToPaperForm} />.
            </div>
          </div>
        </ModalBody>
        <ModalFooter>
          <div className="md:flex flex-nowrap w-full">
            <div className="flex-none basis-1/5">
              <Button id="action-button-back" variant="secondary" onClick={onClickSecondary}>
                Back
              </Button>
            </div>
            <div className="flex-none basis-2/5">
              <Button id="action-button-confirm" variant="primary" onClick={handleOnClickPrimary}>
                Confirm
              </Button>
            </div>
            <div className="grid flex-1 basis-2/5">
              <span className="text-right self-end text-xs font-bold not-italic"></span>
            </div>
          </div>
        </ModalFooter>
      </Modal>
    </>
  )
}

export default LoginConfirmationModal
