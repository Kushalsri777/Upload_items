import styles from './loginFAQ.module.css'

import Container from 'react-bootstrap/Container'
import { Accordion } from '@/components/helios-components'
import DownloadPaperForm from '@/components/dashboard/downloadPaperForm'

export default function LoginFAQ() {
  return (
    <Container>
      <div className={styles.faq}>
        <Accordion
          groupHeading="FAQ"
          items={[
            {
              id: '0',
              heading: 'What is Evidence of Insurability (EOI)?',
              body: 'EOI is a statement or proof of an employee’s or dependent’s medical history. We use it to determine whether or not to provide the benefit you are requesting.',
            },
            {
              id: '1',
              heading: 'Why am I required to submit EOI?',
              body: (
                <>
                  <p>
                    The reason you may need to submit EOI depends on your group policy. Usually, EOI is required if:
                  </p>
                  <ul>
                    <li>you apply for additional coverage that is more than the Guaranteed Issue amount,</li>
                    <li>you previously enrolled for the benefit and now want to increase the amount,</li>
                    <li>you declined the benefit during your initial eligibility period and now want to enroll, or</li>
                    <li>you elect to increase your coverage, and doing so is allowed by your group policy.</li>
                  </ul>
                </>
              ),
            },
            {
              id: '2',
              heading: 'What is a Guaranteed Issue amount?',
              body: 'A Guaranteed Issue amount is the quantity of coverage you can receive under your group policy without having to provide EOI.',
            },
            {
              id: '3',
              heading: 'What are my Guaranteed Issue amounts and deadlines to apply for more coverage?',
              body: 'The Guaranteed Issue amounts and deadlines vary according to your group policy and the type of coverage. Please ask your employer for more information.',
            },
            {
              id: '4',
              heading: 'What if I apply for coverage after the deadline?',
              body: 'If you apply for coverage after the deadline, you will be considered a “late entrant,” and the entire amount you are applying for will be subject to EOI. Typically, the deadline to apply for coverage is 31 days from your date of eligibility. However, to confirm your actual deadlines, please ask your employer.',
            },
            {
              id: '5',
              heading:
                'What if I don’t want to submit EOI online or if the coverage I’m applying for does not yet have an online EOI application?',
              body: (
                <>
                  <p>To download an EOI paper application, visit www.sunlife.com/findaform.</p>
                  <p>
                    You can also call us at 800-247-6875, Monday through Friday, 8:00 a.m. to 8:00 p.m. ET. Fill it out
                    and send it back to us by following the instructions on the application.
                  </p>
                </>
              ),
            },
            {
              id: '6',
              heading: 'What happens after I submit an application online?',
              body: (
                <>
                  <p>
                    Your employer will confirm that you are eligible to apply for your selected coverage. Your employer
                    will not have access to your EOI answers. As soon as your employer verifies your eligibility to
                    apply, we will review your application and contact you by email with a decision.
                  </p>
                  <p>We’ll tell you that your application was either:</p>
                  <ul>
                    <li>
                      Approved Your coverage will go into effect on the later of the approved date or benefit effective
                      date, or
                    </li>
                    <li>
                      {' '}
                      Pended We need more information from you before we make a decision. We will be in touch with you
                      via mail for more information.{' '}
                    </li>
                  </ul>
                </>
              ),
            },
          ]}
        />
      </div>
      <DownloadPaperForm disabled={false} />
    </Container>
  )
}
