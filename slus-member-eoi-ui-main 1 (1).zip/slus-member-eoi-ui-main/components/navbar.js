import { useContext } from 'react'
import Image from 'next/image'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import clsx from 'clsx'
import NavBarHelios from './navbarHelios'
import SubHeader from './subheader'
import styles from './navbar.module.css'
import { AppContext } from '@/components/context/app.context'
import enroller from '@/common/enums/enroller'

const BASE_PATH = process.env.NEXT_PUBLIC_BASE_PATH || ''

const pathEnum = {
  null: {
    step: '0',
    useSubHeader: true,
  },
  '/': {
    step: '',
    useHeliosNav: true,
  },
  '/login': {
    step: '',
    useHeliosNav: true,
  },
  '/dashboard': {
    step: '',
    useHeliosNav: true,
  },
  '/submitted': {
    step: '',
    useHeliosNav: true,
  },
  '/demographics': {
    step: '1',
    useSubHeader: true,
  },
  '/history': {
    step: '2',
    useSubHeader: true,
  },
  '/review': {
    step: '3',
    useSubHeader: true,
  },
  '/fraud': {
    step: '4',
    useSubHeader: true,
  },
  '/authorize': {
    step: '5',
    useSubHeader: true,
  },
  '/signature': {
    step: '6',
    useSubHeader: true,
  },
  '/electronic-consent': {
    useHeliosNav: true,
  },
  '/500': {
    step: '',
    useHeliosNav: true,
  },
  default: {
    step: '',
    useHeliosNav: true,
  },
  '/redirect': {
    step: '',
    useSubHeader: false,
  },
}

const stepsForApplicants = {
  employee: {
    totalCount: '3',
  },
  spouseOrChild: {
    totalCount: '4',
  },
}

function NavBar({ disableNavManu }) {
  const { policyInfo: policy, selectedApplicant, currentEnroller, previousEnroller } = useContext(AppContext)
  const pathname = usePathname()

  const getPathObj = () => {
    return pathEnum[pathname] || pathEnum['default']
  }

  const stepIndex = () => {
    if (
      selectedApplicant.relationshipType === enroller.CHILD.code ||
      selectedApplicant.relationshipType === enroller.SPOUSE.code
    ) {
      if (
        (pathname === '/demographics' &&
          (currentEnroller === enroller.EMPLOYEE_NO_APPLICANT.code ||
            previousEnroller === enroller.EMPLOYEE_NO_APPLICANT.code)) ||
        pathname !== '/demographics'
      ) {
        return `${Number(getPathObj().step) + 1}`
      }
    }
    return getPathObj().step
  }

  const stepCount = () => {
    if (
      selectedApplicant.relationshipType === enroller.CHILD.code ||
      selectedApplicant.relationshipType === enroller.SPOUSE.code
    ) {
      return stepsForApplicants.spouseOrChild.totalCount
    }
    return stepsForApplicants.employee.totalCount
  }

  return (
    <>
      {getPathObj().useHeliosNav ? (
        <NavBarHelios disableNavManu={disableNavManu} />
      ) : (
        <header className={styles.navheader}>
          <div className={clsx('container', styles.navbar)}>
            <Link href="/">
              <Image
                className="h-auto"
                alt="Sun Life"
                src={`${BASE_PATH}/images/SunLifeLogo.svg`}
                width={128}
                height="0"
              />
            </Link>
          </div>
          <hr className={styles.divider} area-hidden="true" />
          {getPathObj().useSubHeader ? (
            <SubHeader
              applicant={selectedApplicant?.applicantFullName}
              relationship={enroller[selectedApplicant?.relationshipType]?.label}
              policyholder={policy?.sponsorName}
              stepIndex={stepIndex()}
              stepCount={stepCount()}
            />
          ) : null}
        </header>
      )}
    </>
  )
}

export default NavBar
