import { MED_GRP, TST_GRP } from '@/common/enums/constant'
import DisplayRadio from '@/components/common/displayRadio'
import { useApplicants } from '@/components/context/Applicants.context'
import MedicationQuestions from '@/components/healthHistoryQuestions/medicationQuestions'
import Question from '@/components/healthHistoryQuestions/Question'
import TestQuestions from '@/components/healthHistoryQuestions/testQuestions'
import { getApplicantQuestionsByUsageCode, parseForVariables } from '@/components/healthHistoryQuestions/steps/util'
import {
  Button,
  Checkbox,
  DatePicker,
  Dropdown,
  HelperText,
  InputGroup,
  Radio,
  TextField,
} from '@/components/helios-components'
import unitedStates from '@/components/unitedStates'
import { isEmpty } from 'lodash'
import React, { useEffect, useState } from 'react'
import { Controller, useFormContext } from 'react-hook-form'
const DEFAULT_TEXT_AREA_MAX_LENGTH = 500
export function QuestionList({
  usageCode,
  applicant,
  onQuestionsChange,
  onQuestionsRemoved,
  className = 'mb-4',
  textAreaConfig = {},
}) {
  const [applicantQuestions, setApplicantQuestions] = useState([])
  const [testQuestions, setTestQuestions] = useState([])
  const [currentMedicationQuestions, setCurrentMedicationQuestions] = useState([])
  const [removedMedicationQuestions, setRemovedMedicationQuestions] = useState([])
  const applicants = useApplicants()
  const { control, setValue } = useFormContext()
  useEffect(() => {
    const allUsageCodeQuestions = getApplicantQuestionsByUsageCode(applicant, applicants, usageCode)
    const applicantQuestions = allUsageCodeQuestions.filter(
      (question) => question.reqtOptSubGroupCd !== MED_GRP && question.reqtOptSubGroupCd !== TST_GRP,
    )
    const medicationQuestions = allUsageCodeQuestions.filter((question) => question.reqtOptSubGroupCd === MED_GRP)
    const testQuestions = allUsageCodeQuestions.filter((question) => question.reqtOptSubGroupCd === TST_GRP)
    applicantQuestions.forEach((question) => {
      const types = ['TEXTAREA', 'TEXTFIELD', 'LISTBOX', 'CHECKBOX', 'RADIO']
      if (types.includes(question.displayType)) {
        setValue(question.requirementOptionCd, question.textValue)
      }
    })
    setApplicantQuestions(applicantQuestions)
    setCurrentMedicationQuestions(medicationQuestions)
    setTestQuestions(testQuestions)
  }, [applicants])
  useEffect(() => {
    if (onQuestionsChange) {
      const allQuestions = applicantQuestions.concat(currentMedicationQuestions).concat(testQuestions)
      onQuestionsChange(allQuestions)
    }
  }, [applicantQuestions, currentMedicationQuestions, testQuestions])
  useEffect(() => {
    if (onQuestionsRemoved) {
      onQuestionsRemoved(removedMedicationQuestions)
    }
  }, [removedMedicationQuestions])
  useEffect(() => {
    applicantQuestions.forEach((question) => {
      if (['TEXTAREA', 'TEXTFIELD'].includes(question.displayType) && isDisabled(question)) {
        setValue(question.requirementOptionCd, '')
      }
    })
  }, [applicantQuestions])

  const handleApplicantQuestionChange = (index, changedTextValue, changedIdValue, changedDateValue) => {
    setApplicantQuestions((previousQuestions) => {
      const questionToUpdate = previousQuestions.at(index)

      const updatedQuestion = (() => {
        if (questionToUpdate.textValue !== changedTextValue && !!changedTextValue) {
          return { ...questionToUpdate, textValue: changedTextValue, errorMessage: null }
        } else if (questionToUpdate.valueId !== changedIdValue && !!changedIdValue) {
          return { ...questionToUpdate, valueId: changedIdValue, errorMessage: null }
        } else if (questionToUpdate.dateValue !== changedDateValue && changedDateValue !== undefined) {
          return { ...questionToUpdate, dateValue: changedDateValue, errorMessage: null }
        } else {
          return questionToUpdate
        }
      })()

      const updatedQuestions = [...previousQuestions].toSpliced(index, 1, updatedQuestion)

      return updatedQuestions.map((question) => {
        if (isDisabled(question)) {
          return { ...question, textValue: null, valueId: null, dateValue: null }
        } else {
          return question
        }
      })
    })
  }

  const handleMedicationQuestionsChange = (changedMedicationQuestions) => {
    const previousMedicationQuestions = [...currentMedicationQuestions]

    const removedMedicationQuestions = previousMedicationQuestions.filter(
      (question) => question.reqtOptSubGroupCd === MED_GRP && !changedMedicationQuestions.includes(question),
    )

    setCurrentMedicationQuestions(changedMedicationQuestions)
    setRemovedMedicationQuestions(removedMedicationQuestions)
  }
  const handleTestQuestionsChange = (changedTestQuestions) => {
    setTestQuestions(changedTestQuestions)
  }
  const handleCheckboxChange = (e, index) => {
    const {
      target: { checked },
    } = e

    const changedTextBoxValue = checked ? 'YES' : 'NO'
    handleApplicantQuestionChange(index, changedTextBoxValue)
    return changedTextBoxValue
  }

  const isDisabled = (question) => {
    if (question.depAction === 'DISABLE') {
      const dep = applicantQuestions.find((q) => question.depRequirementOptionCd === q.requirementOptionCd)
      const valueIdStr = dep.valueId ? dep.valueId.toString() : null
      const depValue = dep.textValue || valueIdStr
      return depValue !== question.depRequirementValue
    }
    return false
  }

  const renderCheckbox = ({ question, description, label, index }) => {
    return (
      <div>
        <Controller
          control={control}
          render={({ field }) => {
            const { ref, onChange, ...fields } = field
            return (
              <Checkbox
                id={`checkbox-question-${index}`}
                label={label}
                name={question.optionName}
                checked={question.textValue === 'YES'}
                onChange={(event) => {
                  onChange(handleCheckboxChange(event, index))
                }}
                disabled={isDisabled(question)}
              />
            )
          }}
          defaultValue={question.textValue}
          name={question.requirementOptionCd}
        />
        {description.toLowerCase() !== label.toLowerCase() && (
          <HelperText className="ml-9 mt-1 mb-3" id={`checkbox-question-desc-${index}`}>
            {description}
          </HelperText>
        )}
      </div>
    )
  }

  const renderSlider = ({ question, applicant, description, label, index }) => {
    return (
      <div>
        <Controller
          control={control}
          render={({ field }) => {
            const { ref, ...fields } = field
            return (
              <Question
                {...fields}
                id={index}
                applicant={applicant}
                text={label}
                helpText={description}
                question={question}
                onQuestionChange={(event) => handleApplicantQuestionChange(index, event)}
              />
            )
          }}
          name={question.requirementOptionCd}
        />
        {question.errorMessage && (
          <HelperText id={`error-${index}`} error>
            {question.errorMessage}
          </HelperText>
        )}
      </div>
    )
  }

  const renderTextField = ({ question, label, description, index }) => {
    return (
      <div className="max-w-sm mt-2">
        <div className="my-2">{description}</div>
        <Controller
          control={control}
          render={({ field }) => {
            const { ref, ...fields } = field
            return (
              <TextField
                {...fields}
                id={index}
                label={label}
                value={field.value == null ? '' : field.value}
                maxLength={DEFAULT_TEXT_AREA_MAX_LENGTH}
                error={question.errorMessage}
                onBlur={(e) => handleApplicantQuestionChange(index, e.target.value)}
                disabled={isDisabled(question)}
              />
            )
          }}
          name={question.requirementOptionCd}
        />
        {question.errorMessage && (
          <HelperText id={`error-${index}`} error>
            {question.errorMessage}
          </HelperText>
        )}
      </div>
    )
  }

  const renderTextArea = ({ question, textAreaConfig, label, index }) => {
    const config = textAreaConfig[question.requirementOptionCd]

    return (
      <div className="mb-6">
        <Controller
          control={control}
          render={({ field }) => (
            <div className={config.className}>
              {config.showExternalLabel && (
                <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
              )}
              <div className="relative">
                <div className="relative">
                  <textarea
                    {...field}
                    id={`textarea-${index}`}
                    placeholder={config.placeholder}
                    value={field.value == null ? '' : field.value}
                    maxLength={config.maxLength}
                    rows={config.rows}
                    className="w-full px-3 pt-2 pb-10 border border-gray-300 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                    style={config.style}
                    onBlur={(e) => handleApplicantQuestionChange(index, e.target.value)}
                  />
                  <div className="absolute bottom-0 left-0 right-0 h-8">
                    <div className="absolute right-2 top-1/2 -translate-y-1/2 text-xs text-gray-500">
                      {field.value?.length || 0}/{config.maxLength}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
          name={question.requirementOptionCd}
        />
      </div>
    )
  }

  const renderListBox = ({ question, description, index }) => {
    return (
      <div className="max-w-sm mt-2">
        <div className="my-2">{description}</div>
        <Controller
          control={control}
          render={({ field }) => {
            const { ref, ...fields } = field
            return (
              <Dropdown
                {...fields}
                id={field.name}
                label={question.optionName}
                onChange={(event) => handleApplicantQuestionChange(index, event.option.value)}
                options={unitedStates}
                selected={field.value || ''}
                placeholder=""
              />
            )
          }}
          name={question.requirementOptionCd}
        />
        {question.errorMessage && (
          <HelperText id={`error-${index}`} error>
            {question.errorMessage}
          </HelperText>
        )}
      </div>
    )
  }

  const renderRadioDisplay = ({ question, applicant, index }) => {
    return (
      <DisplayRadio
        question={question}
        index={index}
        firstname={applicant.firstName}
        onRadioChange={(e, checked) => handleApplicantQuestionChange(index, checked ? 'YES' : 'NO')}
        disabled={isDisabled(question)}
      />
    )
  }

  const renderRadioGroup = ({ question, description, nameVariables, index }) => {
    return (
      <div className="mt-4">
        <InputGroup id={`input-group-${index}`} label={description || 'unknown'}>
          {question.values.map((o) => {
            const { valueId, valueDesc, valueSubDesc } = o
            const processedSubDesc = valueSubDesc ? parseForVariables(valueSubDesc, nameVariables) : null
            return (
              <React.Fragment key={valueId}>
                <Radio
                  id={`radio-${index}-option-${valueId}`}
                  label={valueDesc}
                  checked={question.valueId === valueId}
                  onChange={(e) => handleApplicantQuestionChange(index, null, valueId)}
                  disabled={isDisabled(question)}
                />
                {processedSubDesc && typeof processedSubDesc === 'string' && processedSubDesc.trim().length > 0 && (
                  <HelperText className="ml-9 mt-1 mb-3" id={`subdesc-${index}-${valueId}`}>
                    {processedSubDesc}
                  </HelperText>
                )}
              </React.Fragment>
            )
          })}
        </InputGroup>
      </div>
    )
  }

  const renderCalendar = ({ question, description, index }) => {
    return (
      <div className="max-w-sm mt-3">
        <div className="my-2">{description}</div>
        <DatePicker
          id={index}
          label="YYYY-MM-DD"
          value={{ input: question.dateValue || '' }}
          maskConfig={{ mask: 'YYYY-MM-DD' }}
          onChange={(event) => handleApplicantQuestionChange(index, null, null, event.input)}
          disabled={isDisabled(question)}
        />
      </div>
    )
  }
  const renderButton = ({ question, description, label, index }) => {
    if (question.dataType === 'FILE') {
      const handleFileButtonClick = () => {
        const fileInput = document.createElement('input')
        fileInput.type = 'file'
        fileInput.onchange = (e) => {
          if (e.target.files && e.target.files.length > 0) {
            const filename = e.target.files[0].name
            if (question.reqtOptSubGroupCd === TST_GRP) {
              handleTestQuestionChange(index, filename)
            } else {
              handleApplicantQuestionChange(index, filename)
            }
          }
        }
        fileInput.click()
      }
      return (
        <div className="mt-3 mb-6">
          {description && <div className="my-2">{description}</div>}
          <Button
            id={`button-${index}`}
            onClick={handleFileButtonClick}
            variant="secondary"
            disabled={isDisabled(question)}>
            {label}
          </Button>
          {question.textValue && <div className="mt-2 text-sm text-gray-600">File selected: {question.textValue}</div>}
        </div>
      )
    } else {
      const handleDefaultButtonClick = () => {}
      return (
        <div className="mt-3 mb-6">
          {description && <div className="my-2">{description}</div>}
          <Button
            id={`button-${index}`}
            onClick={handleDefaultButtonClick}
            variant="primary"
            disabled={isDisabled(question)}>
            {label}
          </Button>
        </div>
      )
    }
  }
  const renderDisplayType = (question, index) => {
    const nameVariables = { name: applicant.firstName, firstname: applicant.firstName }
    const label = question.optionName ? parseForVariables(question.optionName, nameVariables) : null
    const description = question?.optionDescription
      ? parseForVariables(question.optionDescription, nameVariables)
      : null

    switch (question.displayType) {
      case 'CHECKBOX':
        return renderCheckbox({ question, description, label, index })
      case 'SLIDER':
        return renderSlider({ question, applicant, description, label, index })
      case 'MULTI-RADIO':
        return renderRadioGroup({ question, description, nameVariables, index })
      case 'RADIO':
        return renderRadioDisplay({ question, applicant, index })
      case 'LABEL':
        return <span className="my-4 block">{label}</span>
      case 'TEXTAREA':
        return renderTextArea({ question, textAreaConfig, label, index })
      case 'TEXTFIELD':
        return renderTextField({ question, label, description, index })
      case 'LISTBOX':
        return renderListBox({ question, description, index })
      case 'CALENDAR':
        return renderCalendar({ question, description, index })
      case 'BUTTON':
        return renderButton({ question, description, label, index })
      default:
        return null
    }
  }

  return (
    <>
      {applicantQuestions &&
        applicantQuestions.map((question, index) => (
          <div key={index} className={className}>
            {renderDisplayType(question, index)}
          </div>
        ))}
      {!isEmpty(testQuestions) && (
        <TestQuestions
          questions={testQuestions}
          applicant={applicant}
          className={className}
          applicantQuestionsLength={applicantQuestions.length}
          onQuestionsChange={handleTestQuestionsChange}
        />
      )}
      {!isEmpty(currentMedicationQuestions) && (
        <div>
          <MedicationQuestions
            questions={currentMedicationQuestions}
            applicant={applicant}
            onQuestionsChange={handleMedicationQuestionsChange}
          />
        </div>
      )}
    </>
  )
}
