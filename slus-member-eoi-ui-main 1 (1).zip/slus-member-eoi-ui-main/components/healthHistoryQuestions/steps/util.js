import parse from 'html-react-parser'
import { EMPLOYEE, SPOUSE, CHILD } from '@/common/enums/enroller'

const Bold = ({ children }) => <span className="font-sunlifeBold">{children}</span>
const BoldUnderline = ({ children }) => (
  <Bold>
    <u>{children}</u>
  </Bold>
)
const Small = ({ children }) => <div style={{ fontSize: '0.875rem', lineHeight: '1.25rem' }}>{children}</div>

const buildBooleanAbreviation = (booleanAnswer, preText, postText) => {
  return (
    <span>
      {preText}&nbsp;
      {booleanAnswer ? (
        ''
      ) : (
        <>
          <BoldUnderline>not</BoldUnderline>&nbsp;
        </>
      )}
      {postText}
    </span>
  )
}

const replaceVariables = (str, variables) => {
  if (typeof str === 'string') {
    return str.replace(/\$?{(\w+)}/g, (_, key) => variables[key] || `{${key}}`)
  }
  return str
}

const options = {
  replace: ({ name, attribs, children }) => {
    if (name === 'bold') {
      return <Bold {...attribs}>{children[0].data}</Bold>
    }
  },
}

const parseForVariables = (text, variables) => {
  const processedText = replaceVariables(text, variables)
  return parse(processedText, options)
}

const getApplicantQuestions = (applicant, applicants) => {
  return applicant.type.code === 'EMPLOYEE'
    ? applicants.employee.questions
    : applicant.type.code === 'SPOUSE'
      ? applicants.spouse.questions
      : applicants.children.find((e) => e.seqNum === applicant.seqNum).questions
}

const getApplicantQuestionsBySubgroupCode = (applicant, applicants, subgroupCode) => {
  const applicantQuestions = getApplicantQuestions(applicant, applicants)
  const subgroupCodeFilter = ({ reqtOptSubGroupCd: setCode }) => setCode === subgroupCode
  return applicantQuestions.filter(subgroupCodeFilter)
}

const getApplicantQuestionsByUsageCode = (applicant, applicants, usageCode) => {
  const {
    employee: { questions: eeQs },
    spouse: { questions: spQs },
    children,
  } = applicants

  const {
    type: { code },
    seqNum,
  } = applicant
  const usageCodeFilter = ({ requirementOptionUsageCd: rouc }) => rouc === usageCode

  switch (code) {
    case EMPLOYEE.code: {
      // const x = questions.filter((q) => )
      return eeQs.filter(usageCodeFilter)
    }
    case SPOUSE.code: {
      return spQs.filter(usageCodeFilter)
    }
    case CHILD.code: {
      const child = children.find(({ seqNum: n }) => n === seqNum)
      const { questions: chQs } = child
      return chQs.filter(usageCodeFilter)
    }
    default:
      throw new Error(`Unknown applicant type code: ${code}`)
  }
}

export {
  Bold,
  BoldUnderline,
  Small,
  buildBooleanAbreviation,
  parseForVariables,
  getApplicantQuestions,
  getApplicantQuestionsBySubgroupCode,
  getApplicantQuestionsByUsageCode,
}
