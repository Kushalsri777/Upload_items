import { useContext, useEffect, useState } from 'react'
import { StepHandlerContext } from '@/components/context/StepHandler.context'
import { Bold, getApplicantQuestions, parseForVariables } from './util'
import { parsePhoneNumber } from 'libphonenumber-js'
import { completeApplicant } from '@/common/utils/api'
import { Notification } from '@/components/helios-components'
import { useApplicants, useApplicantsDispatcher } from '@/components/context/Applicants.context'
import {
  DATA_STEP_ID_ADDICTION,
  DATA_STEP_ID_CANCER,
  DATA_STEP_ID_MEDICATIONS,
  DATA_STEP_ID_NEUROLOGICAL,
} from '@/common/enums/healthHistorySteps'
import {
  PHYSICIAN_CITY,
  PHYSICIAN_FIRST_NAME,
  PHYSICIAN_FIRST_NAME_ERROR,
  PHYSICIAN_LAST_NAME,
  PHYSICIAN_LAST_NAME_ERROR,
  PHYSICIAN_PHONE_NUMBER,
  PHYSICIAN_STATE,
  PHYSICIAN_STREET,
  PHYSICIAN_ZIP_CODE,
  REQUIRED_FIELDS,
} from '@/common/enums/constant'
import { COMPLETE } from '@/common/enums/applicationStatusCode'

const StepReview = ({ name, applicant }) => {
  const { setStepHandler } = useContext(StepHandlerContext)
  const [questions, setQuestions] = useState([])
  const [showNotification, setShowNotification] = useState(false)
  const [notificationMessage, setNotificationMessage] = useState('')
  const applicants = useApplicants()
  const { updateQuestions, updateEmployee, updateSpouse, updateChildren } = useApplicantsDispatcher()

  useEffect(() => {
    setQuestions(
      getApplicantQuestions(applicant, applicants).filter((question) => {
        return (
          question.applicantType === applicant.type.code &&
          question.seqNum === applicant.seqNum &&
          (question.requirementOptionUsageCd === DATA_STEP_ID_CANCER ||
            question.requirementOptionUsageCd === DATA_STEP_ID_ADDICTION ||
            question.requirementOptionUsageCd === DATA_STEP_ID_NEUROLOGICAL ||
            question.requirementOptionUsageCd === DATA_STEP_ID_MEDICATIONS)
        )
      }),
    )
  }, [])

  useEffect(() => {
    setStepHandler({
      onClickNext: async (onStepClick) => {
        if (onStepClick) {
          return true
        }
        if (!validateQuestions()) {
          return false
        }
        const response = await completeApplicant({
          applicantType: applicant.type.code,
          seqNum: applicant.seqNum,
        })
        if (!response.ok) {
          setNotificationMessage('Error completing application. Please try again.')
          return false
        }
        if (applicant.type.code === 'EMPLOYEE') {
          updateEmployee({ status: COMPLETE })
        }
        if (applicant.type.code === 'SPOUSE') {
          updateSpouse({ status: COMPLETE })
        }
        if (applicant.type.code === 'CHILD') {
          const newChildren = applicants.children.map((child) => {
            if (child.seqNum === applicant.seqNum) {
              return { ...child, status: COMPLETE }
            }
            return child
          })
          updateChildren(newChildren)
        }
        return true
      },
    })
  }, [questions])

  const validateQuestions = () => {
    let isValid = true
    let validatedQuestions = questions?.map((question) => {
      if (question.displayType === 'SLIDER' && !question.textValue) {
        question.errorMessage = REQUIRED_FIELDS
        isValid = false
      } else if (
        question.requirementOptionUsageCd === DATA_STEP_ID_MEDICATIONS &&
        question.requirementOptionCd === PHYSICIAN_FIRST_NAME &&
        !question.textValue
      ) {
        question.errorMessage = parseForVariables(PHYSICIAN_FIRST_NAME_ERROR, { name: name })
        isValid = false
      } else if (
        question.requirementOptionUsageCd === DATA_STEP_ID_MEDICATIONS &&
        question.requirementOptionCd === PHYSICIAN_LAST_NAME &&
        !question.textValue
      ) {
        question.errorMessage = parseForVariables(PHYSICIAN_LAST_NAME_ERROR, { name: name })
        isValid = false
      } else {
        question.errorMessage = null
      }
      return question
    })
    setQuestions(validatedQuestions)
    updateQuestions(validatedQuestions)
    return isValid
  }

  const getExperienceAnswers = () => {
    return questions
      ?.filter((question) => {
        return question.requirementOptionUsageCd !== 'MedicMissedWork' && question.textValue === 'YES'
      })
      .map((question) => question.optionName)
  }

  const getMedicationAnswers = () => {
    return questions
      ?.filter((question) => {
        return (
          question.requirementOptionUsageCd === 'MedicMissedWork' &&
          question.displayType === 'SLIDER' &&
          question.textValue
        )
      })
      .map((question) => {
        if (question.textValue === 'YES') {
          return question.optionName.replace('{name}', '').replace('?', '')
        }
        const newValue = question.optionName.replace('{name}', '<Bold>not</Bold>').replace('?', '')
        return parseForVariables(newValue)
      })
  }

  const findMedicationAnswer = (optionCd, questions) => {
    return Array.isArray(questions)
      ? questions?.find((question) => {
          return (
            question.requirementOptionUsageCd === DATA_STEP_ID_MEDICATIONS && question.requirementOptionCd === optionCd
          )
        })?.textValue
      : null
  }

  const formatPhoneNumber = (phoneNumber) => {
    if (!phoneNumber) {
      return ''
    }
    try {
      const parsedPhoneNumber = parsePhoneNumber(phoneNumber, 'US')
      return parsedPhoneNumber.formatNational()
    } catch (e) {
      return phoneNumber
    }
  }

  const getPrimaryPhysicianAnswer = () => {
    const medicQuestions = questions?.filter((question) => {
      return question.requirementOptionUsageCd === DATA_STEP_ID_MEDICATIONS && question.textValue
    })
    return (
      <div>
        <div>
          <span>{findMedicationAnswer(PHYSICIAN_FIRST_NAME, medicQuestions)}</span>&nbsp;
          <span>{findMedicationAnswer(PHYSICIAN_LAST_NAME, medicQuestions)}</span>
        </div>
        <div>
          <span>{findMedicationAnswer(PHYSICIAN_STREET, medicQuestions)}</span>&nbsp;
          <span>{findMedicationAnswer(PHYSICIAN_CITY, medicQuestions)}</span>&nbsp;
          <span>{findMedicationAnswer(PHYSICIAN_STATE, medicQuestions)}</span>&nbsp;
          <span>{findMedicationAnswer(PHYSICIAN_ZIP_CODE, medicQuestions)}</span>
        </div>
        <div>
          <span>{formatPhoneNumber(findMedicationAnswer(PHYSICIAN_PHONE_NUMBER, medicQuestions))}</span>
        </div>
      </div>
    )
  }

  return (
    <>
      <div className="mb-4">
        {showNotification && (
          <Notification actions={{}} closeLabel="Close" onClose={() => setShowNotification(false)} variant="danger">
            <>{notificationMessage}</>
          </Notification>
        )}
      </div>
      <div className="mb-4">Please review the answer you gave us and make sure they&apos;re correct.</div>
      <div className="mb-2">
        <Bold>You told us that {name} has experienced:</Bold>
      </div>
      <div className="mb-4">
        <ol className="list-decimal">
          {getExperienceAnswers().map((question, i) => (
            <li key={`experience-answer-${i}`}>{question}</li>
          ))}
        </ol>
      </div>
      <div className="mb-4">We will ask you follow up questions for these conditions next.</div>
      <div className="mb-2">
        <Bold>You also told us that {name}:</Bold>
      </div>
      <div className="mb-4">
        <ol className="list-decimal">
          {getMedicationAnswers().map((question, i) => (
            <li key={`medication-answer-${i}`}>{question}</li>
          ))}
        </ol>
      </div>
      <div className="mb-2">
        <Bold>The primary physician taking care of {name} is:</Bold>
      </div>
      <div className="mb-4">{getPrimaryPhysicianAnswer()}</div>
    </>
  )
}

export default StepReview
