import { useContext, useEffect, useState } from 'react'
import { StepHandlerContext } from '@/components/context/StepHandler.context'
import { Bold } from './util'
import { saveAnswersForTextValue } from '@/common/utils/api'
import { QuestionList } from '@/components/healthHistoryQuestions/questionList'
import { DATA_STEP_ID_CANCER } from '@/common/enums/healthHistorySteps'
import { useApplicantsDispatcher } from '@/components/context/Applicants.context'

const StepCancer = ({ name, applicant }) => {
  const { setStepHandler } = useContext(StepHandlerContext)
  const [questions, setQuestions] = useState([])
  const { updateQuestions } = useApplicantsDispatcher()

  useEffect(() => {
    setStepHandler({
      onClickNext: async () => {
        const isOk = await saveAnswersForTextValue(applicant, questions)
        if (isOk) {
          updateQuestions(questions)
          return true
        }
        return false
      },
    })
  }, [questions])

  const handleQuestionsChange = (updatedQuestions) => {
    setQuestions(updatedQuestions)
  }

  return (
    <>
      <div className="mb-4">
        In order to understand how healthy {name} is, we need you to answer some health-related questions. Only answer
        for {name}; we&apos;ll ask you about other family members later.
      </div>
      <div className="mb-4">
        <Bold>Please note</Bold>: You must answer all questions to complete the questionnarire, but you don&apos;t have
        to answer them all at once. If you&apos;re unsure how to answer now, you can save and come back later.
      </div>
      <div className="mb-4">
        For questions or help completting this form, you can call Customer Service at 800-247-6875 on Monday through
        Friday from 8:00 a.m. - 8:00 p.m., ET
      </div>
      <div className="mb-4">
        Has {name} experienced any of these conditions in the past 10 years? Choose <Bold>Yes</Bold> or <Bold>No</Bold>{' '}
        for each question.
      </div>
      <QuestionList usageCode={DATA_STEP_ID_CANCER} applicant={applicant} onQuestionsChange={handleQuestionsChange} />
    </>
  )
}

export default StepCancer
