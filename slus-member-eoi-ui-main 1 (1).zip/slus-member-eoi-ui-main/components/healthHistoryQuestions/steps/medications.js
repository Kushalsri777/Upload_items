import { useContext, useEffect, useState } from 'react'
import { StepHandlerContext } from '@/components/context/StepHandler.context'
import { Bold } from './util'
import { saveAnswersForTextValue } from '@/common/utils/api'
import { QuestionList } from '@/components/healthHistoryQuestions/questionList'
import { DATA_STEP_ID_MEDICATIONS } from '@/common/enums/healthHistorySteps'
import { useApplicantsDispatcher } from '@/components/context/Applicants.context'

const StepMedications = ({ name, applicant }) => {
  const { setStepHandler } = useContext(StepHandlerContext)
  const [questions, setQuestions] = useState([])
  const { updateQuestions } = useApplicantsDispatcher()

  useEffect(() => {
    setStepHandler({
      onClickNext: async () => {
        const isOk = await saveAnswersForTextValue(applicant, questions)
        if (isOk) {
          updateQuestions(questions)
          return true
        }
        return false
      },
    })
  }, [questions])

  const handleQuestionsChange = (updatedQuestions) => {
    setQuestions(updatedQuestions)
  }

  return (
    <>
      <div className="mb-4">
        Please answer all questions. If you&apos;re unsure how to answer now, you can save and come back later.
      </div>
      <div className="mb-4">
        Do any of these situations apply to {name}? Choose <Bold>Yes</Bold> or <Bold>No</Bold> for each question.
      </div>
      <QuestionList
        usageCode={DATA_STEP_ID_MEDICATIONS}
        applicant={applicant}
        onQuestionsChange={handleQuestionsChange}
      />
    </>
  )
}

export default StepMedications
