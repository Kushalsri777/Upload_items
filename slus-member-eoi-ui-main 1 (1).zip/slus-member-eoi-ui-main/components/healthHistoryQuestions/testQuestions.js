import { isEmpty } from 'lodash'
import React, { useState, useEffect } from 'react'
import { Controller, useForm, FormProvider } from 'react-hook-form'
import { TextField, DatePicker, Button } from '@/components/helios-components'
import { parseForVariables } from '@/components/healthHistoryQuestions/steps/util'

const renderTestTextField = ({ question, control, index, handleInternalQuestionChange }) => {
  const nameVariables = { name: question.applicant?.firstName || '', firstname: question.applicant?.firstName || '' }
  const label = question.optionName ? parseForVariables(question.optionName, nameVariables) : null
  const description = question?.optionDescription ? parseForVariables(question.optionDescription, nameVariables) : null
  return (
    <div className="max-w-sm mt-3 mb-6">
      <div className="my-2">{description}</div>
      <Controller
        control={control}
        name={question.requirementOptionCd}
        defaultValue={question.textValue || ''}
        render={({ field }) => (
          <TextField
            {...field}
            id={`test-q-${index}`}
            label={label}
            onBlur={(e) => handleInternalQuestionChange(index, e.target.value)}
          />
        )}
      />
    </div>
  )
}
const renderTestCalendar = ({ question, control, index, handleInternalQuestionChange }) => {
  const nameVariables = { name: question.applicant?.firstName || '', firstname: question.applicant?.firstName || '' }
  const description = question?.optionDescription ? parseForVariables(question.optionDescription, nameVariables) : null
  return (
    <div className="max-w-sm mt-3 mb-6">
      <div className="my-2">{description}</div>
      <Controller
        control={control}
        name={question.requirementOptionCd}
        defaultValue={{ input: question.dateValue || '' }}
        render={({ field }) => (
          <DatePicker
            {...field}
            id={`test-q-${index}`}
            label="YYYY-MM-DD"
            maskConfig={{ mask: 'YYYY-MM-DD' }}
            onChange={(event) => handleInternalQuestionChange(index, undefined, undefined, event.input)}
          />
        )}
      />
    </div>
  )
}
const renderTestButton = ({ question, index, handleInternalQuestionChange }) => {
  const nameVariables = { name: question.applicant?.firstName || '', firstname: question.applicant?.firstName || '' }
  const label = question.optionName ? parseForVariables(question.optionName, nameVariables) : null
  const description = question?.optionDescription ? parseForVariables(question.optionDescription, nameVariables) : null
  const handleFileButtonClick = () => {
    const fileInput = document.createElement('input')
    fileInput.type = 'file'
    fileInput.onchange = (e) => {
      if (e.target.files && e.target.files.length > 0) {
        const filename = e.target.files[0].name
        handleInternalQuestionChange(index, filename)
      }
    }
    fileInput.click()
  }
  return (
    <div className="mt-3 mb-6">
      {description && <div className="my-2">{description}</div>}
      <Button id={`test-button-${index}`} onClick={handleFileButtonClick} variant="secondary">
        {label}
      </Button>
      {question.textValue && <div className="mt-2 text-sm text-gray-600">File selected: {question.textValue}</div>}
    </div>
  )
}
export default function TestQuestions({
  questions: initialQuestions = [],
  applicant = {},
  className = 'mb-4',
  onQuestionsChange,
}) {
  const [internalQuestions, setInternalQuestions] = useState(initialQuestions)
  const methods = useForm()
  useEffect(() => {
    setInternalQuestions(initialQuestions)
    initialQuestions.forEach((q, index) => {
      const fieldName = q.requirementOptionCd
      if (q.displayType === 'CALENDAR') {
        methods.setValue(fieldName, { input: q.dateValue || '' })
      } else {
        methods.setValue(fieldName, q.textValue || '')
      }
    })
  }, [initialQuestions, methods])
  const handleInternalQuestionChange = (indexInTestArray, changedTextValue, changedIdValue, changedDateValue) => {
    const updatedQuestions = internalQuestions.map((question, i) => {
      if (i === indexInTestArray) {
        let updatedQuestion = { ...question, errorMessage: null }
        if (changedTextValue !== undefined) {
          updatedQuestion.textValue = changedTextValue
          methods.setValue(question.requirementOptionCd, changedTextValue)
        } else if (changedIdValue !== undefined) {
          updatedQuestion.valueId = changedIdValue
        } else if (changedDateValue !== undefined) {
          updatedQuestion.dateValue = changedDateValue
          methods.setValue(question.requirementOptionCd, { input: changedDateValue })
        }
        return updatedQuestion
      }
      return question
    })
    setInternalQuestions(updatedQuestions)
    if (onQuestionsChange) {
      onQuestionsChange(updatedQuestions)
    }
  }
  if (isEmpty(internalQuestions)) return null
  return (
    <FormProvider {...methods}>
      <div>
        <div className="mb-4 mt-4">
          <span style={{ fontSize: '1.5rem' }}>Other test information</span>
        </div>
        {internalQuestions.map((question, index) => (
          <div key={`test-${index}`} className={className}>
            {(() => {
              const commonProps = {
                question,
                control: methods.control,
                index,
                handleInternalQuestionChange,
                applicant,
              }
              switch (question.displayType) {
                case 'TEXTFIELD':
                  return renderTestTextField(commonProps)
                case 'CALENDAR':
                  return renderTestCalendar(commonProps)
                case 'BUTTON':
                  if (question.dataType === 'FILE') {
                    return renderTestButton(commonProps)
                  }
                  return null
                default:
                  return null
              }
            })()}
          </div>
        ))}
      </div>
    </FormProvider>
  )
}
