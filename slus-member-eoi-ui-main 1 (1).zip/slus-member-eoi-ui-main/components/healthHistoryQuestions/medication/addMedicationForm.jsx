import { REQUIRED_FIELDS } from '@/common/enums/constant'
import { parseForVariables } from '@/components/healthHistoryQuestions/steps/util'
import { Button, DatePicker, HelperText, Radio, TextField } from '@/components/helios-components'
import { isNil } from 'lodash'
import moment from 'moment/moment'
import { Controller, useFormContext } from 'react-hook-form'

export default function AddMedicationForm({ applicant, formQuestions, index, isDisabled, onCancel, onSave }) {
  const { control } = useFormContext()

  const validateField = (value, question) => {
    const isEmpty = question.displayType === 'CALENDAR' ? isNil(value) || !value.input : !value
    if (!isDisabled(question) && isEmpty) {
      return REQUIRED_FIELDS
    }
    if (!isEmpty && question.displayType === 'CALENDAR') {
      const date = moment(value.input, 'MM/DD/YYYY', true)
      if (!date.isValid()) {
        return 'Please enter a valid date'
      }
      if (date.isAfter(moment())) {
        return 'The date must be in the past'
      }
    }
    return true
  }

  return (
    <div className="border-2 pl-5 pb-4 mt-3" key={`medication-form-${index}`}>
      {formQuestions.map((question, questionIndex) => (
        <div key={questionIndex}>
          {(() => {
            const variables = {
              name: applicant.firstName,
              firstname: applicant.firstName,
            }
            const processedText = question.optionName ? parseForVariables(question.optionName, variables) : null
            const processedDesc = question.optionDescription
              ? parseForVariables(question.optionDescription, variables)
              : null
            switch (question.displayType) {
              case 'TEXTFIELD': {
                return (
                  <div className="max-w-sm mt-3">
                    {processedDesc}
                    <Controller
                      control={control}
                      render={({ field, fieldState }) => {
                        const { ref, ...fields } = field
                        return (
                          <TextField
                            {...fields}
                            id={questionIndex}
                            label={processedText}
                            maxLength={2500}
                            error={fieldState.invalid}
                            helperText={fieldState.error?.message}
                            value={field.value == null ? '' : field.value}
                          />
                        )
                      }}
                      name={question.requirementOptionCd}
                      rules={{
                        validate: (value) => validateField(value, question),
                      }}
                    />
                  </div>
                )
              }
              case 'CALENDAR': {
                return (
                  <div className="max-w-sm mt-3">
                    {processedDesc}
                    <Controller
                      control={control}
                      render={({ field, fieldState }) => {
                        const { ref, ...fields } = field
                        return (
                          <DatePicker
                            {...fields}
                            id={questionIndex}
                            label="MM/DD/YYYY"
                            error={fieldState.invalid}
                            helperText={fieldState.error?.message}
                            disabled={isDisabled(question)}
                          />
                        )
                      }}
                      name={question.requirementOptionCd}
                      rules={{
                        validate: (value) => validateField(value, question),
                      }}
                    />
                  </div>
                )
              }
              case 'RADIO': {
                return (
                  <div className="max-w-sm mt-3">
                    {processedDesc}
                    <Controller
                      control={control}
                      render={({ field, fieldState }) => {
                        const { ref, ...fields } = field
                        return (
                          <div>
                            <Radio
                              {...fields}
                              key="0"
                              id={`yes-${questionIndex}`}
                              inline
                              label="Yes"
                              value="YES"
                              isInvalid={fieldState.invalid}
                              checked={field.value === 'YES'}
                              name={question.requirementOptionCd}
                            />
                            <Radio
                              {...fields}
                              key="1"
                              id={`no-${questionIndex}`}
                              inline
                              label="No"
                              value="NO"
                              checked={field.value === 'NO'}
                              name={question.requirementOptionCd}
                            />
                            {fieldState.invalid && (
                              <div>
                                <HelperText id={`error-${questionIndex}`} error>
                                  {fieldState.error?.message}
                                </HelperText>
                              </div>
                            )}
                          </div>
                        )
                      }}
                      name={question.requirementOptionCd}
                      rules={{
                        validate: (value) => validateField(value, question),
                      }}
                    />
                  </div>
                )
              }
              default:
                return null
            }
          })()}
        </div>
      ))}
      <div className="flex mt-3 gap-x-2">
        <Button variant="tertiary" onClick={() => onCancel(index)}>
          Cancel
        </Button>
        <Button variant="secondary" onClick={() => onSave()}>
          Save
        </Button>
      </div>
    </div>
  )
}
