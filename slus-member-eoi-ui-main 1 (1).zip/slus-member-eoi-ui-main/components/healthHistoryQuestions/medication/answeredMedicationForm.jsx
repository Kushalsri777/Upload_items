import { Bold } from '@/components/healthHistoryQuestions/steps/util'
import { Button } from '@/components/helios-components'

export default function AnsweredMedicationForm({ formQuestions, index, isDisabled, onEdit, onDelete }) {
  const getMedicationField = (medication, field) => {
    const medField = medication.find((q) => q.requirementOptionCd === field)
    if (medField?.displayType === 'CALENDAR') {
      return medField.dateValue
        ? new Date(medField.dateValue).toLocaleDateString('en-US', { year: 'numeric', month: 'short' })
        : ''
    }
    return medField ? medField.textValue : ''
  }

  const indicator = getMedicationField(formQuestions, 'MedCurrInd')
  return (
    <div className="border-2 p-3 mt-3 flex justify-between items-center" key={`answered-medications-${index}`}>
      <div>
        <p>
          <Bold>{getMedicationField(formQuestions, 'MedName')}</Bold>
        </p>
        {indicator === 'YES' && <p>Used since {getMedicationField(formQuestions, 'MedStartDt')}</p>}
        {indicator === 'NO' && (
          <p>
            Used between {getMedicationField(formQuestions, 'MedStartDt')} and{' '}
            {getMedicationField(formQuestions, 'MedStopDt')}
          </p>
        )}
        <p>Treatment for {getMedicationField(formQuestions, 'MedCond')}</p>
      </div>
      <div className="flex gap-2">
        <Button variant={!isDisabled ? 'tertiary' : 'primary'} onClick={() => onEdit(index)} disabled={isDisabled}>
          Edit
        </Button>
        <Button variant={!isDisabled ? 'tertiary' : 'primary'} onClick={() => onDelete(index)} disabled={isDisabled}>
          Delete
        </Button>
      </div>
    </div>
  )
}
