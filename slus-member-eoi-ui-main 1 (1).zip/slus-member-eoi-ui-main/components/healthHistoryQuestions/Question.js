import { useState } from 'react'
import { Link } from '@/components/helios-components'
import YesNo from './YesNo'
import { Small } from '@/components/healthHistoryQuestions/steps/util'

const Question = ({ id, text, helpText, question, onQuestionChange }) => {
  const [showHelp, setShowHelp] = useState(false)
  const [status, setStatus] = useState(question?.textValue)

  const handleOnChange = (status) => {
    setStatus(status)
    onQuestionChange(status)
  }

  return (
    <div key={`health-history-question-${id}`}>
      {text} &nbsp;
      {helpText && (
        <Link
          icon={showHelp ? 'chevron-up' : 'chevron-down'}
          iconPosition="after"
          showIcon
          onClick={() => setShowHelp((current) => !current)}>
          Help me choose
        </Link>
      )}
      {showHelp && <Small>{helpText}</Small>}
      <div className="mt-2">
        <YesNo onChange={handleOnChange} status={status} />
      </div>
    </div>
  )
}

export default Question
