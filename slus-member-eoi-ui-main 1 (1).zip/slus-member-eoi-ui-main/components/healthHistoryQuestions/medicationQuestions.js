import { useEffect, useState } from 'react'
import { Bold, parseForVariables } from '@/components/healthHistoryQuestions/steps/util'
import { Button, DatePicker, HelperText, Radio, TextField } from '@/components/helios-components'
import { Controller, FormProvider, useForm } from 'react-hook-form'
import { MED_GRP, REQUIRED_FIELDS } from '@/common/enums/constant'
import { isNil } from 'lodash'
import moment from 'moment/moment'

export default function MedicationQuestions({ questions = [], applicant = {}, onQuestionsChange }) {
  const [medQuestions, setMedQuestions] = useState([])
  const [selectedItem, setSelectedItem] = useState(null)
  const methods = useForm({
    mode: 'onTouched',
  })

  let watchFields = []

  useEffect(() => {
    const allMedQuestions = questions.filter((q) => q.reqtOptSubGroupCd === MED_GRP)
    const groupedQuestions = Object.values(
      allMedQuestions.reduce((acc, question) => {
        if (!acc[question.provisionSeqNum]) {
          acc[question.provisionSeqNum] = []
        }
        acc[question.provisionSeqNum].push(question)
        return acc
      }, {}),
    )
    if (groupedQuestions.length === 1 && groupedQuestions[0][0].provisionSeqNum === null) {
      setSelectedItem(0)
    }
    setMedQuestions(groupedQuestions)
    let watches = []
    groupedQuestions[0].forEach((question) => {
      if (question.depAction === 'DISABLE') {
        watches.push(methods.watch(question.depRequirementOptionCd))
      }
    })
    if (watches.length > 0) {
      watchFields = watches
    }
  }, [questions])

  useEffect(() => {
    medQuestions.forEach((subList) => {
      subList.forEach((question) => {
        if (isDisabled(question)) {
          if (question.displayType === 'CALENDAR') {
            methods.setValue(question.requirementOptionCd, { input: null, selected: null })
          } else {
            methods.setValue(question.requirementOptionCd, null)
          }
        }
      })
    })
  }, [watchFields, methods])

  useEffect(() => {
    if (selectedItem !== null) {
      let watches = []
      medQuestions[selectedItem].forEach((question) => {
        if (question.depAction === 'DISABLE') {
          watches.push(methods.watch(question.depRequirementOptionCd))
        }
      })
      if (watches.length > 0) {
        watchFields = watches
      }
    }
  }, [selectedItem])

  const handleSave = async () => {
    const isValid = await methods.trigger()
    if (isValid) {
      const formData = methods.getValues()

      const updatedQuestions = [...medQuestions]
      updatedQuestions.forEach((subList, i) => {
        subList.forEach((question) => {
          question.provisionSeqNum = i + 1
        })
      })

      const selectedQuestions = updatedQuestions[selectedItem]
      selectedQuestions.forEach((question) => {
        const value = formData[question.requirementOptionCd]
        if (question.displayType === 'CALENDAR') {
          question.dateValue = value ? formData[question.requirementOptionCd].input : null
        } else {
          question.textValue = value ? formData[question.requirementOptionCd] : null
        }
      })

      onQuestionsChange(updatedQuestions.flat())
      setSelectedItem(null)
    }
  }

  const handleCancel = (index) => {
    methods.reset()
    if (medQuestions[index][0].provisionSeqNum !== null) {
      setSelectedItem(null)
    }
    if (
      medQuestions.length > 1 &&
      index === medQuestions.length - 1 &&
      medQuestions[index][0].provisionSeqNum === null
    ) {
      setMedQuestions(medQuestions.slice(0, -1))
      setSelectedItem(null)
    }
  }

  const handleEdit = (index) => {
    medQuestions[index].forEach((question) => {
      if (question.displayType === 'CALENDAR') {
        const dateValue = question.dateValue ? moment(question.dateValue).format('MM/DD/YYYY') : null
        methods.setValue(question.requirementOptionCd, { input: dateValue, selected: dateValue })
      } else {
        methods.setValue(question.requirementOptionCd, question.textValue)
      }
    })
    setSelectedItem(index)
  }

  const handleAdd = () => {
    const newMedQuestions = medQuestions[0].map((question) => ({
      ...question,
      textValue: null,
      dateValue: null,
      provisionSeqNum: null,
    }))
    setSelectedItem(medQuestions.length)
    setMedQuestions([...medQuestions, newMedQuestions])
    newMedQuestions.forEach((question) => {
      if (question.displayType === 'CALENDAR') {
        methods.setValue(question.requirementOptionCd, {})
      } else {
        methods.setValue(question.requirementOptionCd, null)
      }
    })
  }

  const handleDelete = (index) => {
    let newMedQuestions
    if (medQuestions.length === 1) {
      medQuestions[0].forEach((question) => {
        if (question.displayType === 'CALENDAR') {
          methods.setValue(question.requirementOptionCd, {})
        } else {
          methods.setValue(question.requirementOptionCd, null)
        }
      })
      newMedQuestions = [
        medQuestions[0].map((question) => ({ ...question, textValue: null, dateValue: null, provisionSeqNum: null })),
      ]
      setSelectedItem(0)
    } else {
      newMedQuestions = medQuestions.filter((_, i) => i !== index)
    }
    setMedQuestions(newMedQuestions)
    onQuestionsChange(newMedQuestions.flat())
  }

  const getMedicationField = (medication, field) => {
    const medField = medication.find((q) => q.requirementOptionCd === field)
    if (medField?.displayType === 'CALENDAR') {
      return medField.dateValue
        ? new Date(medField.dateValue).toLocaleDateString('en-US', { year: 'numeric', month: 'short' })
        : ''
    }
    return medField ? medField.textValue : ''
  }

  const isDisabled = (question) => {
    if (question.depAction === 'DISABLE') {
      const depValue = methods.getValues()[question.depRequirementOptionCd]
      return depValue !== question.depRequirementValue
    }
    return false
  }

  const validateField = (value, question) => {
    const isEmpty = question.displayType === 'CALENDAR' ? isNil(value) || !value.input : !value
    if (!isDisabled(question) && isEmpty) {
      return REQUIRED_FIELDS
    }
    if (!isEmpty && question.displayType === 'CALENDAR') {
      const date = moment(value.input, 'MM/DD/YYYY', true)
      if (!date.isValid()) {
        return 'Please enter a valid date'
      }
      if (date.isAfter(moment())) {
        return 'The date must be in the past'
      }
    }
    return true
  }

  return (
    <>
      {medQuestions.map((currentItem, index) => {
        if (selectedItem !== null && selectedItem === index) {
          return (
            <div className="border-2 pl-5 pb-4 mt-3" key={index}>
              <FormProvider {...methods}>
                {currentItem.map((q, i) => (
                  <div key={i}>
                    {(() => {
                      const variables = {
                        name: applicant.firstName,
                        firstname: applicant.firstName,
                      }
                      const processedText = q.optionName ? parseForVariables(q.optionName, variables) : null
                      const processedDesc = q.optionDescription
                        ? parseForVariables(q.optionDescription, variables)
                        : null
                      switch (q.displayType) {
                        case 'TEXTFIELD': {
                          return (
                            <div className="max-w-sm mt-3">
                              {processedDesc}
                              <Controller
                                render={({ field, fieldState }) => {
                                  const { ref, ...fields } = field
                                  return (
                                    <TextField
                                      {...fields}
                                      id={i}
                                      label={processedText}
                                      maxLength={2500}
                                      error={fieldState.invalid}
                                      helperText={fieldState.error?.message}
                                    />
                                  )
                                }}
                                name={q.requirementOptionCd}
                                rules={{
                                  validate: (value) => validateField(value, q),
                                }}
                              />
                            </div>
                          )
                        }
                        case 'CALENDAR': {
                          return (
                            <div className="max-w-sm mt-3">
                              {processedDesc}
                              <Controller
                                render={({ field, fieldState }) => {
                                  const { ref, ...fields } = field
                                  return (
                                    <DatePicker
                                      {...fields}
                                      id={i}
                                      label="MM/DD/YYYY"
                                      error={fieldState.invalid}
                                      helperText={fieldState.error?.message}
                                      disabled={isDisabled(q)}
                                    />
                                  )
                                }}
                                name={q.requirementOptionCd}
                                rules={{
                                  validate: (value) => validateField(value, q),
                                }}
                              />
                            </div>
                          )
                        }
                        case 'RADIO': {
                          return (
                            <div className="max-w-sm mt-3">
                              {processedDesc}
                              <Controller
                                render={({ field, fieldState }) => {
                                  const { ref, ...fields } = field
                                  return (
                                    <div>
                                      <Radio
                                        {...fields}
                                        key="0"
                                        id={`yes-${i}`}
                                        inline
                                        label="Yes"
                                        value="YES"
                                        isInvalid={fieldState.invalid}
                                        checked={field.value === 'YES'}
                                        name={q.requirementOptionCd}
                                      />
                                      <Radio
                                        {...fields}
                                        key="1"
                                        id={`no-${1}`}
                                        inline
                                        label="No"
                                        value="NO"
                                        checked={field.value === 'NO'}
                                        name={q.requirementOptionCd}
                                      />
                                      {fieldState.invalid && (
                                        <div>
                                          <HelperText id={`error-${i}`} error>
                                            {fieldState.error?.message}
                                          </HelperText>
                                        </div>
                                      )}
                                    </div>
                                  )
                                }}
                                name={q.requirementOptionCd}
                                rules={{
                                  validate: (value) => validateField(value, q),
                                }}
                              />
                            </div>
                          )
                        }
                        default:
                          return null
                      }
                    })()}
                  </div>
                ))}
              </FormProvider>
              <div className="flex mt-3 gap-x-2">
                <Button variant="tertiary" onClick={() => handleCancel(index)}>
                  Cancel
                </Button>
                <Button variant="secondary" onClick={handleSave}>
                  Save
                </Button>
              </div>
            </div>
          )
        } else {
          const indicator = getMedicationField(currentItem, 'MedCurrInd')
          return (
            <div className="border-2 p-3 mt-3 flex justify-between items-center" key={index}>
              <div>
                <p>
                  <Bold>{getMedicationField(currentItem, 'MedName')}</Bold>
                </p>
                {indicator === 'YES' && <p>Used since {getMedicationField(currentItem, 'MedStartDt')}</p>}
                {indicator === 'NO' && (
                  <p>
                    Used between {getMedicationField(currentItem, 'MedStartDt')} and{' '}
                    {getMedicationField(currentItem, 'MedStopDt')}
                  </p>
                )}
                <p>Treatment for {getMedicationField(currentItem, 'MedCond')}</p>
              </div>
              <div className="flex gap-2">
                <Button
                  variant={selectedItem === null ? 'tertiary' : 'primary'}
                  onClick={() => handleEdit(index)}
                  disabled={selectedItem !== null}>
                  Edit
                </Button>
                <Button
                  variant={selectedItem === null ? 'tertiary' : 'primary'}
                  onClick={() => handleDelete(index)}
                  disabled={selectedItem !== null}>
                  Delete
                </Button>
              </div>
            </div>
          )
        }
      })}
      <div className="mt-6">
        <Button variant="secondary" disabled={selectedItem !== null} onClick={handleAdd}>
          Add medication
        </Button>
      </div>
    </>
  )
}
