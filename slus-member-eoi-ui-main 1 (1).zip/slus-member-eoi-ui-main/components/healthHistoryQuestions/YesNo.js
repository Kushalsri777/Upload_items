import { useEffect, useState } from 'react'
import { Button } from '@/components/helios-components'

const YesNo = ({ status, onChange }) => {
  const [currentStatus, setCurrentStatus] = useState(null)

  const styleDivBoth = {
    border: '2px solid #e0dcdc',
    verticalAlign: 'middle',
  }

  const styleButtonYes = {
    minWidth: '10.5rem',
    minHeight: '3.5rem',
    color: currentStatus === 'YES' ? 'var(--brand-tertiary-900)' : '#78747c',
    border: currentStatus === 'YES' ? '2px solid var(--brand-tertiary-900)' : 'none',
    transition: 'all ease-in-out .25s',
  }

  const styleButtonNo = {
    minWidth: '10.5rem',
    minHeight: '3.5rem',
    color: currentStatus === 'NO' ? 'var(--brand-tertiary-900)' : '#78747c',
    border: currentStatus === 'NO' ? '2px solid var(--brand-tertiary-900)' : 'none',
    transition: 'all ease-in-out .25s',
  }

  const styleVertical = {
    borderLeft: '1px solid #e0dcdc',
    height: '40px',
    zIndex: '-1',
  }

  const handleOnClickYes = () => {
    onChange('YES')
  }

  const handleOnClickNo = () => {
    onChange('NO')
  }

  useEffect(() => {
    setCurrentStatus(status)
  }, [status])

  return (
    <>
      <div className="flex flex-row">
        <div style={styleDivBoth} className="flex items-center">
          <div>
            <Button style={styleButtonYes} variant="tertiary" onClick={handleOnClickYes}>
              Yes
            </Button>
          </div>
          <div style={styleVertical} />
          <div>
            <Button style={styleButtonNo} variant="tertiary" onClick={handleOnClickNo}>
              No
            </Button>
          </div>
        </div>
      </div>
    </>
  )
}

export default YesNo
