import { useEffect } from 'react'
import Fullname from '@/components/personal/fullname'
import { Controller, useFormContext } from 'react-hook-form'
import InputMask from 'react-input-mask'
import { Dropdown, TextField } from '@component-library/helios'
import unitedStates from '@/components/unitedStates'
import { useEnrollerApplications } from '@/components/context/EnrollerApplications.context'

const getNameControls = (name) => [
  {
    label: 'First name',
    controllerName: 'firstName',
    requiredErrorMessage: `Please tell us the first name of the physician. If ${name} does not have one, please type in "None"`,
  },
  {
    label: 'Last name',
    controllerName: 'lastName',
    requiredErrorMessage: `Please tell us the last name of the physician. If ${name} does not have one, please type in "None"`,
  },
]

const PrimaryPhysician = ({ id, name, applicant }) => {
  const enrollerApplications = useEnrollerApplications()
  const methods = useFormContext()
  const { control, setValue } = methods

  const getCurrentEnroller = () => {
    const { type } = applicant || {}
    const currentEnroller = enrollerApplications[type.code.toLowerCase()]
    return currentEnroller
  }

  const handleTransformStateOutput = (selection) => {
    const { option } = selection || {}
    const { value } = option || {}
    return value
  }

  useEffect(() => {
    const currentEnroller = getCurrentEnroller()
    const { answers } = currentEnroller
    const answer = answers?.[id]
    const { value } = answer || {}
    const { firstName, lastName, street, city, state, zip, phone } = value || {}
    setValue('firstName', firstName)
    setValue('lastName', lastName)
    setValue('street', street)
    setValue('city', city)
    setValue('state', state)
    setValue('zip', zip)
    setValue('phone', phone)
  }, [])

  return (
    <div className="max-w-sm">
      <Fullname controls={getNameControls(name)} />
      <div className="mb-4">
        <Controller
          control={control}
          name="street"
          render={({ field }) => {
            const { ref, ...fields } = field
            return <TextField {...fields} id={field.name} label="Street address" />
          }}
        />
      </div>
      <div className="mb-4">
        <Controller
          control={control}
          name="city"
          render={({ field }) => {
            const { ref, ...fields } = field
            return <TextField {...fields} id={field.name} label="City" />
          }}
        />
      </div>
      <div className="mb-4 row">
        <div className="col-6">
          <Controller
            control={control}
            name="state"
            render={({ field }) => {
              const { ref, onChange, value, ...fields } = field
              return (
                <Dropdown
                  id={field.name}
                  {...fields}
                  label="State"
                  options={unitedStates}
                  selected={value}
                  onChange={(e) => onChange(handleTransformStateOutput(e))}
                />
              )
            }}
          />
        </div>
        <div className="col-6">
          <Controller
            control={control}
            name="zip"
            render={({ field }) => {
              const { ref, ...fields } = field
              return <TextField {...fields} id={field.name} label="Zip" />
            }}
          />
        </div>
      </div>
      <div className="mb-4">
        <Controller
          control={control}
          name="phone"
          render={({ field }) => {
            const { ref, ...fields } = field
            return (
              <InputMask
                {...fields}
                mask={'(999) 999-9999'}
                maskChar={null}
                alwaysShowMask={false}
                permanents={[0, 4, 5]}
                formatChars={{ 9: '[0-9]' }}
                value={fields.value}
                onChange={fields.onChange}>
                {(inputProps) => <TextField {...inputProps} id={field.name} label="Phone" />}
              </InputMask>
            )
          }}
        />
      </div>
    </div>
  )
}

export default PrimaryPhysician
