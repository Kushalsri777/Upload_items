import { COMPLETED, NOT_STARTED, STARTED } from '@/common/enums/guidedExperienceStepStatus'
import {
  DATA_STEP_ID_ADDICTION,
  DATA_STEP_ID_CANCER,
  DATA_STEP_ID_MEDICATIONS,
  DATA_STEP_ID_NEUROLOGICAL,
  DATA_STEP_ID_REVIEW,
} from '@/common/enums/healthHistorySteps'
import { useApplicants } from '@/components/context/Applicants.context'
import { useHealthHistorySteps } from '@/components/context/HealthHistorySteps.context'
import { StepHandlerContext } from '@/components/context/StepHandler.context'
import { getApplicantQuestions } from '@/components/healthHistoryQuestions/steps/util'
import { Drawer, GuidedExperience, HelperText } from '@/components/helios-components'
import { useEffect, useState } from 'react'
import { FormProvider, useForm } from 'react-hook-form'
import styles from './healthHistoryDrawer.module.css'
import StepAddiction from './steps/addiction'
import StepCancer from './steps/cancer'
import StepMedications from './steps/medications'
import StepNeurological from './steps/neurological'
import StepReview from './steps/review'

const GE_CONFIG = {
  heading: 'Health history questions',
  steps: [
    {
      stepId: DATA_STEP_ID_CANCER,
      component: StepCancer,
    },
    {
      stepId: DATA_STEP_ID_NEUROLOGICAL,
      component: StepNeurological,
    },
    {
      stepId: DATA_STEP_ID_ADDICTION,
      component: StepAddiction,
    },
    {
      stepId: DATA_STEP_ID_MEDICATIONS,
      component: StepMedications,
    },
    {
      stepId: DATA_STEP_ID_REVIEW,
      component: StepReview,
    },
  ],
}

export function HealthHistoryDrawer({ applicant, showDrawer, onClose }) {
  const [applicantName, setApplicantName] = useState()
  const [activeIndex, setActiveIndex] = useState(0)
  const [stepHandler, setStepHandler] = useState({ onClickNext: async () => true })
  const { stepCancer, stepNeurological, stepAddiction, stepMedications, stepReview } = useHealthHistorySteps()
  const applicants = useApplicants()

  const methods = useForm({
    mode: 'onTouched',
  })

  const getStep = (stepId) => {
    switch (stepId) {
      case DATA_STEP_ID_CANCER:
        return stepCancer
      case DATA_STEP_ID_NEUROLOGICAL:
        return stepNeurological
      case DATA_STEP_ID_ADDICTION:
        return stepAddiction
      case DATA_STEP_ID_MEDICATIONS:
        return stepMedications
      case DATA_STEP_ID_REVIEW:
        return stepReview
      default:
        throw Error(`Unknown stepId: ${stepId}`)
    }
  }

  const getInvalidQuestions = (stepId) => {
    const questions = getApplicantQuestions(applicant, applicants)
    return questions.filter((q) => {
      return q.requirementOptionUsageCd === stepId && q.errorMessage
    })
  }

  const hasStarted = () => {
    return getApplicantQuestions(applicant, applicants).filter((q) => q.textValue).length > 0
  }

  const getStepStatus = (stepId) => {
    if (stepId === DATA_STEP_ID_REVIEW) {
      return hasStarted() ? STARTED : NOT_STARTED
    }
    const stepQuestions = getApplicantQuestions(applicant, applicants).filter(
      (q) => q.requirementOptionUsageCd === stepId && q.displayType !== 'LABEL',
    )
    let completedCount = stepQuestions.filter((q) => {
      return q.textValue
    })?.length
    completedCount = completedCount || 0
    if (completedCount === 0) {
      if (stepId === DATA_STEP_ID_CANCER) {
        return STARTED
      }
      return NOT_STARTED
    }
    if (completedCount < stepQuestions.length) {
      return STARTED
    }
    if (completedCount === stepQuestions.length) {
      return COMPLETED
    }
  }

  const isAllStepYesNoQuestionsAnsweredNo = () => {
    const allQuestions = getApplicantQuestions(applicant, applicants)
    return allQuestions.filter((q) => q.displayType === 'SLIDER').every((q) => !q.textValue || q.textValue === 'NO')
  }

  const isCurrentStepValid = async () => {
    const { onClickNext } = stepHandler
    return await onClickNext()
  }

  const handleOnClickActionPrevious = async () => {
    const isValid = await isCurrentStepValid()
    if (!isValid) {
      return false
    }

    onClose()
  }

  const handleOnClickActionNext = async () => {
    const isValid = await isCurrentStepValid()
    if (!isValid) {
      return false
    }
    const newActiveIndex = Math.min(GE_CONFIG.steps.length - 1, activeIndex + 1)
    if (activeIndex === newActiveIndex) {
      // this means we are on the last step trying to proceed
      onClose()
    } else {
      setActiveIndex(newActiveIndex)
    }
  }

  const handleOnStepClick = async (currId, clickedId) => {
    const indexOfDash = clickedId.lastIndexOf('-')
    const newActiveIndexSubstr = clickedId.substr(indexOfDash + 1)
    const newActiveIndex = parseInt(newActiveIndexSubstr)
    const isValid = await stepHandler.onClickNext(true)
    if (isValid) {
      setActiveIndex(newActiveIndex)
    }
  }

  const getLabel = (step) => {
    const { label } = getStep(step.stepId)
    return label
  }

  const getDescription = ({ stepId }) => {
    const invalidQuestions = getInvalidQuestions(stepId)
    if (invalidQuestions?.length === 0) return null

    const count = invalidQuestions.length
    let helperText
    if (count === 1) {
      helperText = 'There is 1 question with an error on this page'
    } else {
      helperText = `There are ${count} questions with an error on this page`
    }
    return [
      <HelperText error key="helper-text">
        {helperText}
      </HelperText>,
    ]
  }

  const isLastStep = () => {
    return GE_CONFIG.steps.length - 1 === activeIndex
  }
  const getFinalButtonText = () => {
    if (!isLastStep()) {
      return 'Next Step'
    }
    return 'Countinue to follow-up questions'
  }

  const getActionButtons = () => {
    const isLastStep = GE_CONFIG.steps.length - 1 === activeIndex
    const isAllAnsweredNo = isAllStepYesNoQuestionsAnsweredNo()
    if (isLastStep && isAllAnsweredNo) {
      return [
        {
          id: 2,
          children: 'Save and finish',
          variant: 'primary',
          onClick: handleOnClickActionNext,
        },
      ]
    }

    return [
      {
        id: 1,
        children: 'Save and return to dashboard',
        variant: 'secondary',
        onClick: handleOnClickActionPrevious,
      },
      {
        id: 2,
        children: getFinalButtonText(),
        variant: 'primary',
        onClick: handleOnClickActionNext,
      },
    ]
  }

  useEffect(() => {
    if (!applicant?.firstName) {
      return
    }

    setApplicantName(applicant.firstName)
  }, [applicant])

  useEffect(() => {
    let index = GE_CONFIG.steps.findIndex((s) => {
      const status = getStepStatus(s.stepId)
      return status === NOT_STARTED || status === STARTED
    })
    if (index < 0) {
      index = GE_CONFIG.steps.length - 1
    }
    setActiveIndex(index)
  }, [])

  const getCurrentActiveComponent = () => {
    const ActiveComponent = GE_CONFIG.steps.at(activeIndex).component

    return (
      <FormProvider {...methods}>
        <ActiveComponent name={applicantName} applicant={applicant} />
      </FormProvider>
    )
  }

  const ActiveComponent = GE_CONFIG.steps[activeIndex].component
  return (
    <Drawer
      className={styles.drawer}
      aria-describedby="drawer-drawer-body"
      closeLabel="Close"
      id="health-history-drawer"
      onExit={onClose}
      onExited={onClose}
      size="large"
      show={showDrawer}
      actions={getActionButtons()}>
      <StepHandlerContext.Provider value={{ stepHandler, setStepHandler }}>
        <GuidedExperience
          className={styles.guidedExp}
          action={{}} // using actions on the drawer component
          heading={GE_CONFIG.heading}
          activeStep={`step-${activeIndex}`}
          onStepClick={handleOnStepClick}
          steps={GE_CONFIG.steps.map((s, i) => {
            return {
              id: `step-${i}`,
              label: getLabel(s),
              status: getStepStatus(s.stepId),
              title: s.label,
              description: getDescription(s),
            }
          })}>
          {getCurrentActiveComponent()}
        </GuidedExperience>
      </StepHandlerContext.Provider>
    </Drawer>
  )
}
