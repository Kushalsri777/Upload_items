import React from 'react'
import { usePathname } from 'next/navigation'
import { ELECTRONIC_CONSENT } from '@/common/utils/pageText'
import { PRINT } from '@/common/enums/imageIcons'
import PageLink from './pageLink'

const Tx = ({ children, isHeader, ...rest }) =>
  isHeader ? <th {...rest}>{children}</th> : <td {...rest}>{children}</td>

const renderColumn = (item, i, isHeader, style) => (
  <Tx isHeader={isHeader} key={`key_table_data_${i}`} style={style}>
    {item}
  </Tx>
)

const renderColumns = (array, isHeader) =>
  array.map((item, i) => {
    if (typeof item === 'string') {
      return renderColumn(item, i, isHeader)
    }
    return renderColumn(item.data, i, isHeader, item.style)
  })

const renderTableRow = (row, i) => {
  if (Array.isArray(row)) {
    return <tr key={`key_table_row_${i}`}>{renderColumns(row)}</tr>
  }
  return (
    <tr key={`key_table_row_${i}`} className={row.className}>
      {renderColumns(row.data, row.isHeader)}
    </tr>
  )
}

const renderTable = (tableArray) => (
  <table>
    <tbody>{tableArray.map((row, i) => renderTableRow(row, i))}</tbody>
  </table>
)

const marginTop = '40px'
const marginRight = '20px'
const marginBottom = '40px'
const marginLeft = '20px'
const getPageMargins = () => {
  return `@page { margin: ${marginTop} ${marginRight} ${marginBottom} ${marginLeft} !important; }`
}

const ElectronicConsentDisclosure = React.forwardRef(({ children, handlePrint }, ref) => {
  const pathname = usePathname()
  return (
    <div ref={ref}>
      <style>{getPageMargins()}</style>
      <div className="mt-14">
        <div className="text-4xl mb-8">{ELECTRONIC_CONSENT.title}</div>
        <div className="mr-1 mb-8">
          <PageLink image={<PRINT />} label={ELECTRONIC_CONSENT.link} onClick={handlePrint} />
        </div>
        {ELECTRONIC_CONSENT.body.paragraphs
          .filter((p) => {
            return typeof p.isVisible === 'function' ? p.isVisible(pathname) : true
          })
          .map((p, i) => (
            <div key={`key_div_${i}`} className="pb-4 text-sm">
              {p.subTitle ? <div className="font-sunlifeBold text-base pb-2">{p.subTitle}</div> : null}
              {p.values ? p.values.map((v, j) => <div key={`key_p_div_${j}`}>{v}</div>) : null}
              {p.table ? renderTable(p.table) : null}
            </div>
          ))}
        {children}
      </div>
    </div>
  )
})
ElectronicConsentDisclosure.displayName = 'ElectronicConsentDisclosure'

export default ElectronicConsentDisclosure
