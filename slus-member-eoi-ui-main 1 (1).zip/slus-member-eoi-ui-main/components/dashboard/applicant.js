import Questionnaire from './Questionnaire'
import { getButtonText, getDisplayStatusText } from '@/common/utils/questionUtils'

const fullName = ({ firstName, lastName }) => {
  return `${firstName} ${lastName}`
}

const Applicant = ({
  applicant = { firstName: 'Not Specified', questions: [] },
  label,
  buttonVariant = 'secondary',
  onClickAction = console.log,
  disableRemove = false,
  onClickRemove = console.log,
  isLoading,
  questionFilter = () => true,
}) => {
  const { questions, status } = applicant
  const filteredQuestions = questions?.filter(questionFilter)
  const [landingStatusText, statusCode] = getDisplayStatusText(filteredQuestions, status)
  const buttonText = getButtonText(statusCode)
  const displayLabel = label || fullName(applicant)

  return (
    <Questionnaire
      applicant={applicant}
      label={displayLabel}
      status={landingStatusText}
      buttonText={buttonText}
      buttonVariant={buttonVariant}
      onClickAction={onClickAction}
      disableRemove={disableRemove}
      onClickRemove={onClickRemove}
      isLoading={isLoading}
    />
  )
}

export default Applicant
