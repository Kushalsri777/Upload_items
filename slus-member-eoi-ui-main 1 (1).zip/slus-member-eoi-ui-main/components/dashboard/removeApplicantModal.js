'use client'

import { Button, Modal, ModalBody, ModalFooter } from '@/components/helios-components'

function RemoveApplicantModal({ show, name, onClickCancel = console.log, onClickRemove = console.log }) {
  return (
    <>
      <Modal
        id="remove-applicant-modal"
        show={show}
        heading={
          <div style={{ fontSize: '36px', lineHeight: '40px' }}>
            Are you sure you want to remove {name} from the application?
          </div>
        }
        onHide={onClickCancel}>
        <ModalBody>
          <div>
            <div className="text-xl">
              If {name} doesn&apos;t need to be approved for EOI, then please remove them. But once removed, you&apos;ll
              have to start at the beginning if you want to add them again.
            </div>
          </div>
        </ModalBody>
        <ModalFooter>
          <div className="flex-nowrap w-full">
            <div className="flex flex-col md:flex-row whitespace-nowrap">
              <Button id="action-button-secondary" variant="secondary" onClick={onClickCancel}>
                Cancel
              </Button>
              <Button id="action-button-primary" variant="primary" onClick={onClickRemove}>
                Remove
              </Button>
            </div>
          </div>
        </ModalFooter>
      </Modal>
    </>
  )
}

export default RemoveApplicantModal
