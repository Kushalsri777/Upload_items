'use client'

import { useState } from 'react'
import { Button, Link } from '@/components/helios-components'
import RemoveApplicantModal from './removeApplicantModal'

const Questionnaire = ({
  applicant = {},
  label = 'Not specified',
  status = 'Not started',
  buttonText = 'Start',
  buttonVariant = 'secondary',
  onClickAction = console.log,
  disableRemove = false,
  onClickRemove = console.log,
  isLoading = false,
}) => {
  const [showRemoveModal, setShowRemoveModal] = useState(false)

  const handleOnClickRemove = () => {
    setShowRemoveModal(false)
    onClickRemove(applicant)
  }

  const displayStatus = isLoading ? '' : status

  return (
    <div className="flex place-items-center gap-4">
      <div className="flex-1">{label}</div>
      <div className="font-sunlifeItalic">{displayStatus}</div>
      <div>
        {isLoading && (
          <Button id="action-button-disabled" variant="tertiary" disabled={true}>
            <span className="fa-solid fa-spinner fa-spin" />
            &nbsp;&nbsp;Loading...
          </Button>
        )}
        {!isLoading && (
          <Button id="action-button" variant={buttonVariant} onClick={onClickAction}>
            {buttonText}
          </Button>
        )}
      </div>
      <div>{isLoading || disableRemove ? null : <Link onClick={() => setShowRemoveModal(true)}>Remove</Link>}</div>
      <div className="flex-none w-1/6">{/* This is intentially left blank */}</div>
      <RemoveApplicantModal
        name={label}
        show={showRemoveModal}
        onClickCancel={() => setShowRemoveModal(false)}
        onClickRemove={handleOnClickRemove}
      />
    </div>
  )
}

export default Questionnaire
