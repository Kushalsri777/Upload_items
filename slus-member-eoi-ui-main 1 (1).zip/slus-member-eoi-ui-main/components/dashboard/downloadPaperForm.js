import { useEffect, useState } from 'react'
import clsx from 'clsx'
import { APPLICANTS_PART } from './legacy/text/textData'
import { linkStyle as ls } from '@/common/utils/util'
import { navigateToPaperForm } from '@/common/utils/util'
import { DOWNLOAD } from '@/common/enums/imageIcons'

const { download } = APPLICANTS_PART

function DownloadPaperForm({ disabled }) {
  const [linkStyle, setLinkStyle] = useState(() => ls(disabled))

  useEffect(() => {
    setLinkStyle(() => ls(disabled))
  }, [disabled])

  return (
    <>
      <hr
        className={clsx('sl-divider border-t-[0.063rem] border-solid mb-[24px]', { 'mb-[80px]': disabled })}
        aria-hidden={true}
      />
      <div className={clsx(linkStyle, 'mx-8 my-[36px] font-bold', { hidden: disabled })} onClick={navigateToPaperForm}>
        <DOWNLOAD />
        {download}
      </div>
    </>
  )
}

export default DownloadPaperForm
