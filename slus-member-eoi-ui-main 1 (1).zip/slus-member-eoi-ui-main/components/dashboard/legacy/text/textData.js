const text1 = {
  a:
    'Please read the below Consumer Electronic Consent and Disclosure carefully ' +
    '(you must use the scroll bar to review the entire document). To agree to the Consumer Electronic Consent and Disclosure,' +
    ' click the “I agree” button. Once you have agreed, you may begin the EOI application by clicking START next to an applicant ' +
    'listed below. If there are no applicants listed, you may add them below by clicking “Add applicants.”',
}

const text2 = {
  a: 'If you do not wish to consent',
  b:
    'to the eSignature terms presented, you will not be able to comp' +
    'lete an online EOI application. Instead, you should access the a' +
    'ppropriate forms from the link provided, and complete and mail t' +
    'he paper application to the Sun Life to complete the Evidence of ' +
    'Insurability process.',
}

const text3 = {
  a: (
    <>
      <b>Customer Electronic Consent and Disclosure</b>
      <br />
      <br />
      IMPORTANT NOTICE - PLEASE READ CAREFULLY AND RETAIN A COPY FOR FUTURE REFERENCE
      <br />
      <br />
      Sun Life Assurance Company of Canada (&quot;Company,&quot; &quot;we&quot; or &quot;us&quot;) provides you with the
      option without charge to receive, in electronic format, certain information relating to your application for group
      insurance coverage(s) that would otherwise be sent to you in paper form by mail or otherwise. To receive
      application information in electronic format and complete an application electronically, you must provide us with
      your agreement to the following terms and conditions. If you click the &quot;I agree&quot; button, you will be
      providing your consent to:
      <br />
      <br />
      (a) have the information described in this Consumer Electronic Consent and Disclosure (&quot;Consent&quot;)
      delivered to you in electronic format;
      <br />
      (b) execute via electronic means the documents that are described in this Consent; and
      <br />
      (c) all of the terms and conditions set forth below in this Consent.
      <br />
      <br />
      If you do not want to have the information described in this Consent delivered to you in electronic format, if you
      do not want to execute via electronic means the documents that are described in this Consent, or if you do not
      agree with all of the terms and conditions of this Consent, you may not complete an application electronically and
      you should click the “I disagree” button. Please read the following terms and conditions carefully.
      <br />
      <br />
      <b>Scope and Duration of this Consent</b>
      <br />
      <br />
      By clicking the &quot;I agree&quot; button you agree to all of the terms and conditions of this Consent, including
      your agreement to: <br />
      <br />
      (a) receive via electronic means an Evidence of Insurability Application, including information that the Company
      is required by law to provide or make available to you in writing, as well as other information and documents
      related to your application (collectively, &quot;Application Documents&quot;); <br />
      (b) complete and execute via electronic means the Application Documents; and <br />
      (c) be bound with the same force and effect as if you had affixed your signature on paper by hand when you apply
      your electronic signature to Application Documents.
      <br />
      <br />
      Even though you have provided the Company with this Consent, the Company may, at its option: (a) deliver
      Application Documents to you on paper and (b) require that certain communications from you be delivered to the
      Company on paper.
      <br />
      <br />
      <b>Requesting Copies</b>
      <br />
      <br />
      You may obtain paper copies of Application Documents at any time and without charge by contacting us in a manner
      provided below (or such other manner as may be permitted in the future).
      <br />
      <br />
      <b>Maintaining Copies of Application Documents</b>
      <br />
      <br />
      You agree to print or save this Consent and all Application Documents, and to keep printed or electronic copies
      for your records. If you have any trouble with printing or saving, you should contact the Company.
      <br />
      <br />
      <b>Withdrawal of Your Consent/Termination of this Consent</b>
      <br />
      <br />
      This Consent will become effective when you click the &quot;I agree&quot; button and will remain in effect unless
      terminated by the Company in its sole discretion or until you withdraw your consent (as described below),
      whichever comes first.
      <br />
      <br />
      If at any time you would like to terminate this Consent and cease receiving Application Documents in electronic
      format, you must notify the Company in writing at the below address or telephone number. Your withdrawal of your
      consent to receive Application Documents in electronic format will be made with respect to all Application
      Documents and will not be made with respect to only some Application Documents. Your withdrawal of your consent to
      receive Application Documents in electronic format will become effective only after the Company has a reasonable
      period of time to process your withdrawal. Thereafter, all Application Documents will be provided to you on paper
      by mail.
      <br />
      <br />
      The Company may, at its option, treat your providing us with an invalid e-mail address, or the subsequent
      malfunction of a previously valid electronic address, as a withdrawal and termination of your consent to receive
      Application Documents in electronic format.
      <br />
      <br />
      The Company reserves the right, in its sole discretion, to discontinue providing Application Documents in
      electronic format, or to terminate or change the terms and conditions on which the Company provides electronic
      Application Documents. We will provide you with notice of any such termination or change as required by law.{' '}
      <br />
      <br />
      <b>Changes to Your Contact Information</b>
      <br />
      <br />
      It is your responsibility to promptly notify the Company of any changes to your e-mail address and all other
      contact information. You may inform us of any such changes by contacting us at the address provided below (or such
      other address as may be provided to you in the future). Such change will become effective only after we have a
      reasonable period of time to process the change. <br />
      <br />
      <b>Contacting the Company</b>
      <br />
      <br />
      <b>Mail:</b>
      <br />
      P.O. Box 81344 <br />
      Wellesley, MA 02481 <br />
      <br />
      <b>Telephone:</b> (800) 247-6875
      <br />
      <br />
      <b>Systems Requirements</b>
      <br />
      <br />
      To access and retain the Application Documents sent or made available to you electronically by the Company you
      must have access to a computer with an Internet connection. You must be able to send and receive e-mails, and be
      able to save the Application Documents to a storage device for later reference or have the computer connected to a
      printer so you can print such documents. Please contact the Company at the telephone number above if you have any
      trouble with printing or saving your Application Documents.
      <br />
      <br />
      PRINT OR SAVE A COPY OF THIS CONSENT AND DISCLOSURE NOW FOR FUTURE REFERENCE (To print press Ctrl+p (Windows) or
      select your browser’s print option.
      <br />
      <br />
      <b>
        I have CAREFULLY read this Consent and accept its provisions voluntarily and with full knowledge and
        understanding of its terms and conditions. I have computer hardware and software that meets the minimum hardware
        and software requirements described above. I have successfully printed or saved a copy of this Consent and
        Disclosure.
        <br />
        By clicking the &quot;I agree&quot; button, I agree to receive and execute electronic Application Documents in
        accordance with the terms described above.
      </b>
    </>
  ),
}

const disagreeModal = {
  header: 'Disagreeing to Electronic Consent',
  body:
    'By disagreeing to the electronic consent you are agreeing to' +
    ' submit your EOI application with a paper form. You won’t be abl' +
    'e to change your election.',
  button: {
    primary: 'Okay, use paper form',
    secondary: 'I changed my mind',
  },
}

const applicantsPart = {
  header: 'Who needs coverage?',
  action: 'Add applicants',
  info: {
    a: 'Important:',
    b:
      'Failure to provide complete responses will result in underwri' +
      'ting delays or non-payment of claims. This request for coverag' +
      'e is not effective until approved in writing by Sun Life. N' +
      'o information provided by you or your agent shall bind Sun Life' +
      ' unless you provide such information in writing on this fo' +
      'rm. No agent or broker has authority to alter the contents of ' +
      'this form.',
  },
  none: "There aren't any applicants. Please add one to get started",
  download: 'Download paper form',
}

const drawer = {
  header: 'Add Applicants',
  subHeader: "Select which applicants you'd like to add to your EOI a" + 'pplication',
  action: {
    primary: 'Save Applicants',
    secondary: 'Back',
  },
  ee: 'Employee',
  sp: 'Spouse/Partner',
  ch: 'Child',
  childCount: {
    label: 'Number of covered children',
    hint: 'Number of children',
  },
  errors: {
    removeApplicant: "Please select the applicant you'd like to remove from the dashboard",
  },
}

const readiness = {
  header: 'Application readiness',
  info: 'Once all applicants are completed you will be able to submit the application',
  action: 'Submit EOI Application',
  status: {
    ready: 'Ready to submit',
    notReady: 'Not ready to submit',
  },
}

export {
  text1 as TEXT_1,
  text2 as TEXT_2,
  text3 as TEXT_3,
  disagreeModal as DISAGREE_MODAL,
  applicantsPart as APPLICANTS_PART,
  drawer as DRAWER,
  readiness as READINESS,
}
