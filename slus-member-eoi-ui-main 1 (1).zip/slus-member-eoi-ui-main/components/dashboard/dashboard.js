import { useEffect, useState } from 'react'
import { useApplicants, useApplicantsDispatcher } from '@/components/context/Applicants.context'
import { getHealthQuestions } from '@/common/utils/api'
import Layout from '@/components/layout'
import DashboardLanding from './dashboardLanding'
import DashboardApplicant from './dashboardApplicant'
import { isLevel1, mapFollowUps } from '@/common/enums/usageCode'

const SCREEN = {
  LANDING: 'LANDING',
  APPLICANT: 'APPLICANT',
}

function Dashboard() {
  const { updateQuestions } = useApplicantsDispatcher()
  const { policy } = useApplicants()

  const [screen, setScreen] = useState(SCREEN.LANDING)
  const [activeApplicant, setActiveApplicant] = useState(null)
  const [isLoading, setIsLoading] = useState(false)

  const handleActionPrimaryLanding = (activeApplicant) => {
    setActiveApplicant(activeApplicant)
    setScreen(SCREEN.APPLICANT)
  }

  const handleActionSecondaryApplicant = () => {
    setScreen(SCREEN.LANDING)
  }

  useEffect(() => {
    async function fetchQuestions() {
      setIsLoading(true)
      const allQuestions = await getHealthQuestions()
      // const followUpMappedQuestions = mapFollowUps(allQuestions)
      // const level1Questions = followUpMappedQuestions.filter(isLevel1)

      updateQuestions(allQuestions)
      setIsLoading(false)
    }
    fetchQuestions()
  }, [])

  return (
    <>
      <Layout disableContactInfo>
        {screen === SCREEN.LANDING && (
          <DashboardLanding handleActionPrimary={handleActionPrimaryLanding} isLoading={isLoading} />
        )}
        {screen === SCREEN.APPLICANT && (
          <DashboardApplicant
            applicant={activeApplicant}
            situsState={policy?.situsState}
            handleActionSecondary={handleActionSecondaryApplicant}
          />
        )}
      </Layout>
    </>
  )
}

export default Dashboard
