import { Drawer } from '@/components/helios-components'
import { FormProvider, useForm } from 'react-hook-form'
import Fullname from '@/components/personal/fullname'
import Gender from '@/components/personal/gender'
import DateOfBirth from '@/components/personal/dateOfBirth'
import Height from '@/components/personal/height'
import Weight from '@/components/personal/weight'
import { useEffect } from 'react'
import { useApplicants, useApplicantsDispatcher } from '@/components/context/Applicants.context'
import { saveEmployee, savePartner, updateChild } from '@/common/utils/api'
import Email from '@/components/personal/email'
import { DATE_OF_BIRTH } from '@/common/enums/regex'

const nameControls = [
  { label: 'First name', controllerName: 'firstName' },
  { label: 'Last name', controllerName: 'lastName' },
]

const defaultApplicantValues = {
  firstName: '',
  lastName: '',
  genderCode: '',
  dateOfBirth: '',
  heightFeet: '',
  heightInches: '',
  weight: '',
  identifier: '',
}

export function ApplicantDrawer({ applicant, showDrawer, onClose }) {
  const { isKnownUser } = useApplicants()
  const { updateEmployee, updateSpouse, updateChildren } = useApplicantsDispatcher()
  const { children } = useApplicants()

  const methods = useForm({
    mode: 'onTouched',
    defaultValues: defaultApplicantValues,
  })

  useEffect(() => {
    const dobFormated = DATE_OF_BIRTH.MM_DD_YYYY.convert(applicant?.dateOfBirth)

    methods.setValue('firstName', applicant?.firstName)
    methods.setValue('lastName', applicant?.lastName)
    methods.setValue('genderCode', applicant?.genderCode)
    methods.setValue('dateOfBirth', dobFormated)
    methods.setValue('heightFeet', applicant?.heightFeet)
    methods.setValue('heightInches', applicant?.heightInches)
    methods.setValue('weight', applicant?.weight)
    if (isEmployee || isSpouse) {
      methods.setValue('email', applicant?.email)
    }
  }, [applicant])

  const isEmployee = applicant?.type?.code === 'EMPLOYEE'
  const isSpouse = applicant?.type?.code === 'SPOUSE'

  const handleSaveApplicant = async () => {
    const isValid = await methods.trigger()
    if (isValid) {
      const values = methods.getValues()
      const isOk = await saveApplicant(values)
      if (isOk) {
        onClose()
      }
    }
  }

  function updateApplicant(values, returnedObject) {
    applicant.firstName = values.firstName
    applicant.lastName = values.lastName
    applicant.genderCode = values.genderCode
    applicant.dateOfBirth = values.dateOfBirth
    applicant.lastUpdatedDate = returnedObject?.lastUpdatedDate
    applicant.heightInches = values.heightInches
    applicant.heightFeet = values.heightFeet
    applicant.weight = values.weight
    if (isEmployee || isSpouse) {
      applicant.email = values.email
    }
  }

  const saveApplicant = async (values) => {
    if (applicant?.type?.code === 'EMPLOYEE') {
      const response = await saveEmployee(values)
      if (response.ok) {
        updateEmployee(values)
        updateApplicant(values, response.json())
      }
      return response.ok
    }
    if (applicant?.type?.code === 'SPOUSE') {
      const response = await savePartner(values, true)
      if (response.ok) {
        updateSpouse(values)
        updateApplicant(values, response.json())
      }
      return response.ok
    }
    if (applicant?.type?.code === 'CHILD') {
      const response = await updateChild(values, applicant.seqNum)
      if (response.ok) {
        updateChildren(children.map((child) => (child.seqNum === values.seqNum ? values : child)))
        updateApplicant(values, response.json())
      }
      return response.ok
    }
  }

  const handleExit = () => {
    onClose()
  }

  return (
    <Drawer
      actions={[
        {
          children: 'Save',
          id: '1',
          variant: 'primary',
          onClick: handleSaveApplicant,
        },
      ]}
      aria-describedby="drawer-drawer-body"
      closeLabel="Close"
      heading={`${applicant.firstName} ${applicant.lastName}`}
      id="drawerChild"
      onExit={handleExit}
      onExited={handleExit}
      size="medium"
      show={showDrawer}>
      <div className="w-full max-w-sm">
        <FormProvider {...methods}>
          <div className="mt-3 mb-3">All fields are required.</div>
          <Fullname
            controls={nameControls}
            isViewOnly={isKnownUser}
            validatePlaceholder={applicant?.type?.code !== 'EMPLOYEE'}
          />
          <Gender />
          <DateOfBirth />
          <Height />
          <Weight />
          {isSpouse && <Email controllerName="email" />}
        </FormProvider>
      </div>
    </Drawer>
  )
}
