import Acknowledgements from '../acknowledgements'
import { FRAUD_WARNING } from '@/common/enums/acknowledgementStep'

const FraudWarning = ({ applicants, applicantNames, setIsValid }) => {
  return (
    <>
      <div className="mt-10" style={{ fontSize: '30px' }}>
        Submit Application
      </div>
      <hr className="mt-3" />
      <div className="mt-10" style={{ fontSize: '30px' }}>
        Fraud Warning
      </div>
      <div className="xw-full max-w-3xl">
        <div className="mt-6">
          Any person who knowingly and with intent to defraud any insurance company or any other person files an
          application for insurance, containing any materially false information, or conceals, for the purpose of
          misleading, information concerning any fact material thereto commits a fraudulent insurance act, which is a
          crime and subjects such person to criminal and civil penalties.
        </div>
        <div className="mt-10" style={{ fontSize: '30px' }}>
          Acknowledgement and signature
        </div>
        <div className="mt-6">I confirm my understanding that:</div>
        <div className="mt-6 ml-6">
          <ul className="list-disc">
            <li>
              My EOI Application may be denied and I may be refused insurance if Sun Life Assurance Company of Canada or
              Sun Life and Health Insurance Company (U.S.)(&quot;The Company&quot;) determines that I am not insurable.
              If The Company determines that I am not insurable, it will explain in writing the basis of its
              determination.
            </li>
            <li>
              I may ask the Company in writing to: (a) obtain certain information from the EOI application file relating
              to me (a fee may be charged); (b) correct, amend or delete information in the EOI Application file
              relating to me (as permitted by applicable law); (c) file my own statement of facts if I believe any
              information in the EOI Application file relating to me is incorrect; and (d) provide me with a copy of my
              EOI Application.
            </li>
            <li>
              If I have any questions regarding my EOI Application, I can write to Sun Life, Group Medical Underwriting,
              P.O. Box 219390, Kansas City, MO 64121.
            </li>
            <li>I have read, or had read to me, the fraud warning for my state.</li>
            <li>
              I understand Sun Life is relying upon the accuracy and completeness of the information provided within the
              application to decide whether insurance may be issued. Any insurance issued upon incomplete or inaccurate
              information may be contested as permitted by the Group Policy and may result in a loss of coverage and
              claim denial.
            </li>
            <li>
              I attest that I am the person who has answered and/or reviewed the answers to the questions pertaining to
              my life and health history and have answered and/or reviewed the answers to the questions pertaining to
              any Dependent Child.
            </li>
            <li>
              I agree those answers are accurate and complete to the best of my knowledge and belief and provide my
              attestation by checking the &quot;I agree&quot; box.
            </li>
          </ul>
        </div>
        <Acknowledgements
          applicants={applicants}
          step={FRAUD_WARNING}
          applicantNames={applicantNames}
          setIsValid={setIsValid}
        />
      </div>
    </>
  )
}

export default FraudWarning
