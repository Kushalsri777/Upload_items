import Acknowledgements from '../acknowledgements'
import { HIPAA_AUTH } from '@/common/enums/acknowledgementStep'

const HIPAA_Authorization_NY = ({ applicants, applicantNames, setIsValid }) => {
  return (
    <>
      <div className="mt-10" style={{ fontSize: '30px' }}>
        Submit Application
      </div>
      <hr className="mt-3" />
      <div className="xw-full max-w-3xl">
        <div className="mt-10" style={{ fontSize: '30px' }}>
          Health Insurance Portability and Accountability Act (HIPAA)
        </div>
        <div className="mt-4" style={{ fontSize: '24px' }}>
          HIPAA Authorization
        </div>
        <div className="mt-3">
          I AUTHORIZE any physician, health care provider, health plan, medical professional, hospital, clinic,
          laboratory, pharmacy benefit manager or other medical or healthcare facility that has provided payment,
          treatment, or services to me or on my behalf, to disclose my entire medical record and any other protected
          health information concerning me to the Medical Underwriting Department of Sun Life Assurance Company of
          Canada or Sun Life and Health Insurance Company (U.S.) (&post; Sun Life&post;) its subsidiaries, affiliates,
          third party administrators, and reinsurers.
        </div>
        <div className="mt-4">
          I understand that such information may include records that relate to my physical or mental condition, such as
          diagnostic tests, physical examination notes and treatment histories, and that may include information
          regarding the diagnosis and treatment of human immunodeficiency virus (HIV) infection, sexually transmitted
          diseases, mental illness and the use of alcohol, drugs, and tobacco, but does not include psychotherapy notes.
        </div>
        <div className="mt-4">
          By my signature below, I acknowledge that any agreements I have made to restrict my protected health
          information do not apply to this Authorization, and I instruct any physician, health care professional,
          hospital, clinic, medical facility, or other health care provider to release and disclose my entire medical
          record without restriction.
        </div>
        <div className="mt-4">
          I understand that Sun Life will use the information it obtains to (a) administer claims; (b) determine or
          fulfill responsibility for coverage and provision of benefits; (c) administer coverage; and (d) conduct other
          legally permissible activities that relate to any coverage I have or have applied for with Sun Life.
        </div>
        <div className="mt-4">
          I understand that Sun Life will not disclose information it obtains about me except as authorized by this
          Authorization; as may be required or permitted by law; or as I may further authorize. I understand that if
          information is redisclosed as permitted by this Authorization, it may no longer be protected by applicable
          federal privacy law.
        </div>
        <div className="mt-4">
          I understand that: (a) this Authorization shall be valid for 24 months from the date I sign it; (b) I may
          revoke it at any time by providing written notice to Sun Life, Group Medical Underwriting, P.O. Box 219390,
          Kansas City, MO 64121, subject to the rights of any person who acted in reliance on it prior to receiving
          notice of its revocation; and (c) my authorized representative and I are entitled to receive a copy of the
          Authorization upon request.
        </div>
        <div className="mt-4">A copy of this Authorization shall be as valid as the original.</div>
        <Acknowledgements
          applicants={applicants}
          step={HIPAA_AUTH}
          applicantNames={applicantNames}
          setIsValid={setIsValid}
        />
      </div>
    </>
  )
}

export default HIPAA_Authorization_NY
