import { Checkbox } from '@/components/helios-components'

const AcknowledgeCheckbox = ({ id, name, isChecked = false, handleOnClick }) => {
  return (
    <Checkbox
      id={id}
      key={id}
      label={`I, ${name}, agree`}
      type="checkbox"
      checked={isChecked}
      onClick={({ target: { checked } }) => handleOnClick(checked)}
    />
  )
}

export default AcknowledgeCheckbox
