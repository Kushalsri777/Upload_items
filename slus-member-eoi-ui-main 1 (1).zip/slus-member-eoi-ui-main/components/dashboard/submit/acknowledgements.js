import { useEffect, useState } from 'react'
import AcknowledgeCheckbox from './acknowledgeCheckbox'
import { getFullName } from '@/common/utils/questionUtils'
import { useApplicants, useApplicantsDispatcher } from '@/components/context/Applicants.context'
import { useRequiredApplicants } from '@/components/context/RequiredApplicants.context'
import { EMPLOYEE, SPOUSE, CHILD } from '@/common/enums/enroller'

const Acknowledgements = ({ step, setIsValid = () => {} }) => {
  const { employee, spouse, children } = useApplicants()
  const { requireEmployee, requireSpouse, requireChildren } = useRequiredApplicants()
  const { setAcknowledge } = useApplicantsDispatcher()

  const getApplicant = (type, seqNum) => {
    switch (type) {
      case EMPLOYEE: {
        return employee
      }
      case SPOUSE: {
        return spouse
      }
      case CHILD: {
        return children.find((c) => c.seqNum === seqNum)
      }
    }
  }

  const getApplicants = () => {
    const result = []

    if (requireEmployee && employee) {
      result.push(employee)
    }

    if (requireSpouse && spouse) {
      result.push(spouse)
    }

    if (requireChildren && children) {
      result.push(...children)
    }

    return result
  }
  const [applicants] = useState(() => getApplicants())

  const handleApplicantAgreed = (applicant, isChecked) => {
    setAcknowledge(applicant, step, isChecked)
  }

  const handleIsChecked = (staleApplicant) => {
    const { type, seqNum } = staleApplicant
    const applicant = getApplicant(type, seqNum)
    const { acknowledgements } = applicant
    const { [step]: isChecked } = acknowledgements || {}
    return isChecked
  }

  useEffect(() => {
    const isEveryApplicantChecked = applicants.every((a) => handleIsChecked(a))
    console.log(`setting isValid to: ${isEveryApplicantChecked}`)
    setIsValid(isEveryApplicantChecked)
  })

  return (
    <div className="mt-4">
      {applicants?.map((a, i) => {
        return (
          <AcknowledgeCheckbox
            id={`acknowledgement-checkbox-${step}-${i}`}
            key={`acknowledgement-checkbox-${step}-${i}`}
            name={getFullName(a)}
            isChecked={handleIsChecked(a)}
            handleOnClick={(isChecked) => handleApplicantAgreed(a, isChecked)}
          />
        )
      })}
    </div>
  )
}

export default Acknowledgements
