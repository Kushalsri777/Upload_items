import { useState } from 'react'
import { useApplicants } from '@/components/context/Applicants.context'
import { Drawer } from '@/components/helios-components'
import FraudWarning_default from './default/fraudWarning'
import HIPAA_Authorization_default from './default/hipaaAuthorization'
import FraudWarning_NY from './NY/fraudWarning_NY'
import HIPAA_Authorization_NY from './NY/hipaaAuthorization_NY'
import { FRAUD_WARNING, HIPAA_AUTH } from '@/common/enums/acknowledgementStep'

const AcknowledgementDrawer = ({
  show,
  applicants,
  applicantNames,
  onClickPrimaryAction = console.log,
  onClickSecondaryAction = console.log,
}) => {
  const { policy } = useApplicants()
  const { situsState } = policy || {}

  const [step, setStep] = useState(FRAUD_WARNING)
  const [isValid, setIsValid] = useState(false)

  const getDrawerActions = () => {
    if (step === HIPAA_AUTH) {
      return [
        {
          id: 3,
          children: 'Back',
          variant: 'secondary',
          onClick: () => setStep(FRAUD_WARNING),
        },
        {
          id: 4,
          children: 'Submit Application',
          variant: 'primary',
          onClick: () => {
            onClickPrimaryAction()
          },
          disabled: !isValid,
        },
      ]
    }

    return [
      {
        id: 1,
        children: 'Close',
        variant: 'secondary',
        onClick: () => onClickSecondaryAction(),
      },
      {
        id: 2,
        children: 'Next',
        variant: 'primary',
        onClick: () => {
          setIsValid(false)
          setStep(HIPAA_AUTH)
        },
        disabled: !isValid,
      },
    ]
  }

  const getComponent = () => {
    switch (step) {
      case FRAUD_WARNING:
        switch (situsState) {
          case 'NY':
            return FraudWarning_NY
          default:
            return FraudWarning_default
        }
      case HIPAA_AUTH:
        switch (situsState) {
          case 'NY':
            return HIPAA_Authorization_NY
          default:
            return HIPAA_Authorization_default
        }
      default:
        throw new Error(`Unknown step value: ${step}`)
    }
  }
  const Component = getComponent()

  return (
    <>
      <Drawer
        closeLabel="Close"
        id="health-history-drawer"
        onExit={onClickSecondaryAction}
        onExited={onClickSecondaryAction}
        size="large"
        show={show}
        actions={getDrawerActions()}>
        <Component applicants={applicants} applicantNames={applicantNames} setIsValid={setIsValid} />
      </Drawer>
    </>
  )
}

export default AcknowledgementDrawer
