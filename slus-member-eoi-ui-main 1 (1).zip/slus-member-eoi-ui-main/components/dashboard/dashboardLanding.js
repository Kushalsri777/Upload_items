import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { useApplicants, useApplicantsDispatcher } from '@/components/context/Applicants.context'
import { useRequiredApplicants, useRequiredApplicantsDispatcher } from '@/components/context/RequiredApplicants.context'
import { Button, Divider, Link } from '@/components/helios-components'
import Applicant from '@/components/dashboard/applicant'
import { PartnerSpouseDrawer } from '@/components/onboarding/partnerSpouseDrawer'
import { ChildDrawer } from '@/components/onboarding/childDrawer'
import { EMPLOYEE, SPOUSE, CHILD } from '@/common/enums/enroller'
import { COMPLETE } from '@/common/enums/applicationStatusCode'
import { PRIMARY, SECONDARY, TERTIARY } from '@/common/enums/buttonVariant'
import AcknowledgementDrawer from './submit/acknowledgementDrawer'
import { Bold } from '../healthHistoryQuestions/steps/util'
import { removeChild, removePartner } from '@/common/utils/api'
import { isLevel1 } from '@/common/enums/usageCode'

function DashboardLanding({ handleActionPrimary, isLoading }) {
  const { employee, spouse, children, isKnownUser } = useApplicants()
  const { requireEmployee, requireSpouse, requireChildren } = useRequiredApplicants()
  const router = useRouter()

  const [showAddSpouse, setShowAddSpouse] = useState(false)
  const [showAddChild, setShowAddChild] = useState(false)
  const [showAcknowledgement, setShowAcknowledgement] = useState(false)

  const { deleteChild, deleteSpouse } = useApplicantsDispatcher()

  const { setEmployeeRequired } = useRequiredApplicantsDispatcher()

  const isDisabledSubmitButton = () => {
    if (isLoading) {
      return true
    }
    if (!requireEmployee && !requireSpouse && (!requireChildren || !children?.length)) {
      return true
    }
    return countApplicantsRemaining() > 0
  }

  const countApplicantsRemaining = () => {
    let count = 0

    if (requireEmployee && employee) {
      const { status } = employee
      count += COMPLETE === status ? 0 : 1
    }

    if (requireSpouse && spouse) {
      const { status } = spouse
      count += COMPLETE === status ? 0 : 1
    }

    if (requireChildren && children) {
      count += children.filter((c) => {
        const { status } = c
        return COMPLETE !== status
      }).length
    }

    return count
  }

  const getApplicantsRemainingDisplayText = () => {
    if (isLoading) {
      return ''
    }

    const count = countApplicantsRemaining()
    return `${count} applicant${count === 1 ? '' : 's'} remaining`
  }

  const getApplicantButtonVariant = (enroller, index) => {
    switch (enroller) {
      case EMPLOYEE: {
        const { status: eeStatus } = employee
        if (eeStatus === COMPLETE) {
          return TERTIARY
        }

        return PRIMARY
      }
      case SPOUSE: {
        const { status: spStatus } = spouse
        if (spStatus === COMPLETE) {
          return TERTIARY
        }

        if (requireEmployee && employee) {
          const { status: eeStatus } = employee
          if (eeStatus !== COMPLETE) {
            return SECONDARY
          }
        }

        return PRIMARY
      }
      case CHILD: {
        const { status: chStatus } = children[index]
        if (chStatus === COMPLETE) {
          return TERTIARY
        }

        if (requireEmployee && employee) {
          const { status: eeStatus } = employee
          if (eeStatus !== COMPLETE) {
            return SECONDARY
          }
        }

        if (requireSpouse && spouse) {
          const { status: spStatus } = spouse
          if (spStatus !== COMPLETE) {
            return SECONDARY
          }
        }

        const indexOfFirstNotCompletedChild = children.findIndex((c) => {
          const { status: chStatus } = c
          return chStatus !== COMPLETE
        })
        if (indexOfFirstNotCompletedChild === index) {
          return PRIMARY
        }

        return SECONDARY
      }
    }
  }

  const getApplicantNames = () => {
    const getFullName = (applicant) => {
      const { firstName: fn, lastName: ln } = applicant
      return `${fn} ${ln}`
    }
    const result = []

    if (requireEmployee && employee) {
      result.push(getFullName(employee))
    }

    if (requireSpouse && spouse) {
      result.push(getFullName(spouse))
    }

    if (requireChildren && children) {
      result.push(...children.map((c) => getFullName(c)))
    }

    return result
  }

  const getApplicants = () => {
    const result = []

    if (requireEmployee && employee) {
      result.push(employee)
    }

    if (requireSpouse && spouse) {
      result.push(spouse)
    }

    if (requireChildren && children) {
      result.push(...children)
    }

    return result
  }

  const handleOnClickRemoveEmployee = () => {
    setEmployeeRequired(false)
  }

  const handleOnClickRemoveSpouse = async () => {
    const response = await removePartner()
    if (response.ok) {
      deleteSpouse()
    }
  }

  const handleOnClickRemoveChild = async (child) => {
    const response = await removeChild(child.seqNum)
    if (response.ok) {
      deleteChild(child)
    }
  }

  const handleOnClickActionEmployee = () => {
    handleActionPrimary(employee)
  }

  const handleOnClickActionSpouse = () => {
    handleActionPrimary(spouse)
  }

  const handleOnClickActionChild = (child) => {
    handleActionPrimary(child)
  }

  const handleOnSubmitApplication = () => {
    console.log('SUBMIT APPLICATION!')
    // TODO: Send application(s) to backend

    router.push('/submitted')
  }

  return (
    <>
      <div>
        <div className="grid grid-flow-row grid-cols-3 mt-16 justify-items-end">
          <div className="col-span-2">
            <span className="font-sunlifeNewDisplay text-3.5xl">Evidence of Insurability Dashboard</span>
            <div className="mt-6">
              To submit your Evidence of Insurability (EOI) application, you must complete a questionnaire for each
              applicant. To begin, select <Bold>Start</Bold> for an applicant. Once all questionnaires are complete,
              select <Bold>Submit application</Bold>.
            </div>
            <div className="mt-6">
              <Bold>Please note</Bold>: You&apos;ll be able to edit and save your answers, and come back anytime during
              this process.
            </div>
          </div>
          <div className="flex flex-col place-items-center">
            <Button disabled={isDisabledSubmitButton()} onClick={() => setShowAcknowledgement(true)}>
              Submit application
            </Button>
            <span className="font-sunlifeBold text-xs-bold">{getApplicantsRemainingDisplayText()}</span>
          </div>
        </div>
        <div id="applicants" className="mt-10">
          <div>
            {requireEmployee && employee ? (
              <Applicant
                applicant={employee}
                buttonVariant={getApplicantButtonVariant(EMPLOYEE)}
                disableRemove={isKnownUser}
                onClickRemove={handleOnClickRemoveEmployee}
                onClickAction={handleOnClickActionEmployee}
                isLoading={isLoading}
                questionFilter={isLevel1}
              />
            ) : null}
          </div>
          <div className="mt-4">
            {requireSpouse && spouse ? (
              <Applicant
                applicant={spouse}
                buttonVariant={getApplicantButtonVariant(SPOUSE)}
                disableRemove={isKnownUser}
                onClickRemove={handleOnClickRemoveSpouse}
                onClickAction={handleOnClickActionSpouse}
                isLoading={isLoading}
              />
            ) : null}
          </div>
          {requireChildren &&
            children?.map((c, i) => (
              <div key={`applicant-child-${i}-div`} className="mt-4">
                <Applicant
                  key={`applicant-child-${i}`}
                  applicant={c}
                  buttonVariant={getApplicantButtonVariant(CHILD, i)}
                  disableRemove={isKnownUser}
                  onClickRemove={() => handleOnClickRemoveChild(c)}
                  onClickAction={() => handleOnClickActionChild(c)}
                  isLoading={isLoading}
                />
              </div>
            ))}
        </div>
      </div>
      {!isKnownUser && (
        <div>
          <div className="mt-16">
            <Divider />
            <div className="mt-3">
              {!isKnownUser && !spouse?.firstName && (
                <Link onClick={() => setShowAddSpouse(true)}>Add partner/spouse</Link>
              )}
            </div>
            <div className="mt-3">{!isKnownUser && <Link onClick={() => setShowAddChild(true)}>Add child</Link>}</div>
          </div>
          <PartnerSpouseDrawer showDrawer={showAddSpouse} onClose={() => setShowAddSpouse(false)} />
          <ChildDrawer showDrawer={showAddChild} onClose={() => setShowAddChild(false)} />
        </div>
      )}
      <AcknowledgementDrawer
        show={showAcknowledgement}
        applicants={getApplicants()}
        applicantNames={getApplicantNames()}
        onClickPrimaryAction={handleOnSubmitApplication}
        onClickSecondaryAction={() => setShowAcknowledgement(false)}
      />
    </>
  )
}

export default DashboardLanding
