import { DATE_OF_BIRTH } from '@/common/enums/regex'
import { isLevel1, isQuestionAffirmative } from '@/common/enums/usageCode'
import { fetchLocations } from '@/common/utils/api'
import { useApplicants } from '@/components/context/Applicants.context'
import { ApplicantDrawer } from '@/components/dashboard/applicantDrawer'
import { getApplicantQuestions, parseForVariables } from '@/components/healthHistoryQuestions/steps/util'
import { Button, Link, Notification } from '@/components/helios-components'
import { isEmpty } from 'lodash'
import moment from 'moment'
import { useEffect, useState } from 'react'
import { FollowUpQuestionDrawer } from '../followUpQuestions/followUpQuestionDrawer'
import { buildFollowUpStepConfigs } from '../followUpQuestions/steps'
import { HealthHistoryDrawer } from '../healthHistoryQuestions/healthHistoryDrawer'
import { Bold } from '../healthHistoryQuestions/steps/util'
import States from '../unitedStates'
import Applicant from './applicant'
import styles from './dashboardApplicant.module.css'
import Questionnaire from './Questionnaire'

function DashboardApplicant({ applicant, situsState, handleActionSecondary }) {
  const [showHealthHistoryDrawer, setShowHealthHistoryDrawer] = useState(false)
  const [showFollowUpSection, setShowFollowUpSection] = useState(false)
  const [location, setLocation] = useState()
  const [showApplicantDrawer, setShowApplicantDrawer] = useState(false)
  const [followUpStepConfigs, setFollowUpStepConfigs] = useState([])
  const [activeFollowUpStepConfig, setActiveFollowUpStepConfig] = useState({})

  const applicants = useApplicants()

  const {
    firstName,
    lastName,
    dateOfBirth,
    email,
    occupation,
    heightFeet,
    heightInches,
    phone,
    state,
    weight,
    street,
    city,
    zip,
    locationCode,
    genderCode,
  } = applicant || {}

  const height = heightFeet ? (
    <>
      {heightFeet}&apos; {heightInches}&quot;
    </>
  ) : (
    ''
  )
  const weightLbs = weight ? <>{weight}lb</> : ''
  const gender = genderCode === 'M' ? 'Male' : 'Female'
  const dobFormated = DATE_OF_BIRTH.MM_DD_YYYY.convert(dateOfBirth)
  const address = (
    <>
      {street},<br />
      {city}, {state}, {zip}
    </>
  )
  const workState = <>{States.find((s) => s.value === situsState)?.label}</>

  const LabelData = ({ label, data, showBackground = true }) => {
    const isEmpty = showBackground && !data
    return (
      <div className={`${styles.labelData} ${isEmpty ? styles.emptyData : ''}`}>
        <div className={`${isEmpty ? '' : 'text-gray-500'}`}>{label}</div>
        <div>{data}</div>
      </div>
    )
  }

  useEffect(() => {
    const getLocations = async () => {
      const currentLocations = await fetchLocations()
      const currentLocation = currentLocations.find((l) => l.value === locationCode?.trim())
      setLocation(currentLocation?.label)
    }
    getLocations()
  }, [locationCode])

  useEffect(() => {
    checkShowFollowUps()
  }, [])

  const checkShowFollowUps = () => {
    const nameVariables = { name: applicant.firstName, firstname: applicant.firstName }

    const applicantQuestions = getApplicantQuestions(applicant, applicants)

    // Temporary array to filter questions to only display currently implemented follow ups
    const requirementOptionCodesToFilter = ['LungRespDisord', 'Medications', 'HeartConditions']

    const affirmativeQuestions = applicantQuestions
      .filter(isLevel1)
      .filter(isQuestionAffirmative)
      .filter(({ requirementOptionCd: code }) => requirementOptionCodesToFilter.includes(code))
      .map((question) => {
        const substitutedOptionName = question.optionName ? parseForVariables(question.optionName, nameVariables) : null

        return { ...question, optionName: substitutedOptionName }
      })

    const followUpStepConfigs = buildFollowUpStepConfigs(affirmativeQuestions)

    if (affirmativeQuestions?.length > 0) {
      setShowFollowUpSection(true)
      setFollowUpStepConfigs(followUpStepConfigs)
    } else {
      setShowFollowUpSection(false)
    }
  }

  const handleHealthHistoryDrawerClose = () => {
    checkShowFollowUps()
    setShowHealthHistoryDrawer(false)
  }

  const handleDirectToHealthHistoryDrawer = () => {
    setShowHealthHistoryDrawer(true)
    setActiveFollowUpStepConfig({})
  }

  const isNullOrBlank = (value) => value === null || value === '' || value === undefined

  const formatDate = (dateString) => {
    return moment(dateString).format('MMM Do, YYYY')
  }

  const showFollowUpDrawer = !isEmpty(activeFollowUpStepConfig)

  return (
    <div className="mb-20">
      <div className="mb-4">
        <Notification
          actions={{
            onClick: () => {},
            text: 'Next step: Start health history questionnaire',
          }}
          closeLabel="Close"
          onClose={() => {}}
          variant="info">
          <>We&apos;ve updated personal information about {firstName} based on what you told us.</>
        </Notification>
      </div>
      <div className="flex justify-between">
        <div>
          <Link icon="chevron-left" iconPosition="before" showIcon inline onClick={handleActionSecondary}>
            Back to EOI dashboard
          </Link>
        </div>
        <div>Last Updated {formatDate(applicant.lastUpdatedDate)}</div>
      </div>
      {applicant?.type?.code === 'EMPLOYEE' && (
        <div className="grid grid-cols-4 gap-4 my-4">
          <div className="grid grid-cols-subgrid gap-4 col-span-3">
            <div className="col-start-1">
              <h1>
                {firstName}&nbsp;{lastName}
              </h1>
            </div>
          </div>
          <div className="content-center">
            <Link onClick={() => setShowApplicantDrawer(true)}>Edit</Link>
          </div>
          <LabelData label="Date of birth" data={dobFormated} />
          <LabelData label="Email" data={email} />
          <div className="grid grid-cols-subgrid gap-4 col-span-2">
            <LabelData label="Occupation" data={occupation} />
          </div>
          <LabelData label="Height" data={height} />
          <LabelData label="Phone" data={phone} />
          <div className="grid grid-cols-subgrid gap-4 col-span-2">
            <LabelData label="Work state" data={workState} />
          </div>
          <LabelData label="Weight" data={weightLbs} />
          <LabelData label="Address" data={address} />
          <div className="grid grid-cols-subgrid gap-4 col-span-2">
            <LabelData label="Location" data={location} showBackground={false} />
          </div>
          <LabelData label="Sex at birth" data={gender} />
        </div>
      )}
      {applicant?.type?.code === 'SPOUSE' && (
        <div className="grid grid-cols-4 gap-4 my-4">
          <div className="grid grid-cols-subgrid gap-4 col-span-3">
            <div className="col-start-1">
              <h1>
                {firstName}&nbsp;{lastName}
              </h1>
            </div>
          </div>
          <div className="content-center">
            {isNullOrBlank(heightFeet) || isNullOrBlank(heightInches) || isNullOrBlank(weight) ? (
              <Button onClick={() => setShowApplicantDrawer(true)}>Continue</Button>
            ) : (
              <Link onClick={() => setShowApplicantDrawer(true)}>Edit</Link>
            )}
          </div>
          <LabelData label="Date of birth" data={dobFormated} />
          <div className="grid grid-cols-subgrid gap-4 col-span-3">
            <LabelData label="Email" data={email} showBackground={false} />
          </div>
          <div className="grid grid-cols-subgrid gap-4 col-span-4">
            <LabelData label="Sex at birth" data={gender} />
          </div>
          <div className="grid grid-cols-subgrid gap-4 col-span-4">
            <LabelData label="Height" data={height} />
          </div>
          <div className="grid grid-cols-subgrid gap-4 col-span-4">
            <LabelData label="Weight" data={weightLbs} />
          </div>
        </div>
      )}
      {applicant?.type?.code === 'CHILD' && (
        <div className="grid grid-cols-4 gap-4 my-4">
          <div className="grid grid-cols-subgrid gap-4 col-span-3">
            <div className="col-start-1">
              <h1>
                {firstName}&nbsp;{lastName}
              </h1>
            </div>
          </div>
          <div className="content-center">
            <Link onClick={() => setShowApplicantDrawer(true)}>Edit</Link>
          </div>
          <LabelData label="Date of birth" data={dobFormated} />
          <div className="grid grid-cols-subgrid gap-4 col-span-4">
            <LabelData label="Sex at birth" data={gender} />
          </div>
          <div className="grid grid-cols-subgrid gap-4 col-span-4">
            <LabelData label="Height" data={height} />
          </div>
          <div className="grid grid-cols-subgrid gap-4 col-span-4">
            <LabelData label="Weight" data={weightLbs} />
          </div>
        </div>
      )}
      <hr className="mb-4" aria-hidden={true} />
      <div className="mb-20">
        <div className="max-w-3xl">
          <div className="mb-2">
            <span style={{ fontSize: '1.5rem' }}>Health history</span>
          </div>
          <div className="mb-4">
            <span>
              We need to ask some questions about health history, and you&apos;ll need information about conditions,
              missed work, primary physician, and medications to answer. Select <Bold>Start</Bold> to begin.
            </span>
          </div>
          <div className="mb-4">
            <Bold>Please note</Bold>: There may be follow-up questions to help determine eligibility.
          </div>
        </div>
        <Applicant
          applicant={applicant}
          label={<div style={{ fontSize: '1.25rem' }}>Health history questionnaire</div>}
          buttonVariant="primary"
          disableRemove
          onClickAction={() => setShowHealthHistoryDrawer(true)}
          questionFilter={isLevel1}
        />
      </div>
      {showFollowUpSection && (
        <div>
          <div className="max-w-3xl">
            <div className="mb-2">
              <span style={{ fontSize: '1.5rem' }}>Health history follow up questions</span>
            </div>
            <div className="mb-4">
              <span>
                Based on your answers in the health history questionnaire, we have some additional questions that will
                help us make a decision. We&apos;ll need information about the specific conditions, such as medications,
                physicians, and test results. Please select <Bold>Start</Bold>
              </span>
            </div>
          </div>
          {followUpStepConfigs.map((followUpConfig, index) => {
            return (
              <div className="mb-4" key={`level-1-affirmative-questions-${index}`}>
                <Questionnaire
                  applicant={applicant}
                  label={<div style={{ fontSize: '1.25rem' }}>{followUpConfig.name}</div>}
                  buttonVariant="secondary"
                  disableRemove
                  onClickAction={() => setActiveFollowUpStepConfig(followUpConfig)}
                />
              </div>
            )
          })}
          {showFollowUpDrawer && (
            <FollowUpQuestionDrawer
              applicant={applicant}
              steps={activeFollowUpStepConfig.steps}
              showDrawer={showFollowUpDrawer}
              onClose={() => setActiveFollowUpStepConfig({})}
              onShowHealthHistoryDrawer={handleDirectToHealthHistoryDrawer}
            />
          )}
        </div>
      )}
      <HealthHistoryDrawer
        applicant={applicant}
        showDrawer={showHealthHistoryDrawer}
        onClose={handleHealthHistoryDrawerClose}
      />
      <ApplicantDrawer
        applicant={applicant}
        showDrawer={showApplicantDrawer}
        onClose={() => setShowApplicantDrawer(false)}
      />
    </div>
  )
}

export default DashboardApplicant
