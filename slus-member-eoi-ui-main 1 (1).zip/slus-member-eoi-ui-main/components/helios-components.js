import dynamic from 'next/dynamic'

const Button = dynamic(() => import('@sunlife/slus-helios-components').then((mod) => mod.Button))
const Header = dynamic(() => import('@sunlife/slus-helios-components').then((mod) => mod.Header))
const Divider = dynamic(() => import('@sunlife/slus-helios-components').then((mod) => mod.Divider))
const Footer = dynamic(() => import('@sunlife/slus-helios-components').then((mod) => mod.Footer))
const Banner = dynamic(() => import('@sunlife/slus-helios-components').then((mod) => mod.Banner))
const Checkbox = dynamic(() => import('@sunlife/slus-helios-components').then((mod) => mod.Checkbox))
const HelperText = dynamic(() => import('@sunlife/slus-helios-components').then((mod) => mod.HelperText))
const InputGroup = dynamic(() => import('@sunlife/slus-helios-components').then((mod) => mod.InputGroup))
const Modal = dynamic(() => import('@sunlife/slus-helios-components').then((mod) => mod.Modal))
const ModalBody = dynamic(() => import('@sunlife/slus-helios-components').then((mod) => mod.Modal.Body))
const ModalFooter = dynamic(() => import('@sunlife/slus-helios-components').then((mod) => mod.Modal.Footer))
const Link = dynamic(() => import('@sunlife/slus-helios-components').then((mod) => mod.Link))
const Accordion = dynamic(() => import('@sunlife/slus-helios-components').then((mod) => mod.Accordion))
const Toasts = dynamic(() => import('@sunlife/slus-helios-components').then((mod) => mod.Toasts))
const TextField = dynamic(() => import('@sunlife/slus-helios-components').then((mod) => mod.TextField))
const Radio = dynamic(() => import('@sunlife/slus-helios-components').then((mod) => mod.Radio))
const Drawer = dynamic(() => import('@sunlife/slus-helios-components').then((mod) => mod.Drawer))
const GuidedExperience = dynamic(() => import('@sunlife/slus-helios-components').then((mod) => mod.GuidedExperience))
const Progress = dynamic(() => import('@sunlife/slus-helios-components').then((mod) => mod.Progress))
const Notification = dynamic(() => import('@sunlife/slus-helios-components').then((mod) => mod.Notification))
const Dropdown = dynamic(() => import('@sunlife/slus-helios-components').then((mod) => mod.Dropdown))
const Icon = dynamic(() => import('@sunlife/slus-helios-components').then((mod) => mod.Icon))
const DatePicker = dynamic(() => import('@sunlife/slus-helios-components').then((mod) => mod.DatePicker))

export {
  Button,
  Header,
  Divider,
  Footer,
  Banner,
  Checkbox,
  HelperText,
  InputGroup,
  Modal,
  ModalBody,
  ModalFooter,
  Link,
  Accordion,
  Toasts,
  TextField,
  Radio,
  Drawer,
  GuidedExperience,
  Progress,
  Notification,
  Dropdown,
  Icon,
  DatePicker,
}
