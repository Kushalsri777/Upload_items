import { useState, useEffect } from 'react'
import { Container } from 'react-bootstrap'
import { Footer as HeliosFooter } from '@/components/helios-components'
import { FOOTER } from '@/common/utils/pageText'

const { componentContentInfo, contactInfo } = FOOTER

function Footer({ disableContactInfo }) {
  const [contentObj, setContentObj] = useState()
  const [menus, setMenus] = useState()
  const [languageObj, setLanguageObj] = useState()
  const [utilityMenuObj, setUtilityMenuObj] = useState()

  useEffect(() => {
    setContentObj(componentContentInfo)
    setMenus(null)
    setLanguageObj(null)

    setUtilityMenuObj({
      items: [
        {
          href: 'https://www.sunlife.com/sl/pslf-united-states/en/legal/',
          target: '_blank',
          title: 'Legal',
        },
        {
          href: 'https://www.sunlife.com/sl/pslf-united-states/en/privacy/',
          target: '_blank',
          title: 'Privacy',
        },
        {
          href: 'https://www.sunlife.com/sl/pslf-united-states/en/security/',
          target: '_blank',
          title: 'Security',
        },
        {
          href: 'https://www.sunlife.com/us/en/sitemap/',
          target: '_blank',
          title: 'Site map',
        },
      ],
      siteTag: 'SLF',
    })
  }, [])

  return (
    <>
      <Container>
        {disableContactInfo ? null : (
          <>
            <hr className="my-8" aria-hidden={true} />
            {contactInfo.map((line) => line)}
          </>
        )}
      </Container>
      <HeliosFooter content={contentObj} menus={menus} language={languageObj} utilityMenu={utilityMenuObj} />
    </>
  )
}

export default Footer
