import { useContext, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { AppContext } from '@/components/context/app.context'

/**
 * This component is used as HOC to check if the User has a valid session and check that User after completing an Applicant
 * can't go back to the Review Page or any other page related to the Applicant Information flow.
 * @param Component
 * @returns {(function(*): (null|*))|*}
 */
function WithAuth(Component) {
  return function IsAuth(props) {
    const router = useRouter()
    const { timeoutInfo, applicantCompletionStatus, clearTimeouts } = useContext(AppContext)

    useEffect(() => {
      ;(async () => {
        if (!timeoutInfo.isUserLogged) {
          await router.push('/')
        }
      })()
    }, [applicantCompletionStatus, router, timeoutInfo.isUserLogged])

    useEffect(() => {
      const handleRouteChange = (url) => {
        if (
          (applicantCompletionStatus === 'NOT_STARTED' || applicantCompletionStatus === 'COMPLETED') &&
          (url === '/demographics' || url === '/history' || url === '/review')
        ) {
          router.push('/dashboard')
          return false
        }

        if (url === '/submitted') {
          clearTimeouts(true, false)
          router.push('/')
          return false
        }

        return true
      }

      const handlePopState = (event) => {
        const url = event.state?.as
        handleRouteChange(url)
      }

      window.addEventListener('popstate', handlePopState)

      return () => {
        window.removeEventListener('popstate', handlePopState)
      }
    }, [applicantCompletionStatus, router, timeoutInfo.isUserLogged])

    if (
      !timeoutInfo.isUserLogged ||
      (applicantCompletionStatus === 'COMPLETED' &&
        (router.asPath === '/demographics' || router.asPath === '/history' || router.asPath === '/review'))
    ) {
      return null
    }

    return <Component {...props} />
  }
}

export default WithAuth
