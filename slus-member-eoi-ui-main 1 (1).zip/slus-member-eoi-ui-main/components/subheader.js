import Col from 'react-bootstrap/Col'
import Container from 'react-bootstrap/Container'
import Row from 'react-bootstrap/Row'
import { Divider } from '@/components/helios-components'
import styles from './subheader.module.css'

function SubHeader({
  applicant = '--',
  relationship = 'Employee',
  policyholder = 'Unknown',
  stepIndex = '1',
  stepCount = '1',
}) {
  return (
    <>
      <Container>
        <Row className={styles.row}>
          <Col xs={8} className={styles.item1}>
            <div>
              <span className={styles.spanBlock} data-cy="subheader_applicant">
                Applicant: <span className="font-sunlifeBold">{applicant}</span> {`(${relationship})`}
              </span>
              <Divider className={styles.dividerV} orientation="vertical" size="md" />
              <span className={styles.spanBlock} data-cy="subheader_policyholder">
                Policyholder: <span className="font-sunlifeBold">{policyholder}</span>
              </span>
            </div>
          </Col>
          <Col xs={4} className={styles.item2}>
            <div className="font-sunlifeBold">
              <span className={styles.spanBlock}>
                <span data-cy="subheader_steps" className={styles.steps}>
                  Step {stepIndex} of {stepCount}
                </span>
              </span>
            </div>
          </Col>
        </Row>
      </Container>
      <Divider orientation="horizontal" size="sm" />
    </>
  )
}

export default SubHeader
