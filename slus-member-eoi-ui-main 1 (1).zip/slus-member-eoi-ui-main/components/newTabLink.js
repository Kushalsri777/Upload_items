import { useEffect, useState } from 'react'
import Link from 'next/link'
import { linkStyle as ls } from '@/common/utils/util'

function NewTabLink({ image, label, href, onClick, disabled = false }) {
  const [linkStyle, setLinkStyle] = useState(() => ls(disabled))

  useEffect(() => {
    setLinkStyle(() => ls(disabled))
  }, [disabled])

  return (
    <>
      {!!href ? (
        <Link href={href} rel="noopener noreferrer" target="_blank">
          <div className={linkStyle}>
            {image}
            {label}
          </div>
        </Link>
      ) : (
        <div className={linkStyle} onClick={onClick}>
          {image}
          {label}
        </div>
      )}
    </>
  )
}

export default NewTabLink
