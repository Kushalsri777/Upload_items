function PageLink({ image, label, onClick }) {
  return (
    <div
      className="flex items-center font-bold font-sunlifeBold no-underline cursor-pointer text-[#00588B]"
      onClick={onClick}>
      {image}
      {label}
    </div>
  )
}

export default PageLink
