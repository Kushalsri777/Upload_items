import { useContext, useEffect, useId } from 'react'
import { FormProvider, useForm } from 'react-hook-form'
import { StepHandlerContext } from '@/components/context/StepHandler.context'
import { useApplicantsDispatcher } from '../context/Applicants.context'
import { ONBOARDING_PARTER_SPOUSE_STEP } from '@/common/utils/pageText'
import { PartnerSpouseForm } from '@/components/onboarding/partnerSpouseForm'
import { savePartner } from '@/common/utils/api'

const {
  body: { values: displayTextValues },
} = ONBOARDING_PARTER_SPOUSE_STEP

const defaultApplicantValues = {
  firstName: '',
  lastName: '',
  genderCode: '',
  dateOfBirth: '',
  email: '',
}

const PartnerSpouse = () => {
  const methods = useForm({
    mode: 'onTouched',
    defaultValues: defaultApplicantValues,
  })
  const { trigger, getValues, setValue } = methods
  const { setStepHandler } = useContext(StepHandlerContext)
  const { updateSpouse } = useApplicantsDispatcher()

  const id = useId()

  useEffect(() => {
    const onClickNext = async () => {
      const isValid = await trigger()
      if (isValid) {
        const values = getValues()
        const response = await savePartner(values)
        if (response.ok) {
          const updated = await response.json()
          updateSpouse({
            ...values,
            status: updated.processStatus,
            lastUpdatedDate: updated.lastUpdatedDate,
          })
        }
        return response.ok
      }
      return false
    }
    setStepHandler({ onClickNext })
  }, [])

  return (
    <div className="w-full">
      <FormProvider {...methods}>
        {displayTextValues.map((displayText, i) => (
          <div className="mb-4" key={`display-text-${id}-${i}`}>
            {displayText}
          </div>
        ))}
        <PartnerSpouseForm />
      </FormProvider>
    </div>
  )
}

export default PartnerSpouse
