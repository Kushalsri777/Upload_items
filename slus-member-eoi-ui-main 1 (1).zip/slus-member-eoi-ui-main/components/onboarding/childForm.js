import Fullname from '@/components/personal/fullname'
import Gender from '@/components/personal/gender'
import DateOfBirth from '@/components/personal/dateOfBirth'
import { FormProvider, useForm } from 'react-hook-form'
import { Button } from '@/components/helios-components'
import { useEffect } from 'react'

const nameControls = [
  { label: 'First name', controllerName: 'firstName' },
  { label: 'Last name', controllerName: 'lastName' },
]

const defaultApplicantValues = {
  firstName: '',
  lastName: '',
  genderCode: '',
  dateOfBirth: '',
}

export function ChildForm({ item, index, onEdit, onCancel }) {
  const methods = useForm({
    mode: 'onTouched',
    defaultValues: defaultApplicantValues,
  })

  useEffect(() => {
    methods.setValue('firstName', item.firstName)
    methods.setValue('lastName', item.lastName)
    methods.setValue('genderCode', item.genderCode)
    methods.setValue('dateOfBirth', item.dateOfBirth)
  }, [item, methods])

  const handleEdit = async () => {
    const isValid = await methods.trigger()

    if (isValid) {
      const formData = methods.getValues()
      onEdit(index, {
        firstName: formData.firstName,
        lastName: formData.lastName,
        genderCode: formData.genderCode,
        dateOfBirth: formData.dateOfBirth,
      })
    }
  }

  return (
    <div className="w-full max-w-sm">
      <FormProvider {...methods}>
        <Fullname controls={nameControls} validatePlaceholder={true} />
        <Gender />
        <DateOfBirth />
        <div className="hstack gap-2">
          <Button onClick={onCancel} variant="secondary">
            Cancel
          </Button>
          <Button onClick={handleEdit} variant="primary">
            Save
          </Button>
        </div>
      </FormProvider>
    </div>
  )
}
