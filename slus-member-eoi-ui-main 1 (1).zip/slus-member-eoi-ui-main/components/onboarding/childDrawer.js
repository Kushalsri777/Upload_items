import { Drawer } from '@/components/helios-components'
import Fullname from '@/components/personal/fullname'
import Gender from '@/components/personal/gender'
import DateOfBirth from '@/components/personal/dateOfBirth'
import { FormProvider, useForm } from 'react-hook-form'
import { useApplicants, useApplicantsDispatcher } from '@/components/context/Applicants.context'
import { useRequiredApplicantsDispatcher } from '../context/RequiredApplicants.context'
import { addChild, getHealthQuestionsForApplicant } from '@/common/utils/api'

const nameControls = [
  { label: 'First name', controllerName: 'firstName' },
  { label: 'Last name', controllerName: 'lastName' },
]

const defaultApplicantValues = {
  firstName: '',
  lastName: '',
  genderCode: '',
  dateOfBirth: '',
}

export function ChildDrawer({ onClose, showDrawer }) {
  const methods = useForm({
    mode: 'onTouched',
    defaultValues: defaultApplicantValues,
  })
  const { trigger, getValues } = methods
  const { updateChildren } = useApplicantsDispatcher()
  const { children } = useApplicants()
  const { setChildrenRequired } = useRequiredApplicantsDispatcher()

  const handleSaveChild = async () => {
    const isValid = await trigger()
    if (isValid) {
      const values = getValues()
      const response = await addChild(values)
      if (response.ok) {
        const responseBody = await response.json()
        values.seqNum = responseBody.seqNum
        values.status = responseBody.processStatus
        values.lastUpdatedDate = responseBody.lastUpdatedDate
        values.acknowledgements = {
          fraudWarning: false,
          hipaaAuth: false,
        }
        values.questions = await getHealthQuestionsForApplicant('CHILD', values.seqNum)
        updateChildren([...children, values])
        methods.reset(defaultApplicantValues)
        setChildrenRequired(true)
        onClose()
      }
    }
  }

  const handleExit = () => {
    methods.reset(defaultApplicantValues)
    onClose()
  }

  return (
    <Drawer
      actions={[
        {
          children: 'Save',
          id: '1',
          variant: 'primary',
          onClick: handleSaveChild,
        },
      ]}
      aria-describedby="drawer-drawer-body"
      closeLabel="Close"
      heading="Child applicants"
      id="drawerChild"
      onExit={handleExit}
      onExited={handleExit}
      size="medium"
      show={showDrawer}>
      <div className="w-full max-w-sm">
        <FormProvider {...methods}>
          <div className="fs-3 mb-4">Let&apos;s setup their application</div>
          <div className="mt-3">All fields are required unless labeled optional.</div>
          <div className="mt-3 mb-3">
            If you make any mistakes here, you&apos;ll be able to make changes on their applicant page.
          </div>
          <Fullname controls={nameControls} validatePlaceholder={true} />
          <Gender />
          <DateOfBirth />
        </FormProvider>
      </div>
    </Drawer>
  )
}
