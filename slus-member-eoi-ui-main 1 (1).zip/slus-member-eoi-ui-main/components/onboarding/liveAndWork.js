import { useContext, useEffect } from 'react'
import { FormProvider, useForm } from 'react-hook-form'
import Address from '@/components/address'
import Occupation from '@/components/occupation'
import Contact from '@/components/contact'
import { StepHandlerContext } from '@/components/context/StepHandler.context'
import { useApplicants, useApplicantsDispatcher } from '../context/Applicants.context'

const addressControls = {
  street: { label: 'Street address', controllerName: 'street' },
  city: { label: 'City', controllerName: 'city' },
  usState: { label: 'State', controllerName: 'state' },
  zip: { label: 'Zip code', controllerName: 'zip' },
}

const defaultApplicantValues = {
  street: '',
  city: '',
  state: '',
  zip: '',
  applicant: {
    employeeEmailAddress: '',
    confirmEmail: '',
    employeeWorkPhoneNumber: '',
    employeeOccupation: '',
    locationCode: '',
  },
}

function LiveAndWork() {
  const methods = useForm({
    mode: 'onTouched',
    defaultValues: defaultApplicantValues,
  })
  const { setValue, trigger, getValues } = methods
  const { setStepHandler } = useContext(StepHandlerContext)
  const { employee } = useApplicants()
  const { updateEmployee } = useApplicantsDispatcher()

  useEffect(() => {
    const { street, city, state, zip, email, emailConfirm, phone, occupation, locationCode } = employee || {}

    setValue('street', street || '')
    setValue('city', city || '')
    setValue('state', state || '')
    setValue('zip', zip || '')
    setValue('applicant.employeeEmailAddress', email || '')
    setValue('applicant.confirmEmail', emailConfirm || '')
    setValue('applicant.employeeWorkPhoneNumber', phone || '')
    setValue('applicant.employeeOccupation', occupation || '')
    setValue('applicant.locationCode', locationCode || '')
  }, [employee])

  useEffect(() => {
    const onClickNext = async () => {
      const isValid = await trigger()
      if (isValid) {
        const values = getValues()
        updateEmployee({
          ...values,
          email: values.applicant.employeeEmailAddress,
          emailConfirm: values.applicant.confirmEmail,
          phone: values.applicant.employeeWorkPhoneNumber,
          occupation: values.applicant.employeeOccupation,
          locationCode: values.applicant.locationCode,
        })
        const url = `${process.env.NEXT_PUBLIC_BASE_URL}/applicants/liveAndWork`
        const response = await fetch(url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            streetAddress: values.street,
            city: values.city,
            state: values.state,
            zipCode: values.zip,
            email: values.applicant.employeeEmailAddress,
            phoneNumber: values.applicant.employeeWorkPhoneNumber,
            occupation: values.applicant.employeeOccupation,
            location: values.applicant.locationCode,
          }),
        })
        return response.ok
      }
      return isValid
    }
    setStepHandler({ onClickNext })
  }, [])

  return (
    <div className="w-full max-w-sm">
      <FormProvider {...methods}>
        <div className="mb-4">All fields are required unless labeled optional.</div>
        <Address controls={addressControls} />
        <Contact />
        <Occupation />
      </FormProvider>
    </div>
  )
}

export default LiveAndWork
