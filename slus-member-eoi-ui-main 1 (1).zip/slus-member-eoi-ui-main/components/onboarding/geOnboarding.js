'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import _ from 'lodash'
import styles from './geOnboarding.module.css'
import { useRequiredApplicants } from '@/components/context/RequiredApplicants.context'
import { useLegacyApplicationDispatcher } from '@/components/context/LegacyApplication.context'
import { useApplicants } from '@/components/context/Applicants.context'
import { useContinuance, useContinuanceDispatcher } from '@/components/context/Continuance.context'
import { GuidedExperience, Progress, Notification } from '@/components/helios-components'
import { COMPLETED, STARTED } from '@/common/enums/guidedExperienceStepStatus'
import { StepHandlerContext } from '@/components/context/StepHandler.context'
import { DASHBOARD, ONBOARDING } from '@/common/enums/applicationContinuanceLocation'
import { KNOWN_USER_STEPS, UNKNOWN_USER_STEPS } from '@/common/enums/onboardingUserSteps'
import { NOT_STARTED } from '@/common/enums/applicationStatusCode'

const GE_Onboarding = () => {
  const router = useRouter()
  const requiredApplicants = useRequiredApplicants()
  const { deleteTimeoutInfo } = useLegacyApplicationDispatcher()
  const { isKnownUser } = useApplicants()

  const { currentStepIndex, isUserInProgress, isFinishedOnboarding } = useContinuance()

  const { updateAppLocation, updateIsUserInProgress, deleteAppLocationId, updateCurrentStepIndex } =
    useContinuanceDispatcher()

  const [stepHandler, setStepHandler] = useState({ onClickNext: async () => true })
  const [activeStepIndex, setActiveStepIndex] = useState(0)
  const [steps, setSteps] = useState([])
  const [isDashboardLoading, setIsDashboardLoading] = useState(false)
  const [isInitialLoading, setIsInitialLoading] = useState(true)
  const [isShowNotification, setIsShowNotification] = useState(false)

  const handleOnClickNext = async () => {
    const isValid = await stepHandler.onClickNext()
    if (isValid) {
      // turn off the notification if it is currently displayed
      setIsShowNotification(false)

      // make a copy of original steps
      let workingSteps = _.cloneDeep(isKnownUser ? KNOWN_USER_STEPS : UNKNOWN_USER_STEPS)

      // add/remove steps based on context changes (eg. applicants page (only unknown affected))
      workingSteps = workingSteps.filter((s) => s.isStepRequired(requiredApplicants))

      // persist the statuses from the steps in current state
      workingSteps = workingSteps.map((s) => {
        const currentStepInState = steps.find((x) => x.id === s.id)

        // if you added a step (spouse or child), state may not have a current status set, use original status
        const currentStepStatus = currentStepInState?.status || s.status
        return {
          ...s,
          status: currentStepStatus,
        }
      })

      // set the current step index as completed
      workingSteps[activeStepIndex].status = COMPLETED
      setSteps(workingSteps)

      // calculate the next step index, be sure not to exceed the new workingSteps array length
      const nextStepIndex = Math.min(workingSteps.length - 1, activeStepIndex + 1)

      // set the next step index as the active step
      setActiveStepIndex(nextStepIndex)
      updateCurrentStepIndex(nextStepIndex) // context

      // nextStepIndex and activeStepIndex are the same, this means we are done and should route to the dashboard page
      if (nextStepIndex === activeStepIndex) {
        routeToDashboard()
        updateIsUserInProgress(false)
        updateAppLocation(DASHBOARD)
        deleteAppLocationId()
      }
    }
  }

  const handleOnClickPrevious = async () => {
    if (activeStepIndex === 0) {
      updateIsUserInProgress(false)
      await logOut()
    } else {
      setIsShowNotification(false)
      setActiveStepIndex(Math.max(0, activeStepIndex - 1)) // Don't go below 0
    }
  }

  const handleOnClickStep = (stepIdCurrent, stepIdClicked) => {
    console.log(`stepIdCurrent: ${stepIdCurrent}, stepIdClicked: ${stepIdClicked}`)
    setActiveStepIndex(stepIdClicked)
  }

  const logOut = async () => {
    deleteTimeoutInfo({
      shouldClearLoggedUser: true,
      displayTimeoutToast: false,
    })
    await router.push('/login')
  }

  const routeToDashboard = (timeout = 2000) => {
    setIsDashboardLoading(true)
    setTimeout(() => {
      setIsDashboardLoading(false)
      router.push('/dashboard')
    }, timeout)
  }

  useEffect(() => {
    if (isFinishedOnboarding) {
      routeToDashboard(0)
    }

    if (isUserInProgress) {
      setActiveStepIndex(currentStepIndex)
      setIsShowNotification(currentStepIndex > 0)
    } else {
      updateIsUserInProgress(true)
      updateAppLocation(ONBOARDING)
      updateCurrentStepIndex(0)
    }

    const clonedUserSteps = _.cloneDeep(isKnownUser ? KNOWN_USER_STEPS : UNKNOWN_USER_STEPS)
    const filteredSteps = clonedUserSteps.filter((s) => s.isStepRequired(requiredApplicants))

    const stepIndex = currentStepIndex || 0
    const getStatus = (index) => {
      if (index < stepIndex) {
        return COMPLETED
      } else if (index === stepIndex) {
        return STARTED
      } else {
        return NOT_STARTED
      }
    }

    const updatedSteps = filteredSteps.map((s, i) => ({ ...s, status: getStatus(i) }))
    setSteps(updatedSteps)
    setIsInitialLoading(false)
  }, [])

  const LoadingScreen = ({ display = 'One moment, setting up your EOI application dashboard' }) => (
    <div className={styles.loading}>
      <div className={styles.loadingContent}>
        <div
          className="font-sunlifeNewDisplay text-white"
          style={{ width: '760px', textAlign: 'center', fontWeight: '400', lineHeight: '40px' }}>
          {display}
        </div>
        <Progress color="light" variant="indeterminate" className={styles.spinnerIcon} />
      </div>
    </div>
  )

  const NotificationDisplay = () => (
    <Notification
      variant="success"
      closeLabel="Close"
      onClose={() => setIsShowNotification(false)}
      heading="Welcome back to your EOI onboarding">
      <div>We&apos;ve saved the information from your last session so you can continue from where you left off.</div>
    </Notification>
  )

  return (
    <StepHandlerContext.Provider
      value={{
        stepHandler,
        setStepHandler,
      }}>
      {isInitialLoading && <LoadingScreen display="Loading" />}
      {isDashboardLoading && <LoadingScreen />}
      {isShowNotification && <NotificationDisplay />}
      <GuidedExperience
        action={{
          next: {
            children: activeStepIndex === steps.length - 1 ? 'Finish' : 'Next',
            show: true,
            variant: 'primary',
            onClick: handleOnClickNext,
          },
          previous: {
            children: 'Back',
            show: true,
            variant: 'secondary',
            onClick: handleOnClickPrevious,
          },
        }}
        activeStep={steps?.[activeStepIndex]?.id}
        heading={steps?.[activeStepIndex]?.heading}
        onStepClick={handleOnClickStep}
        showMenuLabel="Show step menu"
        steps={steps}>
        {steps?.[activeStepIndex]?.content ? steps[activeStepIndex].content : null}
      </GuidedExperience>
    </StepHandlerContext.Provider>
  )
}

export default GE_Onboarding
