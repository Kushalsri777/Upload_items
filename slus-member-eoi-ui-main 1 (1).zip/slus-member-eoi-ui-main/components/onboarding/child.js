import { useContext, useEffect, useState } from 'react'
import moment from 'moment'
import ListComponent from '@/components/listComponent/listComponent'
import { ChildForm } from '@/components/onboarding/childForm'
import { StepHandlerContext } from '@/components/context/StepHandler.context'
import { useApplicants, useApplicantsDispatcher } from '../context/Applicants.context'
import { saveChildren } from '@/common/utils/api'

const DATE_FORMAT = 'MM/DD/YYYY'

export function Child() {
  const { setStepHandler } = useContext(StepHandlerContext)
  const [isLoading, setIsLoading] = useState(true)
  const { children, isKnownUser } = useApplicants()
  const { updateChildren } = useApplicantsDispatcher()

  useEffect(() => {
    prepareChildren()
  }, [])

  useEffect(() => {
    setIsLoading(false)
    setStepHandler({ onClickNext })
  }, [children])

  const onClickNext = async () => {
    const allChildrenValid = children.every((child) => {
      const errorMessage = getErrorMessage(child)
      return errorMessage === null || errorMessage.length === 0
    })
    if (children.length > 0 && allChildrenValid) {
      const response = await saveChildren(children)
      if (response.ok) {
        const updatedChildren = await response.json()
        updateChildren(
          updatedChildren.map((child) => {
            return {
              seqNum: child.seqNum,
              firstName: child.firstName,
              lastName: child.lastName,
              genderCode: child.gender,
              dateOfBirth: child.dateOfBirth,
              status: child.processStatus,
              lastUpdatedDate: child.lastUpdatedDate,
              acknowledgements: {
                fraudWarning: false,
                hipaaAuth: false,
              },
            }
          }),
        )
      }
      return response.ok
    }
    return false
  }

  const getGenderDescription = (code) => {
    switch (code) {
      case 'M':
        return 'Male at birth'
      case 'F':
        return 'Female at birth'
      default:
        return 'Sex at birth unknown'
    }
  }

  const getDateDescription = (dateString) => {
    if (!dateString) {
      return 'unknown'
    }
    return moment(dateString).format(DATE_FORMAT)
  }

  const getErrorMessage = (dependent) => {
    let missingFields = []
    if (!dependent.genderCode) {
      missingFields.push('Sex at birth')
    }
    if (!dependent.dateOfBirth) {
      missingFields.push('Date of birth (DOB)')
    }
    if (missingFields.length > 0) {
      return `Missing information: ${missingFields.join(' and ')}`
    }
    return null
  }

  const mapDependent = (child) => ({
    ...child,
    header: `${child.firstName} ${child.lastName}`,
    description: `${getGenderDescription(child.genderCode)}, DOB ${getDateDescription(child.dateOfBirth)}`,
    canRemove: !isKnownUser,
    errorMessage: getErrorMessage(child),
    dateOfBirth: child.dateOfBirth ? moment(child.dateOfBirth).format(DATE_FORMAT) : null,
  })

  const prepareChildren = () => {
    const childDependents = children?.map(mapDependent)
    updateChildren(childDependents)
  }

  const onItemUpdate = (items) => {
    setIsLoading(true)
    const newDependents = items?.map(mapDependent)
    updateChildren(newDependents)
  }

  const createNewItem = () => {
    return {
      header: '',
      description: '',
    }
  }

  if (isLoading) {
    return <div>Loading...</div>
  }

  const isViewOnly = isKnownUser

  return (
    <>
      <div className="mb-4">
        {isViewOnly && (
          <p>
            You&apos;ve asked to enroll your child{'{'}ren{'}'} for additional coverage. If this information is not
            accurate, contact your human resources department. If you make any mistakes here, you&apos;ll be able to
            make changes before you submit the application.
          </p>
        )}
        {!isViewOnly && (
          <>
            <p>
              You told us there are one or more child applicants on your Evidence of Insurability (EOl) application. We
              need to collect some basic information to get started. Please select <b>Add child</b> to begin.
            </p>
            <p>If you make any mistakes here, you&apos;ll be able to make changes before you submit the application.</p>
          </>
        )}
        <p>All fields are required.</p>
      </div>
      <ListComponent
        items={children}
        onItemsUpdate={onItemUpdate}
        createNewItem={createNewItem}
        canAdd={!isViewOnly}
        addLabel="Add child"
        newItemLabel="New child applicant">
        <ChildForm />
      </ListComponent>
    </>
  )
}
