import { useContext, useEffect, useState } from 'react'
import { FormProvider, useForm } from 'react-hook-form'
import { getLoginMethod, SSN } from '@/common/enums/loginMethod'
import Fullname from '@/components/personal/fullname'
import Gender from '@/components/personal/gender'
import Height from '@/components/personal/height'
import Weight from '@/components/personal/weight'
import DateOfBirth from '@/components/personal/dateOfBirth'
import Identifier from '@/components/personal/identifier'
import { StepHandlerContext } from '@/components/context/StepHandler.context'
import { useApplicants, useApplicantsDispatcher } from '../context/Applicants.context'
import { useLegacyApplication } from '../context/LegacyApplication.context'
import { useRequiredApplicants } from '../context/RequiredApplicants.context'
import { saveEmployee } from '@/common/utils/api'

const nameControls = [
  { label: 'First name', controllerName: 'firstName' },
  { label: 'Last name', controllerName: 'lastName' },
]

const defaultApplicantValues = {
  firstName: '',
  lastName: '',
  genderCode: '',
  heightFeet: '',
  heightInches: '',
  weight: '',
  dateOfBirth: '',
  identifier: '',
}

function EmployeeInformation() {
  const methods = useForm({
    mode: 'onTouched',
    defaultValues: defaultApplicantValues,
  })
  const { setValue, trigger, getValues } = methods
  const { setStepHandler } = useContext(StepHandlerContext)
  const { employee, isKnownUser } = useApplicants()
  const { updateEmployee } = useApplicantsDispatcher()
  const { loginMethod: contextLoginMethod, loginMethodValue } = useLegacyApplication()
  const { requireEmployee } = useRequiredApplicants()

  const [loginMethod, setLoginMethod] = useState(SSN)

  const isEmployeeSelected = () => {
    return requireEmployee
  }

  useEffect(() => {
    const { firstName, lastName, genderCode, heightFeet, heightInches, weight, dateOfBirth } = employee || {}

    setValue('firstName', firstName)
    setValue('lastName', lastName)
    setValue('genderCode', genderCode)
    setValue('heightFeet', heightFeet)
    setValue('heightInches', heightInches)
    setValue('weight', weight)
    setValue('dateOfBirth', dateOfBirth)
  }, [setValue, employee])

  useEffect(() => {
    // login ID type and value
    const loginMethod = getLoginMethod(contextLoginMethod)
    setLoginMethod(loginMethod)
    setValue('identifier', loginMethod.formatValue(loginMethodValue))
  }, [contextLoginMethod, loginMethodValue, setValue])

  useEffect(() => {
    const onClickNext = async () => {
      const isValid = await trigger()
      if (isValid) {
        const values = getValues()
        const response = await saveEmployee(values)
        if (response.ok) {
          const updated = await response.json()
          updateEmployee({
            ...values,
            status: updated.processStatus,
            lastUpdatedDate: updated.lastUpdatedDate,
          })
        }
        return response.ok
      }
      return false
    }
    setStepHandler({ onClickNext })
  }, [])

  return (
    <div className="w-full">
      <FormProvider {...methods}>
        <div className="mb-4" key="instruction-text">
          All fields are required unless labeled optional.
        </div>
        {!isKnownUser && (
          <div className="mb-4" key="instruction-text-">
            <span>
              If you make any mistakes here, you&apos;ll be able to make changes before you submit the application.
            </span>
          </div>
        )}
        {!isEmployeeSelected() && (
          <div className="mb-4" key="employee-not-selected-text">
            <span>
              <b className="font-sunlifeBold">Please note:&nbsp;</b>We need the employee&apos;s information to complete
              this application.
            </span>
          </div>
        )}
        <div className="max-w-sm">
          <Fullname controls={nameControls} isViewOnly={isKnownUser} />
          <Gender />
          <Height />
          <Weight />
          <DateOfBirth minAge={14} />
          <Identifier loginMethod={loginMethod} isViewOnly={true} />
        </div>
      </FormProvider>
    </div>
  )
}

export default EmployeeInformation
