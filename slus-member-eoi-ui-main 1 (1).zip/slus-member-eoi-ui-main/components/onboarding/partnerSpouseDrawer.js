import { Drawer } from '@/components/helios-components'
import { PartnerSpouseForm } from '@/components/onboarding/partnerSpouseForm'
import { FormProvider, useForm } from 'react-hook-form'
import { useApplicantsDispatcher } from '@/components/context/Applicants.context'
import { useRequiredApplicantsDispatcher } from '../context/RequiredApplicants.context'
import { getHealthQuestionsForApplicant, savePartner } from '@/common/utils/api'

const defaultApplicantValues = {
  firstName: '',
  lastName: '',
  genderCode: '',
  dateOfBirth: '',
  email: '',
}

export function PartnerSpouseDrawer({ onClose, showDrawer }) {
  const methods = useForm({
    mode: 'onTouched',
    defaultValues: defaultApplicantValues,
  })
  const { trigger, getValues } = methods
  const { updateSpouse } = useApplicantsDispatcher()
  const { setSpouseRequired } = useRequiredApplicantsDispatcher()

  const handleSaveSpouse = async () => {
    const isValid = await trigger()
    if (isValid) {
      const values = getValues()
      const response = await savePartner(values, true)
      if (response.ok) {
        const responseBody = await response.json()
        values.status = responseBody.processStatus
        values.lastUpdatedDate = responseBody.lastUpdatedDate
        values.acknowledgements = {
          fraudWarning: false,
          hipaaAuth: false,
        }
        values.questions = await getHealthQuestionsForApplicant('SPOUSE', 1)
        updateSpouse(values)
        setSpouseRequired(true)
        onClose()
      }
    }
  }

  const handleExit = () => {
    methods.reset(defaultApplicantValues)
    onClose()
  }

  return (
    <Drawer
      actions={[
        {
          children: 'Save',
          id: '1',
          variant: 'primary',
          onClick: handleSaveSpouse,
        },
      ]}
      aria-describedby="drawer-drawer-body"
      closeLabel="Close"
      heading="Partner/spouse"
      id="drawerSpouse"
      onExit={handleExit}
      onExited={handleExit}
      size="medium"
      show={showDrawer}>
      <FormProvider {...methods}>
        <div className="fs-3 mb-4">Let&apos;s setup their application</div>
        <div className="mt-3">All fields are required unless labeled optional.</div>
        <div className="mt-3 mb-3 col-md-7">
          If you make any mistakes here, you&apos;ll be able to make changes on their applicant page.
        </div>
        <PartnerSpouseForm showDetails={true} />
      </FormProvider>
    </Drawer>
  )
}
