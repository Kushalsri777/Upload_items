import { useContext, useEffect, useState } from 'react'
import { EMPLOYEE, SPOUSE, CHILD } from '@/common/enums/enroller'
import { Checkbox } from '@/components/helios-components'
import { useRequiredApplicants, useRequiredApplicantsDispatcher } from '@/components/context/RequiredApplicants.context'
import { StepHandlerContext } from '@/components/context/StepHandler.context'

const Applicants = () => {
  const { setStepHandler } = useContext(StepHandlerContext)
  const { toggleEmployeeRequired, toggleSpouseRequired, toggleChildrenRequired } = useRequiredApplicantsDispatcher()

  const { requireEmployee, requireSpouse, requireChildren } = useRequiredApplicants()

  const [isValidating, setIsValidating] = useState(false)

  const isValid = () => requireEmployee || requireSpouse || requireChildren
  useEffect(() => {
    const onClickNext = async () => {
      setIsValidating(true)
      if (isValid()) {
        const url = `${process.env.NEXT_PUBLIC_BASE_URL}/applicants/selection`
        const response = await fetch(url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            employee: requireEmployee || false,
            partner: requireSpouse || false,
            children: requireChildren || false,
          }),
        })
        return response.ok
      }
      return false
    }
    setStepHandler({ onClickNext })
  }, [setIsValidating, requireEmployee, requireSpouse, requireChildren])

  return (
    <div key="onboarding-landing-applicants">
      <div className="mb-4">
        <span className="font-sunlifeBold">Please note:</span>
        <span>&nbsp;We&apos;ll need information about the employee even if they don&apos;t need an application.</span>
      </div>
      <div className="mb-4">
        <span>
          If you make any mistakes here, you&apos;ll be able to make changes before you submit the application.
        </span>
      </div>
      <div className="mb-4">
        <span>Who needs an application? Select all that apply.</span>
      </div>
      <div className="mb-4">
        <Checkbox
          checked={requireEmployee}
          label={EMPLOYEE.label}
          onChange={toggleEmployeeRequired}
          isInvalid={isValidating && !isValid()}
        />
      </div>
      <div className="mb-4">
        <Checkbox
          checked={requireSpouse}
          label={SPOUSE.label}
          onChange={toggleSpouseRequired}
          isInvalid={isValidating && !isValid()}
        />
      </div>
      <div className="mb-4">
        <Checkbox
          checked={requireChildren}
          label={CHILD.label}
          onChange={toggleChildrenRequired}
          isInvalid={isValidating && !isValid()}
        />
      </div>
    </div>
  )
}

export default Applicants
