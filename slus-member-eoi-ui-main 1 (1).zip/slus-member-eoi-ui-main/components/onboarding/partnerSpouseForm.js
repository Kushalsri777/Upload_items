import Fullname from '@/components/personal/fullname'
import Gender from '@/components/personal/gender'
import DateOfBirth from '@/components/personal/dateOfBirth'
import Email from '@/components/personal/email'
import { useApplicants } from '@/components/context/Applicants.context'
import { useEffect } from 'react'
import { useFormContext } from 'react-hook-form'
import Height from '@/components/personal/height'
import Weight from '@/components/personal/weight'
import { useContinuance } from '@/components/context/Continuance.context'

const nameControls = [
  { label: 'First name', controllerName: 'firstName' },
  { label: 'Last name', controllerName: 'lastName' },
]

export function PartnerSpouseForm({ showDetails = false }) {
  const { spouse, isKnownUser } = useApplicants()
  const { setValue } = useFormContext()
  const { isPlaceholder } = useContinuance()

  useEffect(() => {
    setValue('firstName', spouse?.firstName)
    setValue('lastName', spouse?.lastName)
    setValue('genderCode', spouse?.genderCode)
    setValue('dateOfBirth', spouse?.dateOfBirth)
    setValue('heightFeet', spouse?.heightFeet)
    setValue('heightInches', spouse?.heightInches)
    setValue('weight', spouse?.weight)
    setValue('email', spouse?.email)
  }, [])

  return (
    <div className="max-w-sm">
      <Fullname controls={nameControls} isViewOnly={isKnownUser && !isPlaceholder} validatePlaceholder={true} />
      <Gender />
      <DateOfBirth minAge={16} />
      {showDetails && (
        <>
          <Height />
          <Weight />
        </>
      )}
      <Email controllerName="email" />
    </div>
  )
}
