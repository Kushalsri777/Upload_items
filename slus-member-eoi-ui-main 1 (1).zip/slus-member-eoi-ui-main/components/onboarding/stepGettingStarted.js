import { useContext, useEffect, useState } from 'react'
import { AppContext } from '@/components/context/app.context'
import { SUPPORT_EMAIL, SUPPORT_PHONE } from '@/common/enums/constant'
import { getProductCode } from '@/common/enums/productCode'
import { DISABILITY, LIFE } from '@/common/enums/productType'
import { StepHandlerContext } from '@/components/context/StepHandler.context'

const StepGettingStarted = ({ isKnownUser = true }) => {
  const { caseInfo } = useContext(AppContext)
  const [productText, setProductText] = useState('')
  const { setStepHandler } = useContext(StepHandlerContext)

  useEffect(() => {
    const employee = caseInfo?.employee
    const coverages = employee?.coverages || []
    const productTypes = coverages?.map((c) => getProductCode(c.productCode)?.productType) || []
    const productText = productTypes
      ?.filter((p) => p === LIFE || p === DISABILITY)
      ?.filter((value, index, array) => array.indexOf(value) === index) // only unique
      ?.map((p) => {
        switch (p) {
          case LIFE:
            return 'life'
          case DISABILITY:
            return 'disability'
        }
      })
      ?.join(' and ')
    setProductText(productText)
  }, [caseInfo])

  useEffect(() => {
    setStepHandler({ onClickNext: async () => true })
  }, [])

  return (
    <>
      {isKnownUser ? (
        <div key="onboarding-step-known-getting-started">
          <div className="mb-4">
            <span className="mb-4">{`Welcome to your Evidence of Insurability (EOI) application for additional ${productText} coverage.`}</span>
          </div>
          <div className="mb-4">
            <span className="mb-4">
              Applying online is quick, easy, and strictly confidential between you and Sun Life. And if you don&apos;t
              have time to finish on your first try, don&apos;t worry, you&apos;ll be able to save your answers and
              finish later.
            </span>
          </div>
          <div className="mb-4">
            <span className="mb-4">Here&apos;s what you can expect:</span>
          </div>
          <div className="mb-4">
            <span className="mb-4">
              <ol className="list-decimal">
                <li>
                  Confirm some general information and complete a health history questionnaire for yourself and any
                  other applicants.
                </li>
                <li>If necessary, answer some follow-up questions regarding medical conditions.</li>
                <li>Review your answers and submit your application.</li>
              </ol>
            </span>
          </div>
          <div className="mb-4">
            <span className="mb-4">{`If you have any questions or concerns, we're here to help. You can call us at ${SUPPORT_PHONE} or send email to ${SUPPORT_EMAIL}. Or, if you notice any personal information in the application that's inaccurate, please contact your human resources (HR) department or benefits provider.`}</span>
          </div>
          <div className="mb-4">
            <span className="mb-4">Let&apos;s get started!</span>
          </div>
        </div>
      ) : (
        <div key="onboarding-step-known-getting-started">
          <div className="mb-4">
            <span className="mb-4">
              Welcome to your Evidence of Insurability (EOI) application for additional life and/or disability coverage.
            </span>
          </div>
          <div className="mb-4">
            <span className="mb-4">
              Applying online is quick, easy, and strictly confidential between you and Sun Life. And if you don&apos;t
              have time to finish on your first try, don&apos;t worry, you&apos;ll be able to save your answers and
              finish later.
            </span>
          </div>
          <div className="mb-4">
            <span className="mb-4">Here&apos;s what you can expect:</span>
          </div>
          <div className="mb-4">
            <span className="mb-4">
              <ol className="list-decimal">
                <li>Let us know who needs an application.</li>
                <li>
                  Provide some general information and complete a health history questionnaire for yourself and any
                  other applicants.
                </li>
                <li>If necessary, answer some follow-up questions regarding medical conditions.</li>
                <li>Review your answers and submit your application.</li>
              </ol>
            </span>
          </div>
          <div className="mb-4">
            <span className="mb-4">{`If you have any questions or concerns, we're here to help. You can call us at ${SUPPORT_PHONE} or send email to ${SUPPORT_EMAIL}. Or, if you notice any personal information in the application that's inaccurate, please contact your human resources (HR) department or benefits provider.`}</span>
          </div>
          <div className="mb-4">
            <span className="mb-4">Let&apos;s get started!</span>
          </div>
        </div>
      )}
    </>
  )
}

export default StepGettingStarted
