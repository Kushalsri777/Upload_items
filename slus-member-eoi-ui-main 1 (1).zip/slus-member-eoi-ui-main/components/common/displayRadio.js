import { Radio } from '@/components/helios-components'
import { parseForVariables } from '@/components/healthHistoryQuestions/steps/util'

const DisplayRadio = ({ question, index, firstname, onRadioChange, disabled = false }) => {
  const variables = { name: firstname, firstname: firstname }
  const processedDesc = question?.optionDescription ? parseForVariables(question.optionDescription, variables) : null

  return (
    <div className="max-w-md mt-3">
      {processedDesc}
      <div>
        <Radio
          key="0"
          id={`yes-${index}`}
          inline
          label="Yes"
          value="YES"
          checked={question.textValue === 'YES'}
          name={question.requirementOptionCd}
          onChange={(e) => onRadioChange(e, true)}
          disabled={disabled}
        />
        <Radio
          key="1"
          id={`no-${index}`}
          inline
          label="No"
          value="NO"
          checked={question.textValue === 'NO'}
          name={question.requirementOptionCd}
          onChange={(e) => onRadioChange(e, false)}
          disabled={disabled}
        />
      </div>
    </div>
  )
}

export default DisplayRadio
