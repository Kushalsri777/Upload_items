# EOI Member - Frontend

This is the frontend for the EOI Member application developed using Next.js, a popular React.js framework.

## Prerequisites

- Node v18.X

Recommend installing nvm (Node Version Manager) to easily switch node/npm versions.

## Getting Started

You can run the development server, by running the commands below in the project root directory:

```shell
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

You can start editing the files in the project. The page auto-updates as you edit the files.

## Learn More

To learn more about Next.js, take a look at the following resources:

- [Next.js Documentation](https://nextjs.org/docs) - learn about Next.js features and API.
- [Learn Next.js](https://nextjs.org/learn) - an interactive Next.js tutorial.

## Cypress Setup locally

### If you are on windows, do the next steps:

1- Download the Cypress Zip file for the version specified in the package.json file.
The current version of the Cypress is `13.1.0`. The Zip file can be found
[Cypress Zip](https://download.cypress.io/desktop)

2- You need to check the AppData folder which is found in `Users\[SAMPLE_USER]\AppData`.
In that folder `AppData`, if you don't have a Cypress folder , you need to create the next structure of folders
`Cypress\Cache\13.1.0`.

3- Once you have the structure of folders created `C:\Users\[SAMPLE_USER]\AppData\Local\Cypress\Cache\13.1.0` ,
unzip de Cypress.zip file and put the unzip folder `Cypress` , inside the sub-folder `13.1.0`
After the steps below are completed , the path to cypress will look like this : `C:\Users\[SAMPLE_USER]\AppData\Local\Cypress\Cache\13.1.0\Cypress`

### Screenshot below of how it should look after previous steps are completed :

![img.png](cypress_folder_structure_on_windows.png)

### The next npm commands are available to run the Cypress test :

```
npm run cypress:run:e2e
```

Will run the E2E Cypress tests (`cypress\e2e\`) in the terminal and will load the test in the Browser temporarily

```
npm run cypress:run:components
```

Will run the Components Cypress tests (`cypress\support`) only the component tests

```
npm run cypress:open
```

Will open the Cypress UI console , where you can run the `E2E and Component` tests from the Browser directly

## Docker

This application is Docker compatible. If you have Docker installed and running, you can build a Docker image and run it.

### Building Docker Image

Navigate to the project root directory in your terminal and execute:

```shell
docker build -t sunlife.com/slus-member-eoi-ui:latest .
```

You will need to do this step whenever you have new changes.

### Running with Docker Compose

You can run the application with Docker Compose. Navigate to the project root directory in your terminal and execute:

```shell
docker-compose up -d
```

This will start up all the required services as defined in the `docker-compose.yaml` file. The frontend application will
be exposed on the 3001 port and the backend pn port 8081 connecting to the QA database.

Visit http://localhost:3001 to see the application.

When finished, navigate to the project root directory in your terminal and execute:

```shell
docker-compose down
```
