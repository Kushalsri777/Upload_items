const API_URL = process.env.API_URL
const BASE_PATH = process.env.NEXT_PUBLIC_BASE_PATH || ''

/** @type {import('next').NextConfig} */

const nextConfig = {
  output: API_URL ? undefined : 'export',
  basePath: BASE_PATH,
  images: {
    unoptimized: true,
  },
  webpack(config) {
    config.module.rules.push({
      test: /\.svg$/i,
      issuer: /\.[jt]sx?$/,
      use: ['@svgr/webpack'],
    })
    return config
  },
  ...(API_URL && {
    async rewrites() {
      return [
        {
          source: '/api/:path*',
          destination: `${API_URL}/:path*`,
        },
      ]
    },
  }),
}

module.exports = nextConfig
