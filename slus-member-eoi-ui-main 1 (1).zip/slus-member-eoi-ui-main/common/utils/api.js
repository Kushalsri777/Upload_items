import { isNil } from 'lodash'
import { DATE_OF_BIRTH } from '@/common/enums/regex'
import moment from 'moment'

export const saveChildren = async (children) => {
  const childrenToSave = children.map((child) => {
    return {
      firstName: child.firstName,
      lastName: child.lastName,
      gender: child.genderCode,
      dateOfBirth: DATE_OF_BIRTH.YYYY_DD_MM.convert(child.dateOfBirth),
    }
  })
  const url = `${process.env.NEXT_PUBLIC_BASE_URL}/applicants/children`
  return await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(childrenToSave),
  })
}

export const addChild = async (values) => {
  const url = `${process.env.NEXT_PUBLIC_BASE_URL}/applicants/child`
  return await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      firstName: values.firstName,
      lastName: values.lastName,
      gender: values.genderCode,
      dateOfBirth: DATE_OF_BIRTH.YYYY_DD_MM.convert(values.dateOfBirth),
    }),
  })
}

export const updateChild = async (values, seqNum) => {
  const url = `${process.env.NEXT_PUBLIC_BASE_URL}/applicants/child/${seqNum}`
  return await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      firstName: values.firstName,
      lastName: values.lastName,
      gender: values.genderCode,
      dateOfBirth: DATE_OF_BIRTH.YYYY_DD_MM.convert(values.dateOfBirth),
      heightFeet: parseInt(values.heightFeet, 10),
      heightInches: parseInt(values.heightInches, 10),
      weight: parseInt(values.weight, 10),
    }),
  })
}

export const removeChild = async (seqNum) => {
  const url = `${process.env.NEXT_PUBLIC_BASE_URL}/applicants/child/${seqNum}`
  return await fetch(url, {
    method: 'DELETE',
  })
}

export const savePartner = async (values, sendDetails = false) => {
  const url = `${process.env.NEXT_PUBLIC_BASE_URL}/applicants/partner`
  const body = {
    firstName: values.firstName,
    lastName: values.lastName,
    gender: values.genderCode,
    dateOfBirth: DATE_OF_BIRTH.YYYY_DD_MM.convert(values.dateOfBirth),
    email: values.email,
  }
  if (sendDetails) {
    body.heightFeet = parseInt(values.heightFeet, 10)
    body.heightInches = parseInt(values.heightInches, 10)
    body.weight = parseInt(values.weight, 10)
  }
  return await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  })
}

export const removePartner = async () => {
  const url = `${process.env.NEXT_PUBLIC_BASE_URL}/applicants/partner`
  return await fetch(url, {
    method: 'DELETE',
  })
}

export const saveEmployee = async (values) => {
  const url = `${process.env.NEXT_PUBLIC_BASE_URL}/applicants/employee`
  return await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      firstName: values.firstName,
      lastName: values.lastName,
      gender: values.genderCode,
      heightFeet: parseInt(values.heightFeet, 10),
      heightInches: parseInt(values.heightInches, 10),
      weight: parseInt(values.weight, 10),
      dateOfBirth: DATE_OF_BIRTH.YYYY_DD_MM.convert(values.dateOfBirth),
    }),
  })
}

const buildQueryString = (params) => {
  return new URLSearchParams(params).toString()
}

export const getHealthQuestions = async (usageCode, applicantType, dependentSeqNum) => {
  let url
  if (isNil(usageCode) && isNil(applicantType) && isNil(dependentSeqNum)) {
    url = `${process.env.NEXT_PUBLIC_BASE_URL}/healthQuestions/all`
  } else {
    const params = {
      usageCode,
      applicantType,
      dependentSeqNum,
    }
    const queryString = buildQueryString(params)
    url = `${process.env.NEXT_PUBLIC_BASE_URL}/healthQuestions?${queryString}`
  }

  const response = await fetch(url, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
    },
  })
  return response.json()
}

export const getHealthQuestionsForApplicant = async (applicantType, seqNum) => {
  const params = {
    applicantType,
    seqNum,
  }
  const queryString = buildQueryString(params)
  const url = `${process.env.NEXT_PUBLIC_BASE_URL}/healthQuestions/applicant?${queryString}`
  const response = await fetch(url, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
    },
  })
  return response.json()
}

export const saveHealthQuestions = async (body) => {
  const url = `${process.env.NEXT_PUBLIC_BASE_URL}/healthQuestions`
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  })
  return response.ok
}

const translateQuestionsToSave = (questionstoSave = []) => {
  return questionstoSave.map((question) => ({
    benCd: question.benCd,
    requirementId: question.requirementId,
    requirementOptionCd: question.requirementOptionCd,
    requirementOptionUsageCd: question.requirementOptionUsageCd,
    provisionSeqNum: question.provisionSeqNum,
    textValue: question.textValue,
    valueId: question.valueId,
    dateValue: question.dateValue ? moment(question.dateValue).format('YYYY-MM-DD') : null,
  }))
}

const translateQuestionsToRemove = (questionsToRemove = []) => {
  return questionsToRemove.map((question) => ({
    benCd: question.benCd,
    requirementId: question.requirementId,
    requirementOptionCd: question.requirementOptionCd,
    requirementOptionUsageCd: question.requirementOptionUsageCd,
    provisionSeqNum: question.provisionSeqNum,
  }))
}

export const saveMedicationAnswers = async (applicant, questionstoSave = [], questionsToRemove = []) => {
  const body = {
    applicantType: applicant.type.code,
    dependentSeqNum: applicant.seqNum,
    answers: translateQuestionsToSave(questionstoSave),
    answersToRemove: translateQuestionsToRemove(questionsToRemove),
  }

  if (body.answers.length > 0 || body.answersToRemove.length > 0) {
    return await saveHealthQuestions(body)
  }
  return true
}

export const saveAnswersForTextValue = async (applicant, questions, questionsToRemove = []) => {
  const body = {
    applicantType: applicant.type.code,
    dependentSeqNum: applicant.seqNum,
    answers: translateQuestionsToSave(questions),
    answersToRemove: translateQuestionsToRemove(questionsToRemove),
  }

  if (body.answers.length > 0) {
    return await saveHealthQuestions(body)
  }
  return true
}

export const fetchLocations = async () => {
  const url = `${process.env.NEXT_PUBLIC_BASE_URL}/locations`
  const response = await fetch(url, {
    method: 'GET',
  })
  const responseValue = await response.json()
  return responseValue.map((location) => {
    return {
      label: location.description,
      value: location.code,
    }
  })
}

export const completeApplicant = async (applicant) => {
  const url = `${process.env.NEXT_PUBLIC_BASE_URL}/applicants/complete`
  return await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      applicantType: applicant.applicantType,
      seqNum: applicant.seqNum,
    }),
  })
}
