const submitted = {
  title: 'Thank you! Your EOI application has been submitted.',
  body: {
    a: 'Please be aware that adjusting or resubmitting your application is not possible until your initial request has received approval or denial.',
    b: 'What happens next?',
    c: 'First, your employer will verify your key information and coverage amount. Next, we will review your application to determine eligibility and come to a decision. You may receive a request for additional information.  If no additional information is needed, we will send you a letter with our coverage decision.',
    d: 'Please allow 10 business days for review of your application.',
    e: 'If you have any questions regarding your open EOI application, contact Sun Life at 1- 800-247-6875',
    links: {
      review: 'Review Electronic Consent',
      print: 'Print submitted application',
    },
  },
}

// const tableFirstColumnWidthPx = "155px"
const electroninConsent = {
  title: 'Evidence of Insurability Electronic Consent',
  link: 'Print Electronic Consent',
  body: {
    paragraphs: [
      {
        values: ['IMPORTANT NOTICE - PLEASE READ CAREFULLY AND RETAIN A COPY FOR FUTURE REFERENCE'],
      },
      {
        values: [
          'Sun Life Assurance Company of Canada ("Company," "we" or "us") provides you with the option without charge to receive, in electronic format, certain information relating to your application for group insurance coverage(s) that would otherwise be sent to you in paper form by mail or otherwise. To receive application information in electronic format and complete an application electronically, you must provide us with your agreement to the following terms and conditions. If you click the "I agree" button, you will be providing your consent to:',
        ],
      },
      {
        values: [
          '(a) have the information described in this Consumer Electronic Consent and Disclosure ("Consent") delivered to you in electronic format;',
          '(b) execute via electronic means the documents that are described in this Consent; and',
          '(c) all of the terms and conditions set forth below in this Consent.',
        ],
      },
      {
        values: [
          'If you do not want to have the information described in this Consent delivered to you in electronic format, if you do not want to execute via electronic means the documents that are described in this Consent, or if you do not agree with all of the terms and conditions of this Consent, you may not complete an application electronically and you should click the “I disagree” button. Please read the following terms and conditions carefully.',
        ],
      },
      {
        subTitle: 'Scope and Duration of this Consent',
        values: [
          'By clicking the "I agree" button you agree to all of the terms and conditions of this Consent, including your agreement to:',
        ],
      },
      {
        values: [
          '(a) receive via electronic means an Evidence of Insurability Application, including information that the Company is required by law to provide or make available to you in writing, as well as other information and documents related to your application (collectively, "Application Documents");',
          '(b) complete and execute via electronic means the Application Documents; and',
          '(c) be bound with the same force and effect as if you had affixed your signature on paper by hand when you apply your electronic signature to Application Documents.',
        ],
      },
      {
        values: [
          'Even though you have provided the Company with this Consent, the Company may, at its option: (a) deliver Application Documents to you on paper and (b) require that certain communications from you be delivered to the Company on paper.',
        ],
      },
      {
        subTitle: 'Requesting Copies',
        values: [
          'You may obtain paper copies of Application Documents at any time and without charge by contacting us in a manner provided below (or such other manner as may be permitted in the future).',
        ],
      },
      {
        subTitle: 'Maintaining Copies of Application Documents',
        values: [
          'You agree to print or save this Consent and all Application Documents, and to keep printed or electronic copies for your records. If you have any trouble with printing or saving, you should contact the Company.',
        ],
      },
      {
        subTitle: 'Withdrawal of Your Consent/Termination of this Consent',
        values: [
          'This Consent will become effective when you click the "I agree" button and will remain in effect unless terminated by the Company in its sole discretion or until you withdraw your consent (as described below), whichever comes first.',
        ],
      },
      {
        values: [
          'If at any time you would like to terminate this Consent and cease receiving Application Documents in electronic format, you must notify the Company in writing at the below address or telephone number. Your withdrawal of your consent to receive Application Documents in electronic format will be made with respect to all Application Documents and will not be made with respect to only some Application Documents. Your withdrawal of your consent to receive Application Documents in electronic format will become effective only after the Company has a reasonable period of time to process your withdrawal. Thereafter, all Application Documents will be provided to you on paper by mail.',
        ],
      },
      {
        values: [
          'The Company may, at its option, treat your providing us with an invalid e-mail address, or the subsequent malfunction of a previously valid electronic address, as a withdrawal and termination of your consent to receive Application Documents in electronic format.',
        ],
      },
      {
        values: [
          'The Company reserves the right, in its sole discretion, to discontinue providing Application Documents in electronic format, or to terminate or change the terms and conditions on which the Company provides electronic Application Documents. We will provide you with notice of any such termination or change as required by law',
        ],
      },
      {
        subTitle: 'Changes to Your Contact Information',
        values: [
          'It is your responsibility to promptly notify the Company of any changes to your e-mail address and all other contact information. You may inform us of any such changes by contacting us at the address provided below (or such other address as may be provided to you in the future). Such change will become effective only after we have a reasonable period of time to process the change',
        ],
      },
      {
        subTitle: 'Contacting the Company',
      },
      {
        values: [
          <span key="ec_mail_label" className="font-sunlifeBold">
            Mail:
          </span>,
          'P.O. Box 81344',
          'Wellesley, MA 02481',
        ],
      },
      {
        values: [
          <>
            <span key="ec_tel_label" className="font-sunlifeBold">
              Telephone:&nbsp;
            </span>
            <span key="ec_tel_value">(800)&nbsp;247-6875</span>
          </>,
        ],
      },
      {
        subTitle: 'Systems Requirements',
        values: [
          'To access and retain the Application Documents sent or made available to you electronically by the Company you must have access to a computer with an Internet connection. You must be able to send and receive e-mails, and be able to save the Application Documents to a storage device for later reference or have the computer connected to a printer so you can print such documents. Please contact the Company at the telephone number above if you have any trouble with printing or saving your Application Documents.',
        ],
      },
      {
        values: [
          'PRINT OR SAVE A COPY OF THIS CONSENT AND DISCLOSURE NOW FOR FUTURE REFERENCE (To print press Ctrl+p (Windows) or select your browser’s print option.',
        ],
      },
      {
        isVisible: (pathname) => '/electronic-consent' === pathname,
        subTitle:
          'I have CAREFULLY read this Consent and accept its provisions voluntarily and with full knowledge and understanding of its terms and conditions. I have computer hardware and software that meets the minimum hardware and software requirements described above. I have successfully printed or saved a copy of this Consent and Disclosure.',
      },
      {
        isVisible: (pathname) => '/dashboard' === pathname,
        subTitle:
          'I have CAREFULLY read this Consent and accept its provisions voluntarily and with full knowledge and understanding of its terms and conditions. I have computer hardware and software that meets the minimum hardware and software requirements described above. I have successfully printed or saved a copy of this Consent and Disclosure. By clicking the "I agree" button, I agree to receive and execute electronic Application Documents in accordance with the terms described above.',
      },
    ],
  },
}

const login = {
  confirmation: {
    policyholder: {
      body: "Note: Your policyholder might be your employer, a parent company, or a subsidiary. Check with your human resources (HR) department if you're unsure.",
    },
    checkboxText: 'I accept the terms of Electronic Consent',
    checkboxErrorText: 'Please select the checkbox to accept the terms',
    info: {
      message: "If you don't accept the terms of Electronic Consent, you'll need to submit a ",
      link: 'paper EOI application',
    },
  },
}

const demographicsModal = {
  heading: 'EOI Application Instructions',
  body: {
    values: [
      <>
        <div className="text-xl">Welcome!</div>
      </>,
      'This form requires you to answer questions about your medical history, so we recommend gathering your important documents before you start.',
      'To protect your privacy, this application cannot be paused or saved and automatically closes after 15 minutes of inactivity.',
      <>
        You will return to the main EOI dashboard to complete each application included in your coverage request. Once
        all forms are completed use the <span className="font-sunlifeBold">Submit EOI Application</span> button to
        finish your application.
      </>,
    ],
  },
  button: "Let's begin",
}

const timeoutModal = {
  heading: 'Your session will timeout in 5 minutes',
  body: {
    values: [
      'Your session will timeout soon and your application will be lost.',
      'Select "Continue application" to extend the session and keep filling out the form. ',
    ],
  },
}

const timeoutToast = {
  content: 'You’ve been timed out, please log in again to complete your application.',
}

const footer = {
  contactInfo: [
    <div key="company-name">Sun Life Assurance Company of Canada</div>,
    <div key="company-addr">96 Worcester Street, Wellesley Hills, MA 02481</div>,
    <div key="company-phon">Customer Service: 800-247-6875</div>,
  ],
  componentContentInfo: {
    body: '',
    copyText: <span>© Sun Life Assurance Company of Canada. All rights reserved.</span>,
    heading: "Life\'s brighter under the sun",
  },
}

const onboardingParterSpouseStep = {
  body: {
    values: [
      "You've asked to enroll your spouse for additional coverage. If this information is not accurate, contact your human resources department. If you make any mistakes here, you'll be able to make changes before you submit the application.",
      'All fields are required unless labeled optional.',
    ],
  },
}

export {
  electroninConsent as ELECTRONIC_CONSENT,
  submitted as SUBMITTED,
  login as LOGIN,
  demographicsModal as DEMOGRAPHICS_MODAL,
  footer as FOOTER,
  timeoutModal as TIMEOUT_MODAL,
  timeoutToast as TIMEOUT_TOAST,
  onboardingParterSpouseStep as ONBOARDING_PARTER_SPOUSE_STEP,
}
