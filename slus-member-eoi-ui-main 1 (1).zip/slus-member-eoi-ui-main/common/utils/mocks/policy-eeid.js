const mock = {
  id: 3809,
  policyNumber: '926925',
  sponsorName: 'March Core Regression Run 1 Scenario 37',
  situsState: 'MA',
  idType: 'EMPID',
  legalEntityCode: 'SLOC',
  closurePeriodDaysNum: 1,
  distributionChannelId: 20,
}

export default mock
