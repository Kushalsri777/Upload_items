const mock = { message: 'string' }
export default mock
