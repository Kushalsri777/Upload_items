const mock = {
  id: 2845,
  policyNumber: '827495',
  sponsorName: 'Core Regression Run 1 Scenario 6',
  situsState: 'NY',
  idType: 'SSN',
  legalEntityCode: 'SLHIC',
  closurePeriodDaysNum: 90,
  distributionChannelId: 17,
}

export default mock
