import { EMPTY_OR_NEWLINE_REGEX } from '@/common/enums/regex'
import { REQUIRED_FIELDS } from '@/common/enums/constant'

const validateEmptyString = (value) => {
  if (EMPTY_OR_NEWLINE_REGEX.test(value)) {
    return REQUIRED_FIELDS
  }
  return true
}

export { validateEmptyString }
