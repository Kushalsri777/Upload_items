import clsx from 'clsx'
import { PAPER_FORM_URL } from '../enums/constant'

const linkStyle = (disabled, additionalStyles) => {
  return clsx('flex flex-row items-center font-sunlifeBold', additionalStyles, {
    'no-underline cursor-pointer text-[#00588B]': !disabled,
    'stroke-gray text-gray-500': disabled,
  })
}

const openInNewTab = (url) => {
  window.open(url, '_blank').focus()
}

const navigateToPaperForm = () => {
  openInNewTab(PAPER_FORM_URL)
}

export { linkStyle, navigateToPaperForm, openInNewTab }
