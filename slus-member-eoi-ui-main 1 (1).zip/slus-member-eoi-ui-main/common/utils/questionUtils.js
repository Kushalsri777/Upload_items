import { isNil, isArray } from 'lodash'
import { COMPLETE, IN_PROGRESS, NOT_STARTED, NA } from '../enums/applicationStatusCode'

const isQuestionAnswered = (question = []) => {
  const { amountValue, textValue, dateValue } = question
  return !isNil(amountValue) || !isNil(textValue) || !isNil(dateValue)
}

const getUnansweredQuestionCount = (questions = []) => {
  const unansweredCount = questions
    .filter((q) => q.displayType !== 'LABEL')
    .reduce((accumulator, current) => {
      const isAnswered = isQuestionAnswered(current)
      return isAnswered ? accumulator : accumulator + 1
    }, 0)
  return unansweredCount
}

const getUnansweredSectionsCount = (questions = [], currentStatus) => {
  //FIXME: we will supply another question for the last page from the backend,
  // then this assumption for 'reviewPage' can be removed.
  const startingArray = currentStatus !== COMPLETE ? [{ reviewPage: 1 }] : []
  const unansweredCount = questions
    .filter((q) => q.displayType !== 'LABEL')
    .reduce((accumulator, current) => {
      const isAnswered = isQuestionAnswered(current)
      if (isAnswered) {
        return accumulator
      }
      const { requirementOptionUsageCd: section } = current
      if (!accumulator.includes(section)) {
        accumulator.push(section)
      }
      return accumulator
    }, startingArray)
  return unansweredCount.length
}

const getApplicantStatusCode = (questions = [], currentStatus) => {
  const { length: totalQuestionCount } = questions
  const totalAnswerableQuestionCount = questions.filter((q) => q.displayType !== 'LABEL').length

  if (totalQuestionCount === 0) {
    return NA
  }

  const unansweredCount = getUnansweredQuestionCount(questions)
  const unansweredSectionsCount = getUnansweredSectionsCount(questions, currentStatus)

  if (unansweredSectionsCount === 0 && totalAnswerableQuestionCount > 0) {
    return COMPLETE
  }

  if (totalAnswerableQuestionCount === unansweredCount) {
    return NOT_STARTED
  }

  if (unansweredSectionsCount > 0) {
    return IN_PROGRESS
  }

  return NA
}

const getDisplayStatusText = (questions = [], currentStatus) => {
  const applicantStatusCode = getApplicantStatusCode(questions, currentStatus)
  let statusText = null
  switch (applicantStatusCode) {
    case COMPLETE:
      statusText = 'Ready to submit'
      break
    case IN_PROGRESS:
      const unansweredSectionsCount = getUnansweredSectionsCount(questions, currentStatus)
      statusText = (
        <div>
          <span class="sl-icon sl-icon-exclamation-triangle" aria-hidden="true"></span>
          {`${unansweredSectionsCount} sections remaining`}
        </div>
      )
      break
    case NOT_STARTED:
    case NA:
      statusText = 'Not started'
      break
    default:
      statusText = `Unknown status code`
  }
  return [statusText, applicantStatusCode]
}

const getButtonText = (statusCode) => {
  switch (statusCode) {
    case COMPLETE:
      return 'Edit'
    case IN_PROGRESS:
      return 'Continue'
    default:
      return 'Start'
  }
}

const getFullName = (applicant) => {
  const { firstName: fn, lastName: ln } = applicant
  return `${fn} ${ln}`
}

export {
  isQuestionAnswered,
  getUnansweredQuestionCount,
  getUnansweredSectionsCount,
  getApplicantStatusCode,
  getDisplayStatusText,
  getButtonText,
  getFullName,
}
