import { EXTERNAL, PRINT } from './imageIcons'
import { openInNewTab } from '../utils/util'

const BASE_PATH = process.env.NEXT_PUBLIC_BASE_PATH || ''

export const OPEN = {
  id: 'OPEN',
  is: (s) => 'OPEN' === s,
  header: 'First, agree to the Electronic Consent',
  label: 'Print Electronic Consent',
  image: <PRINT />,
  onClick: () => openInNewTab(`${BASE_PATH}/electronic-consent`),
}

export const CLOSED = {
  id: 'CLOSED',
  is: (s) => 'CLOSED' === s,
  header: 'Electronic Consent',
  label: 'Review Electronic Consent',
  image: <EXTERNAL />,
  onClick: () => {},
}
