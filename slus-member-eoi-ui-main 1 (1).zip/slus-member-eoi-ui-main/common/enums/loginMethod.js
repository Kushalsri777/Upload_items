import { SSN_REGEX, EMPLOYEE_ID_REGEX } from './regex'

export const SSN = {
  abr: 'SSN',
  label: 'Social Security Number',
  pattern: {
    value: SSN_REGEX,
    message: 'Not a valid SSN',
  },
  validate: (value) => true,
  isPassword: true,
  autoComplete: 'newPassword',
  mask: '999-99-9999',
  maskChar: null,
  formatChars: { 9: '[0-9]' },
  formatValue: (val) => `*******${val?.slice(-4)}`,
}

export const EMPID = {
  abr: 'Employee ID',
  label: 'Employee ID',
  pattern: {
    value: EMPLOYEE_ID_REGEX,
    message: 'Not a valid Employee ID',
  },
  validate: (value) => true,
  isPassword: false,
  autoComplete: 'off',
  mask: '*************',
  maskChar: null,
  formatChars: { '*': '[A-Za-z0-9_.]' },
  formatValue: (val) => val,
}

export const getLoginMethod = (key) => ('EMPID' === key ? EMPID : SSN)
