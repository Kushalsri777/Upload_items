const YES_NO = 'boolean'
const PRI_PHY = 'object'

export { YES_NO, PRI_PHY }
