import moment from 'moment'

export const ADDRESS_FIELDS_REGEX = new RegExp("^[A-Za-z0-9-'/#.,ÁÉÍÓÚÜÑáéíóúüñ ]+$")
export const CITY_REGEX = new RegExp("^[A-Za-z0-9-'/.ÁÉÍÓÚÜÑáéíóúüñ ]+$")
export const DESCRIPTION_REGEX = new RegExp("^[A-Za-z0-9-,;'/. ]+$")
export const EMPLOYEE_ID_REGEX = new RegExp(/^[A-Za-z0-9_.]{1,13}$/)
export const NAME_FIELDS_REGEX = new RegExp("^[A-Za-z0-9-,.'ÁÉÍÓÚÜÑáéíóúüñ ]*$")
export const PHONE_NUMBER_REGEX = new RegExp('^\\d{3}(-)?\\d{3}(-)?\\d{4}$')
export const POSTAL_CODE_REGEX = new RegExp('^\\d{5}(-|\\s*)?(\\d{4})?$')
export const SSN_REGEX = new RegExp(/^(?!123-?45-?6789)(?!000|666)[0-8][0-9]{2}-?(?!00)[0-9]{2}-?(?!0000)[0-9]{4}$/)

const HEIGHT = {
  FEET: {
    regex: new RegExp('^[2-7]$'),
    message: 'Only numbers from 2 to 7',
  },
  INCHES: {
    regex: new RegExp('^([0-9]|1[01])$'),
    message: 'Only numbers from 0 to 11',
  },
}

const WEIGHT = {
  LBS: {
    regex: new RegExp('^[1-9]\\d*$'),
    message: 'Only positive numbers',
  },
}

const DATE_OF_BIRTH = {
  MM_DD_YYYY: {
    regex: new RegExp(/^(0[1-9]|1[0-2])\/(0[1-9]|1\d|2\d|3[01])\/(19|20)\d{2}$/),
    message: 'Please follow pattern: MM/DD/YYYY',
    pattern: 'MM/DD/YYYY',
  },
  YYYY_DD_MM: {
    regex: new RegExp(/^(19|20)\d{2}-(0[1-9]|1[0-2])-(0[1-9]|1\d|2\d|3[01])$/),
    message: 'Please follow pattern: YYYY-MM-DD',
    pattern: 'YYYY-MM-DD',
  },
}

DATE_OF_BIRTH.MM_DD_YYYY.convert = (dateString) => {
  if (DATE_OF_BIRTH.YYYY_DD_MM.regex.test(dateString)) {
    return moment(dateString, DATE_OF_BIRTH.YYYY_DD_MM.pattern).format(DATE_OF_BIRTH.MM_DD_YYYY.pattern)
  }
  return dateString
}

DATE_OF_BIRTH.YYYY_DD_MM.convert = (dateString) => {
  if (DATE_OF_BIRTH.MM_DD_YYYY.regex.test(dateString)) {
    return moment(dateString, DATE_OF_BIRTH.MM_DD_YYYY.pattern).format(DATE_OF_BIRTH.YYYY_DD_MM.pattern)
  }
  return dateString
}

const EMAIL = {
  regex: new RegExp('^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$'),
  message: 'Only valid email allowed',
}

export const HEIGHT_FEET_REGEX = HEIGHT.FEET.regex
export const HEIGHT_INCHES_REGEX = HEIGHT.INCHES.regex
export const WEIGHT_LBS_REGEX = WEIGHT.LBS.regex
export const EMAIL_REGEX = EMAIL.regex

export { HEIGHT, WEIGHT, DATE_OF_BIRTH, EMAIL }

export const EMPTY_OR_NEWLINE_REGEX = new RegExp(/^[\s\n]*$/)
