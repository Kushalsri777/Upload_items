const APPLICATION_EE = 'applicationEmployee'
const APPLICATION_SP = 'applicationSpouse'
const APPLICATION_CH = 'applicationChild'
const DASHBOARD = 'dashboard'
const ONBOARDING = 'onboarding'

export { APPLICATION_EE, APPLICATION_SP, APPLICATION_CH, DASHBOARD, ONBOARDING }
