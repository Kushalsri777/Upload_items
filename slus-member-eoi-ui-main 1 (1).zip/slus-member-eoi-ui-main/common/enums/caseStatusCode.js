export const NEW = 'NEW'
export const COMPLETE = 'COMPLETE'
export const IN_PROGRESS = 'IN_PROGRESS'
