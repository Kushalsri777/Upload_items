const enroller = {
  EMPLOYEE: {
    type: 'ee',
    label: 'Employee',
    legacyLabel: 'Employee',
    code: 'EMPLOYEE',
  },
  SPOUSE: {
    type: 'sp',
    label: 'Partner/spouse',
    legacyLabel: 'Spouse/Partner',
    code: 'SPOUSE',
  },
  CHILD: {
    type: 'ch',
    label: 'Child(ren)',
    legacyLabel: 'Child',
    code: 'CHILD',
  },
  // EMPLOYEE_NO_APPLICANT: {
  //     type: "eena",
  //     label: "Employee",
  //     legacyLabel: "Employee",
  //     code: "EMPLOYEE_NO_APPLICANT"
  // }
}

export default enroller

const getEnrollerByCode = (code) => {
  return enroller[code]
}
const TYPE_SORT = [enroller.EMPLOYEE.code, enroller.SPOUSE.code, enroller.CHILD.code]
const ee = enroller.EMPLOYEE
const sp = enroller.SPOUSE
const ch = enroller.CHILD
// const eena = enroller.EMPLOYEE_NO_APPLICANT
const all = [ee, sp, ch]

export {
  getEnrollerByCode,
  TYPE_SORT,
  all as ALL,
  ee as EMPLOYEE,
  sp as SPOUSE,
  ch as CHILD,
  // eena as EMPLOYEE_NO_APPLICANT,
}
