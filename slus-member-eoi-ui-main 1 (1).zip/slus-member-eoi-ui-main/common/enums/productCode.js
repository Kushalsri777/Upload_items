import { CRITICAL_ILLNESS, DISABILITY, LIFE } from './productType'

export const BASLICH = { id: 'BASLICH', productType: LIFE }
export const BASLIFEE = { id: 'BASLIFEE', productType: LIFE }
export const BASLISP = { id: 'BASLISP', productType: LIFE }
export const OPTLIFCH = { id: 'OPTLIFCH', productType: LIFE }
export const OPTLIFEE = { id: 'OPTLIFEE', productType: LIFE }
export const OPTLIFSP = { id: 'OPTLIFSP', productType: LIFE }
export const VOLLIFCH = { id: 'VOLLIFCH', productType: LIFE }
export const VOLLIFEE = { id: 'VOLLIFEE', productType: LIFE }
export const VOLLIFSP = { id: 'VOLLIFSP', productType: LIFE }
export const CRILLCCH = { id: 'CRILLCCH', productType: CRITICAL_ILLNESS }
export const CRILLCEE = { id: 'CRILLCEE', productType: CRITICAL_ILLNESS }
export const CRILLCSP = { id: 'CRILLCSP', productType: CRITICAL_ILLNESS }
export const CUSTOMDI = { id: 'CUSTOMDI', productType: DISABILITY }
export const LTDBUYUP = { id: 'LTDBUYUP', productType: DISABILITY }
export const LTDEE = { id: 'LTDEE', productType: DISABILITY }
export const STDEE = { id: 'STDEE', productType: DISABILITY }

const ALL = [
  BASLICH,
  BASLIFEE,
  BASLISP,
  OPTLIFCH,
  OPTLIFEE,
  OPTLIFSP,
  VOLLIFCH,
  VOLLIFEE,
  VOLLIFSP,
  CRILLCCH,
  CRILLCEE,
  CRILLCSP,
  CUSTOMDI,
  LTDBUYUP,
  LTDEE,
  STDEE,
]

export const getProductCode = (id) => ALL.find((p) => p.id === id.trim())
