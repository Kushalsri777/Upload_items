import Image from 'next/image'
import CircleCheckmark from '@/components/icon/circleCheckmark'

const BASE_PATH = process.env.NEXT_PUBLIC_BASE_PATH || ''

const circleAdd = (props) => (
  <Image
    className="mr-2"
    alt="Print"
    src={`${BASE_PATH}/images/add-circle-24px.svg`}
    width={24}
    height={24}
    {...props}
  />
)

const circleCheckmark = (props) => <CircleCheckmark {...props} />

const download = (props) => (
  <Image className="mr-2" alt="Print" src={`${BASE_PATH}/images/download-24px.svg`} width={24} height={24} {...props} />
)

const external = (props) => (
  <Image
    className="mr-1"
    alt="External link"
    src={`${BASE_PATH}/images/external-link-32px.svg`}
    width={32}
    height={32}
    {...props}
  />
)

const print = (props) => (
  <Image className="mr-1" alt="Print" src={`${BASE_PATH}/images/print-20px.svg`} width={20} height={20} {...props} />
)

const trash = (props) => (
  <Image className="mr-1" alt="Print" src={`${BASE_PATH}/images/trash-24px.svg`} width={24} height={24} {...props} />
)

const close = (props) => (
  <Image alt="Close" src={`${BASE_PATH}/images/close-32px.svg`} width={32} height={32} {...props} />
)

const infoTarget = (props) => (
  <Image
    className="mr-2"
    alt="Information"
    src={`${BASE_PATH}/images/info-target-64px.svg`}
    width={64}
    height={64}
    {...props}
  />
)

const check = (props) => (
  <Image alt="Check" src={`${BASE_PATH}/images/check-32px.svg`} width={32} height={32} {...props} />
)
export {
  circleAdd as CIRCLE_ADD,
  circleCheckmark as CIRCLE_CHECKMARK,
  download as DOWNLOAD,
  external as EXTERNAL,
  print as PRINT,
  trash as TRASH,
  close as CLOSE,
  infoTarget as INFO_TARGET,
  check as CHECK,
}
