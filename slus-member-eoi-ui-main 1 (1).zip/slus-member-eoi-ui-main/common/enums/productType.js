export const CRITICAL_ILLNESS = 'CriticalIllness'
export const LIFE = 'Life'
export const DISABILITY = 'Disability'
