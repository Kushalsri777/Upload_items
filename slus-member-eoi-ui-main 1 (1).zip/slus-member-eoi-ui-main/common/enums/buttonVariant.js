const DANGER = 'danger'
const PRIMARY = 'primary'
const SECONDARY = 'secondary'
const SECONDARY_SMALL = 'secondary-small'
const TERTIARY = 'tertiary'

export { DANGER, PRIMARY, SECONDARY, SECONDARY_SMALL, TERTIARY }
