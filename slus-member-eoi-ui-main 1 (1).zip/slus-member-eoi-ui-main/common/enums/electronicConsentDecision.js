export const AGREE = 'AGREE'
export const DISAGREE = 'DISAGREE'
