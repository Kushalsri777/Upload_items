import StepGettingStarted from '@/components/onboarding/stepGettingStarted'
import EmployeeInformation from '@/components/onboarding/employeeInformation'
import Applicants from '@/components/onboarding/applicants'
import LiveAndWork from '@/components/onboarding/liveAndWork'
import PartnerSpouse from '@/components/onboarding/partnerSpouse'
import { Child } from '@/components/onboarding/child'
import { NOT_STARTED } from './guidedExperienceStepStatus'

const knownUserSteps = [
  {
    id: 'step-known-getting-started',
    heading: 'Getting started on your EOI application',
    label: 'Getting started',
    title: 'Onboarding',
    content: <StepGettingStarted isKnownUser={true} />,
    status: NOT_STARTED,
    isStepRequired: () => true,
  },
  {
    id: 'step-known-employee-info',
    heading: 'Employee information',
    label: 'Employee information',
    title: 'We need some general info to get started.',
    content: <EmployeeInformation />,
    status: NOT_STARTED,
    isStepRequired: () => true,
  },
  {
    id: 'step-known-live-and-work',
    heading: 'Live and work',
    label: 'Live and work',
    title: 'Tell us where you live and work, and how to contact you.',
    content: <LiveAndWork />,
    status: NOT_STARTED,
    isStepRequired: () => true,
  },
  {
    id: 'step-known-partner-spouse-applicant',
    heading: 'Partner/spouse applicant',
    label: 'Partner/spouse applicant',
    title: "Let's set up their application",
    content: <PartnerSpouse />,
    status: NOT_STARTED,
    isStepRequired: (requiredApplicants) => requiredApplicants?.requireSpouse === true,
  },
  {
    id: 'step-known-child-applicants',
    heading: 'Child applicants',
    label: 'Child applicants',
    title: "Let's set up their application",
    content: <Child />,
    status: NOT_STARTED,
    isStepRequired: (requiredApplicants) => requiredApplicants?.requireChildren === true,
  },
]

const unknownUserSteps = [
  {
    id: 'step-unknown-getting-started',
    heading: 'Getting started on your EOI application',
    label: 'Getting started',
    title: 'Onboarding',
    content: <StepGettingStarted isKnownUser={false} />,
    status: NOT_STARTED,
    isStepRequired: () => true,
  },
  {
    id: 'step-unknown-applicants',
    heading: 'Applicants',
    label: 'Applicants',
    title: 'Let us know who needs an application.',
    content: <Applicants />,
    status: NOT_STARTED,
    isStepRequired: () => true,
  },
  {
    id: 'step-unknown-employee-info',
    heading: 'Employee information',
    label: 'Employee information',
    title: 'We need some general info to get started.',
    content: <EmployeeInformation />,
    status: NOT_STARTED,
    isStepRequired: () => true,
  },
  {
    id: 'step-unknown-live-and-work',
    heading: 'Live and work',
    label: 'Live and work',
    title: 'Tell us where you live and work, and how to contact you.',
    content: <LiveAndWork />,
    status: NOT_STARTED,
    isStepRequired: () => true,
  },
  {
    id: 'step-unknown-partner-spouse-applicant',
    heading: 'Partner/spouse applicant',
    label: 'Partner/spouse applicant',
    title: "Let's set up their application",
    content: <PartnerSpouse />,
    status: NOT_STARTED,
    isStepRequired: (requiredApplicants) => requiredApplicants?.requireSpouse === true,
  },
  {
    id: 'step-unknown-child-applicants',
    heading: 'Child applicants',
    label: 'Child applicants',
    title: "Let's set up their application",
    content: <Child />,
    status: NOT_STARTED,
    isStepRequired: (requiredApplicants) => requiredApplicants?.requireChildren === true,
  },
]

export { knownUserSteps as KNOWN_USER_STEPS, unknownUserSteps as UNKNOWN_USER_STEPS }
