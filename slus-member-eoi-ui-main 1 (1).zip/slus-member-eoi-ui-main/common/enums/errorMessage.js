export const DEFAULT = 'Something went wrong'

export const REQUIRED = 'Please input a group policy number'

export const POLICY = "We couldn't find your policy, double check you entered it correctly"
