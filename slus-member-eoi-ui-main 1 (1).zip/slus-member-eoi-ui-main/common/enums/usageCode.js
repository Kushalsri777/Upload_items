import { isNil } from 'lodash'

const CANCER_CIRC_RESP = { key: 'CancerCircResp', level: 1 }
const NEUR_PSYCH_INFEC = { key: 'NeurPsychInfec', level: 1 }
const ADDIC_DIAB_CHRON = { key: 'AddicDiabChron', level: 1 }
const MEDIC_MISSED_WORK = { key: 'MedicMissedWork', level: 1 }

const ALL = [CANCER_CIRC_RESP, NEUR_PSYCH_INFEC, ADDIC_DIAB_CHRON, MEDIC_MISSED_WORK]

const isLevel1 = (q) => {
  const { requirementOptionUsageCd: usageCode } = q
  const foundUsageCode = ALL.find((u) => u.key === usageCode && u.level === 1)
  return !isNil(foundUsageCode)
}

const isQuestionAffirmative = (q) => 'YES' === q.textValue

const mapFollowUps = (questions) => {
  const lungOptionCode = 'LungRespDisord'
  const lungFollowUps = questions.filter(({ requirementOptionUsageCd: c }) => c === 'LungDiseaseFlUp')
  const isRequiresFollowUps = (q) => q.textValue === 'YES'

  return questions.map((q) => {
    const { requirementOptionCd: optionCode } = q
    if (lungOptionCode === optionCode) {
      const followUps = lungFollowUps
      return {
        ...q,
        followUps,
        isRequiresFollowUps,
      }
    }
    return q
  })
}

export { CANCER_CIRC_RESP, NEUR_PSYCH_INFEC, ADDIC_DIAB_CHRON, MEDIC_MISSED_WORK, isLevel1, isQuestionAffirmative }
