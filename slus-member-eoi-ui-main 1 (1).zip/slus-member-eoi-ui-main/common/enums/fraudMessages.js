export const fraudMessagePerState = [
  {
    statesCodes: ['AL'],
    message: `Any person who knowingly presents a false or fraudulent claim for payment of a loss or benefit or who knowingly presents false information in an application for insurance is guilty of a crime and may be subject to restitution fines or confinement in prison, or any combination thereof.`,
  },
  {
    statesCodes: ['AR', 'LA', 'MA', 'NM', 'RI', 'WV'],
    message: `Any person who knowingly presents a false or fraudulent claim for payment of a loss or benefit or knowingly presents false information in an application for insurance is guilty of a crime and may be subject to fines and confinement in prison.`,
  },
  {
    statesCodes: ['CO'],
    message: ` It is unlawful to knowingly provide false, incomplete, or misleading facts or information to an insurance company for the purpose of defrauding or attempting to defraud the company. Penalties may include imprisonment, fines, denial of insurance and civil damages. Any insurance company or agent of an insurance company who knowingly provides false, incomplete, or misleading facts or information to a policyholder or claimant for the purpose of defrauding or attempting to defraud the policyholder or claimant with regard to a settlement or award payable from insurance proceeds shall be reported to the Colorado Division of Insurance within the Department of Regulatory Agencies.`,
  },
  {
    statesCodes: ['DC'],
    message: `Any person who knowingly presents a false or fraudulent claim for payment of a loss or benefit or knowingly presents false information in an application for insurance is guilty of a crime and may be subject to fines and confinement in prison.`,
  },
  {
    statesCodes: ['FL'],
    message: `Any person who knowingly and with intent to injure, defraud, or deceive any insurer files a statement of claim or an application containing any false, incomplete, or misleading information is guilty of a felony of the third degree.`,
  },
  {
    statesCodes: ['KS'],
    message: `Any person who knowingly and with intent to defraud any insurance company or other person files an Application for insurance or statement of claim containing any materially false information or conceals, for the purpose of misleading, information concerning any fact material thereto may be guilty of insurance fraud as determined by a court of law.`,
  },
  {
    statesCodes: ['KY'],
    message: `Any person who knowingly and with intent to defraud any insurance company or other person files an application for insurance, containing any materially false information, or conceals, for the purpose of misleading, information concerning any fact material thereto commits a fraudulent insurance act, which is a crime.`,
  },
  {
    statesCodes: ['MD'],
    message: `Any person who knowingly OR willfully presents a false or fraudulent claim for payment of a loss or benefit or who knowingly OR willfully presents false information in an application for insurance is guilty of a crime and may be subject to fines and confinement in prison.`,
  },
  {
    statesCodes: ['ME', 'TN', 'WA'],
    message: `It is a crime to knowingly provide false, incomplete, or misleading information to an insurance company for the purpose of defrauding the company. Penalties include imprisonment, fines, and denial of insurance benefits.`,
  },
  {
    statesCodes: ['NJ'],
    message: `Any person who knowingly includes any false or misleading information on an application for an insurance policy is subject to criminal and civil penalties.`,
  },
  {
    statesCodes: ['OH'],
    message: `Any person who, with intent to defraud or knowing that he is facilitating a fraud against an insurer, submits an application or files a claim containing a false or deceptive statement is guilty of insurance fraud.`,
  },
  {
    statesCodes: ['OK'],
    message: `WARNING: Any person who knowingly, and with intent to injure, defraud or deceive any insurer, makes any claim for the proceeds of an insurance policy containing any false, incomplete or misleading information is guilty of a felony.`,
  },
  {
    statesCodes: ['OR', 'VA'],
    message: `Any person who, with intent to defraud or knowing that he is facilitating a fraud against an insurer, submits an application or files a claim containing a false or deceptive statement may have violated state law.`,
  },
  {
    statesCodes: ['PR'],
    message: `Any person who knowingly and with the intention of defrauding presents false information in an insurance application, or presents, helps, or causes the presentation of a fraudulent claim for the payment of a loss or any other benefit, or presents more than one claim for the same damage or loss, shall incur a felony and, upon conviction, shall be sanctioned for each violation by a fine of not less than five thousand dollars ($5,000) and not more than ten thousand dollars ($10,000), or a fixed term of imprisonment for three (3) years, or both penalties. Should aggravating circumstances be present, the penalty thus established may be increased to a maximum of five (5) years, if extenuating circumstances are present, it may be reduced to a minimum of two (2) years.`,
  },
  {
    statesCodes: ['VT'],
    message: `Any person who knowingly presents a false statement in an application for insurance may be guilty of a criminal offense and subject to penalties under state law.`,
  },
]
