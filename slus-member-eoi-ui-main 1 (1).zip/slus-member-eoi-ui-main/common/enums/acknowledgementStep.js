const FRAUD_WARNING = 'fraudWarning'
const HIPAA_AUTH = 'hipaaAuth'

export { FRAUD_WARNING, HIPAA_AUTH }
