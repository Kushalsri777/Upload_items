/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './common/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      fontFamily: {
        sunlife: 'Sun Life New Text Regular',
        sunlifeBold: 'Sun Life New Text Bold',
        sunlifeItalic: 'Sun Life New Text Italic',
        sunlifeBoldItalic: 'Sun Life New Text Bold Italic',
        sunlifeNewDisplay: 'Sun Life New Display Regular',
        sunlifeNewDisplayBold: 'Sun Life New Display Bold',
      },
    },
    screens: {
      xs: '360px',
      // => @media (min-width: 360px) { ... }
      sm: '600px',
      // => @media (min-width: 600px) { ... }
      md: '905px',
      // => @media (min-width: 905px) { ... }
      lg: '1240px',
      // => @media (min-width: 1240px) { ... }
    },
    fontSize: {
      'xs-bold': [
        '12px',
        {
          lineHeight: '16px',
          fontWeight: '700',
        },
      ],
      '3.5xl': [
        '32px',
        {
          lineHeight: '40px',
          fontWeight: '400',
        },
      ],
    },
  },
  plugins: [require('@tailwindcss/forms')],
}
