'use client'

import { useRouter } from 'next/router'
import { useEffect } from 'react'

function Login() {
  const router = useRouter()

  useEffect(() => {
    const redirect = async () => {
      await router.push('/')
    }
    redirect().catch(console.error)
  }, [router])
  return <>redirecting</>
}

export default Login
