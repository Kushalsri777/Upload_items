'use client'

import Link from 'next/link'
import clsx from 'clsx'
import Layout from '@/components/layout'
import TriIcon64 from '@/public/images/exclamation-triangle-64px.svg'
import s from './500.module.css'

const topicLinks = [
  {
    href: '/',
    label: 'Log in',
  },
  {
    href: 'https://forms.sunlife-usa.com/onlineordering/get_file.cfm?form_id=528',
    label: 'Get the paper form',
    rel: 'noopener noreferrer',
    target: '_blank',
  },
]

const homeLink = {
  href: '/',
  label: 'homepage',
}

function Sunlife500() {
  const titleText = 'Technical difficulties'
  const text1 =
    'Details are currently unavailable but we have logged this event. Please try again later or contact us at 800-247-6875'
  const text2 = 'Or, you may have been wanting to reach one of these pages:'
  const text3a = "If you still can't reach the page, try going back to the"
  const text3b = 'or contact us at 800-247-6875 and let us know what went wrong.'

  return (
    <>
      <Layout>
        <div className="pt-[3.5rem]">
          <div className={s.headline}>
            <TriIcon64 className="h-auto" alt="Important" width={64} height={64} />
            <span data-cy="heading_500" className={clsx('mt-[0.55rem]', s.f32)}>
              {titleText}
            </span>
          </div>
          <div className={s.mb40}>
            <span data-cy="moved_page" className={s.f16}>
              {text1}
            </span>
          </div>
          <div className="pb-3">
            <span data-cy="alternate_page" className={s.f16}>
              {text2}
            </span>
          </div>
          <div className={s.mb40}>
            {topicLinks.map((l, i) => (
              <Link
                key={`topic_link_key_${i}`}
                href={l.href}
                rel={l.rel}
                target={l.target}
                className={clsx(s.link, s.list, 'font-sunlifeBold')}>
                {l.label}
              </Link>
            ))}
          </div>
          <div className={clsx('pb-[96px]', s.f16)}>
            <span data-cy="redirect_info">
              {text3a}
              <Link href={homeLink.href} className={clsx(s.mx4, s.link, 'font-sunlifeBold')}>
                {homeLink.label}
              </Link>
              {text3b}
            </span>
          </div>
        </div>
      </Layout>
    </>
  )
}

export default Sunlife500
