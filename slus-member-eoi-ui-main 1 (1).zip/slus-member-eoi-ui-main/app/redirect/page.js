'use client'

import Layout from '@/components/layout'
import styles from './index.module.css'
import clsx from 'clsx'
import { useCallback, useContext, useEffect, useRef, useState } from 'react'
import { AppContext } from '@/components/context/app.context'
import WithAuth from '@/components/auth/withAuth'

function Redirect() {
  const { redirectUrl, policyInfo, sessionInfo } = useContext(AppContext)
  const formRef = useRef(null)
  const message = "Hang Tight, we're redirecting you"
  const subMessage =
    "We're working on a new EOI experience. At this time your policy\n" +
    " is not supported and you're being redirected to our existing website."
  const subMessage2 = 'If the page does not redirect '
  const linkText = 'please click here'

  const onRedirectClickHandler = () => {
    window.location.replace(redirectUrl)
  }

  const [employeeInfo, setEmployeeInfo] = useState({ employeeIdInput1: '', employeeIdInput2: '', employeeIdInput3: '' })

  /**
   * transformEmployeeInfo will split the employeeId in three parts. E.g: 123-58-9874 ,
   * the value will be divided in 3 parts and each part will be used in the form in separate fields.
   * This way the EmployeeId field will be populated in the legacy form.
   * @type {(function(): void)|*}
   */
  const transformEmployeeInfo = useCallback(() => {
    if (sessionInfo && sessionInfo?.employeeId) {
      let employeeId = sessionInfo.employeeId
      let counter = 1
      const start = 0
      let end = 3
      let employeeIdInput1 = ''
      let employeeIdInput2 = ''
      let employeeIdInput3 = ''
      while (employeeId) {
        const extractedEmployeeIdSubValue = employeeId.substring(start, end)
        employeeId = employeeId.substring(end)

        if (counter === 1) {
          employeeIdInput1 = extractedEmployeeIdSubValue
          end = 2
        } else if (counter === 2) {
          employeeIdInput2 = extractedEmployeeIdSubValue
          end = 6
        } else if (counter === 3) {
          employeeIdInput3 = extractedEmployeeIdSubValue
          employeeId = ''
        }

        counter++
      }
      setEmployeeInfo({ employeeIdInput1, employeeIdInput2, employeeIdInput3 })
    }
  }, [sessionInfo])

  useEffect(() => {
    transformEmployeeInfo()
    setTimeout(() => {
      formRef.current.submit()
    }, 5000)
  }, [policyInfo, redirectUrl, sessionInfo, transformEmployeeInfo])

  return (
    <>
      <Layout disableContactInfo={true}>
        <div className={styles.container}>
          <span className={styles.mainMessage}>{message}</span>

          <div>
            <div>
              <i className={clsx(styles.spinnerIcon, 'fad', 'fa-spinner-third', 'fa-spin')} />
            </div>
            <div>
              <span className={styles.subMessage}>{subMessage}</span>
            </div>
            <div className={styles.linkContainer}>
              <span className={styles.subMessage}>{subMessage2}</span>
              <span className={styles.link} onClick={onRedirectClickHandler}>
                {linkText}
              </span>
            </div>
          </div>
        </div>
        <form ref={formRef} name="eoilegacyForm" id="eoilegacyForm" method="post" action={redirectUrl}>
          <input
            hidden={true}
            id="grpPolicyNo"
            type="text"
            name="grpPolicyNo"
            size="20"
            value={policyInfo.policyNumber}
          />

          <input
            hidden={true}
            id="EmployeeIdInput1"
            type="text"
            name="EmployeeIdInput1"
            size="4"
            maxLength={3}
            value={employeeInfo?.employeeIdInput1}
          />
          <input
            hidden={true}
            id="EmployeeIdInput2"
            type="text"
            name="EmployeeIdInput2"
            size="3"
            maxLength={2}
            value={employeeInfo?.employeeIdInput2}
          />
          <input
            hidden={true}
            id="EmployeeIdInput3"
            type="text"
            name="EmployeeIdInput3"
            size="6"
            maxLength={6}
            value={employeeInfo?.employeeIdInput3}
          />

          <input hidden={true} id="employee" type="checkbox" name="employee" checked={sessionInfo?.employeeSelected} />
          <input hidden={true} id="spouse" type="checkbox" name="spouse" checked={sessionInfo?.spouseSelected} />
          <input hidden={true} id="dependent" type="checkbox" name="dependent" checked={sessionInfo?.childSelected} />

          <input
            hidden={true}
            id="noOfClildren"
            type="text"
            name="noOfClildren"
            maxLength={2}
            size={15}
            value={sessionInfo?.numberOfChildren}
          />
        </form>
      </Layout>
    </>
  )
}

export default WithAuth(Redirect)
