'use client'

import '/styles/styles.scss'
import '@fortawesome/fontawesome-free/css/all.min.css'
import { ApplicantsProvider } from '@/components/context/Applicants.context'
import { RequiredApplicantsProvider } from '@/components/context/RequiredApplicants.context'
import { AppProvider } from '@/components/context/app.context'
import { useEffect, useState } from 'react'
import TimeoutModal from '@/components/timeoutModal'
import { LegacyApplicationProvider } from '@/components/context/LegacyApplication.context'
import { ContinuanceProvider } from '@/components/context/Continuance.context'
import { EnrollerApplicationsProvider } from '@/components/context/EnrollerApplications.context'
import { HealthHistoryStepsProvider } from '@/components/context/HealthHistorySteps.context'

export default function RootLayout({ children }) {
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    setIsLoading(false)
  }, [])

  return (
    <html lang="en">
      <head>
        <meta name="format-detection" content="telephone=no, date=no, email=no, address=no" />
        <link
          rel="stylesheet"
          href="https://cdn.sunlife.com/content/dam/sunlife/global/shared-assets/css/sl-colors.css"
        />
        <title>EOI Member</title>
      </head>
      <body className="font-sunlife">
        <HealthHistoryStepsProvider>
          <EnrollerApplicationsProvider>
            <ContinuanceProvider>
              <ApplicantsProvider>
                <RequiredApplicantsProvider>
                  <LegacyApplicationProvider>
                    <AppProvider>
                      {isLoading ? null : (
                        <>
                          <TimeoutModal />
                          {children}
                        </>
                      )}
                    </AppProvider>
                  </LegacyApplicationProvider>
                </RequiredApplicantsProvider>
              </ApplicantsProvider>
            </ContinuanceProvider>
          </EnrollerApplicationsProvider>
        </HealthHistoryStepsProvider>
      </body>
    </html>
  )
}
