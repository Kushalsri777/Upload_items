'use client'

import WithAuth from '@/components/auth/withAuth'
import Dashboard from '@/components/dashboard/dashboard'

function DashboardWithAuth() {
  return <Dashboard />
}

export default WithAuth(DashboardWithAuth)
