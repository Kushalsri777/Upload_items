'use client'

import Layout from '@/components/layout'
import LoginBanner from '@/components/login/loginBanner'
import LoginInstructions from '@/components/login/loginInstructions'
import LoginFAQ from '@/components/login/loginFAQ'

export default function Home() {
  return (
    <>
      <Layout disableContactInfo disableContainer>
        <LoginBanner />
        <LoginInstructions />
        <LoginFAQ />
      </Layout>
    </>
  )
}
