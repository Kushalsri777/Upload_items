'use client'

import { useContext } from 'react'
import Layout from '@/components/layout'
import PageHeader from '@/components/pageHeader'
import { SUBMITTED } from '@/common/utils/pageText'
import { AppContext } from '@/components/context/app.context'
import { EXTERNAL, PRINT } from '@/common/enums/imageIcons'
import PageLink from '@/components/pageLink'
import { openInNewTab } from '@/common/utils/util'
import WithAuth from '@/components/auth/withAuth'

const {
  title,
  body: {
    a,
    b,
    c,
    d,
    e,
    links: { review, print },
  },
} = SUBMITTED
const DISABLE_PRINT_LINK = true // TODO: We can remove this flag or set to false once we have the details for these links

const BASE_PATH = process.env.NEXT_PUBLIC_BASE_PATH || ''

function Submitted() {
  const { policyInfo: policy } = useContext(AppContext)

  const handleOnClickReview = () => {
    openInNewTab(`${BASE_PATH}/electronic-consent`)
  }

  const handleOnClickPrint = () => {
    console.log(`onClick: ${print}`)
  }

  return (
    <>
      <Layout>
        <PageHeader title={title} sponsorName={policy?.sponsorName}>
          <PageLink image={<EXTERNAL width={20} height={20} />} label={review} onClick={handleOnClickReview} />
        </PageHeader>
        <div className="border-2 border-solid border-[#dcdedf] p-6">
          <div className="mb-8">{a}</div>
          <div className="mb-8 font-sunlifeBold">{b}</div>
          <div className="mb-8">{c}</div>
          <div className="mb-8">{d}</div>
          <div className="mb-8">{e}</div>
          {DISABLE_PRINT_LINK ? null : <PageLink image={<PRINT />} label={print} onClick={handleOnClickPrint} />}
        </div>
      </Layout>
    </>
  )
}

export default WithAuth(Submitted)
