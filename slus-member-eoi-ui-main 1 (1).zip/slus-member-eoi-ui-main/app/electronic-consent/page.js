'use client'

import React, { useRef } from 'react'
import Layout from '@/components/layout'

import ElectronicConsentDisclosure from '@/components/electronicConsentDisclosure'
import { useReactToPrint } from 'react-to-print'

const ElectronicConsentPage = () => {
  const componentRef = useRef()
  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
  })

  return (
    <Layout>
      <ElectronicConsentDisclosure ref={componentRef} handlePrint={handlePrint} />
    </Layout>
  )
}

export default ElectronicConsentPage
