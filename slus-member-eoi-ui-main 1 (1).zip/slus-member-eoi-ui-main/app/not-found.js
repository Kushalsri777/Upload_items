'use client'

import CloudIcon from '@/public/images/cloud404.svg'
import s from './500.module.css'
import clsx from 'clsx'
import Link from 'next/link'
import Layout from '@/components/layout'

const topicLinks = [
  {
    href: '/login',
    label: 'Log in',
  },
  {
    href: 'https://forms.sunlife-usa.com/onlineordering/get_file.cfm?form_id=528',
    label: 'Get the paper form',
    rel: 'noopener noreferrer',
    target: '_blank',
  },
]

const homeLink = {
  href: '/',
  label: 'homepage',
}

function Sunlife404() {
  const heading = 'Oops, there’s a cloud. Let’s make it sunny again.'
  const pageMoved = 'The page you are trying to reach might have been moved, updated or deleted.'
  const alternatePage = 'Are one of these pages the one you’re looking for?'
  const redirect1 = "If you still can't reach the page, try going back to the"
  const redirect2 = 'or contact us at 800-247-6875 and let us know what went wrong.'

  return (
    <>
      <Layout disableSubheader>
        <div className="pt-[56px]">
          <div className={clsx(s.iconPadding, s.headline)}>
            <CloudIcon className="h-auto mr-2" alt="Cloud 404 Icon" width={97.5} height={54} />
          </div>
          <h1 data-cy={'heading_404'} className={s.headline}>
            {heading}
          </h1>
          <div className={s.mb40}>
            <span data-cy={'moved_page'}>{pageMoved}</span>
          </div>
          <div className={s.headline}>
            <span data-cy={'alternate_page'}>{alternatePage}</span>
          </div>
          <div className={s.mb40}>
            {topicLinks.map((l, i) => (
              <Link
                key={`topic_link_key_${i}`}
                href={l.href}
                rel={l.rel}
                target={l.target}
                className={clsx(s.link, s.list, 'font-sunlifeBold')}>
                {l.label}
              </Link>
            ))}
          </div>
          <div data-cy={'redirect_info'} className={clsx('pb-[96px]', s.f16)}>
            <span>
              {redirect1}
              <Link href={homeLink.href} className={clsx(s.mx4, s.link, 'font-sunlifeBold')}>
                {homeLink.label}
              </Link>
              {redirect2}
            </span>
          </div>
        </div>
      </Layout>
    </>
  )
}

export default Sunlife404
