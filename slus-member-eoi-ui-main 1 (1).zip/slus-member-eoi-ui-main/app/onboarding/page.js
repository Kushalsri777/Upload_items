'use client'

import WithAuth from '@/components/auth/withAuth'
import Layout from '@/components/layout'
import GE_Onboarding from '@/components/onboarding/geOnboarding'

function Onboarding() {
  return (
    <Layout>
      <GE_Onboarding />
    </Layout>
  )
}

export default WithAuth(Onboarding)
