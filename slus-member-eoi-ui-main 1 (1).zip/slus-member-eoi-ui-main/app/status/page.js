function Health() {
  return <>OK</>
}

export default Health
