export default 'svg'
export const ReactComponent = 'div'
